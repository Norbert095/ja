import { Suspense, useEffect, useState, useCallback, useRef } from "react";
import "@fontsource/inter";
import { useGameStore, CubeType, Enemy } from "./lib/stores/useGameStore";
import { useAudio } from "./lib/stores/useAudio";
import { GameScene } from "./components/game";
import { MainMenu } from "./components/ui/MainMenu";
import { SaveSlotSelector } from "./components/ui/SaveSlotSelector";
import { GameHUD } from "./components/ui/GameHUD";
import { PauseMenu } from "./components/ui/PauseMenu";
import { CraftingUI } from "./components/ui/CraftingUI";
import { InventoryUI } from "./components/ui/InventoryUI";
import { SandboxPanel } from "./components/ui/SandboxPanel";
import { GameOver } from "./components/ui/GameOver";
import { MobileControls } from "./components/ui/MobileControls";

function LoadingScreen() {
  return (
    <div className="fixed inset-0 bg-gradient-to-b from-purple-900 via-indigo-900 to-black flex flex-col items-center justify-center">
      <div className="text-4xl font-bold text-white mb-8 animate-pulse">
        Loading...
      </div>
      <div className="w-64 h-2 bg-gray-700 rounded-full overflow-hidden">
        <div className="h-full bg-gradient-to-r from-purple-500 to-pink-500 animate-pulse" style={{ width: "60%" }} />
      </div>
    </div>
  );
}

function App() {
  const { 
    phase, 
    setPhase, 
    spawnCube, 
    spawnEnemy,
    setBackgroundMusic,
    setHitSound,
    setSuccessSound
  } = useGameStore();
  
  const audioStore = useAudio();
  
  const [isPaused, setIsPaused] = useState(false);
  const [showCrafting, setShowCrafting] = useState(false);
  const [showInventory, setShowInventory] = useState(false);
  const [showSandbox, setShowSandbox] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const mobileInputRef = useRef({ forward: 0, right: 0 });
  
  useEffect(() => {
    const bgMusic = new Audio("/sounds/background.mp3");
    bgMusic.loop = true;
    bgMusic.volume = 0.3;
    audioStore.setBackgroundMusic(bgMusic);
    
    const hitSfx = new Audio("/sounds/hit.mp3");
    hitSfx.volume = 0.5;
    audioStore.setHitSound(hitSfx);
    
    const successSfx = new Audio("/sounds/success.mp3");
    successSfx.volume = 0.5;
    audioStore.setSuccessSound(successSfx);
    
    // Suppress pointer lock errors from DREI library
    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      if (
        event.reason?.message?.includes("user has exited the lock") ||
        event.reason?.message?.includes("Target Element removed from DOM")
      ) {
        event.preventDefault();
      }
    };
    
    window.addEventListener("unhandledrejection", handleUnhandledRejection);
    setIsLoading(false);
    
    return () => window.removeEventListener("unhandledrejection", handleUnhandledRejection);
  }, []);
  
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (phase !== "playing" && phase !== "sandbox") return;
      
      if (e.code === "Escape") {
        if (showCrafting) {
          setShowCrafting(false);
        } else if (showInventory) {
          setShowInventory(false);
        } else if (showSandbox) {
          setShowSandbox(false);
        } else {
          setIsPaused(!isPaused);
        }
      }
      
      if (e.code === "Tab") {
        e.preventDefault();
        if (!isPaused) {
          setShowInventory(!showInventory);
        }
      }
      
      if (e.code === "KeyC") {
        if (!isPaused) {
          setShowCrafting(!showCrafting);
        }
      }
    };
    
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [phase, isPaused, showCrafting, showInventory, showSandbox]);
  
  useEffect(() => {
    if (phase === "sandbox" && !showSandbox) {
      setShowSandbox(true);
    }
  }, [phase, showSandbox]);
  
  const handlePause = useCallback(() => {
    setIsPaused(true);
  }, []);
  
  const handleResume = useCallback(() => {
    setIsPaused(false);
    setShowCrafting(false);
    setShowInventory(false);
    setShowSandbox(false);
  }, []);
  
  const handleSpawnCube = useCallback((type: CubeType, position: [number, number, number]) => {
    spawnCube(type, position);
  }, [spawnCube]);
  
  const handleSpawnEnemy = useCallback((enemy: Omit<Enemy, "id">) => {
    spawnEnemy(enemy);
  }, [spawnEnemy]);
  
  if (isLoading) {
    return <LoadingScreen />;
  }
  
  return (
    <div className="w-screen h-screen overflow-hidden bg-black">
      {phase === "menu" && <MainMenu />}
      
      {phase === "slot_select" && <SaveSlotSelector />}
      
      {(phase === "playing" || phase === "sandbox") && (
        <Suspense fallback={<LoadingScreen />}>
          <GameScene menuOpen={isPaused || showCrafting || showInventory} />
          
          <GameHUD 
            onPause={handlePause}
            onOpenInventory={() => setShowInventory(true)}
            onOpenCrafting={() => setShowCrafting(true)}
          />

          <MobileControls
            onMove={(x, z) => {
              mobileInputRef.current = { forward: -z, right: x };
              if (window.mobileInputRef) {
                window.mobileInputRef.current = mobileInputRef.current;
              }
            }}
            onJump={() => document.dispatchEvent(new KeyboardEvent('keydown', { code: 'Space' }))}
            onAttack={() => document.dispatchEvent(new MouseEvent('click'))}
            onInteract={() => document.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyE' }))}
            onInventory={() => setShowInventory(!showInventory)}
          />
          
          {isPaused && <PauseMenu onResume={handleResume} />}
          
          {showCrafting && !isPaused && (
            <CraftingUI onClose={() => setShowCrafting(false)} />
          )}
          
          {showInventory && !isPaused && (
            <InventoryUI onClose={() => setShowInventory(false)} />
          )}
          
          {showSandbox && phase === "sandbox" && !isPaused && (
            <SandboxPanel 
              onClose={() => setShowSandbox(false)}
              onSpawnCube={handleSpawnCube}
              onSpawnEnemy={handleSpawnEnemy}
            />
          )}
        </Suspense>
      )}
      
      {phase === "game_over" && <GameOver />}
    </div>
  );
}

export default App;
