import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { Text } from "@react-three/drei";

interface CrystalProps {
  position: [number, number, number];
  hp: number;
  maxHp: number;
  onDamage?: (amount: number) => void;
}

export function Crystal({ position, hp, maxHp, onDamage }: CrystalProps) {
  const crystalRef = useRef<THREE.Mesh>(null);
  const glowRef = useRef<THREE.PointLight>(null);
  
  const healthPercent = hp / maxHp;
  
  const getHealthColor = () => {
    if (healthPercent > 0.7) return "#00FF88";
    if (healthPercent > 0.4) return "#FFFF00";
    if (healthPercent > 0.2) return "#FF8800";
    return "#FF0000";
  };
  
  const color = getHealthColor();
  
  useFrame((state) => {
    if (crystalRef.current) {
      crystalRef.current.rotation.y += 0.015;
      crystalRef.current.position.y = position[1] + 3 + Math.sin(state.clock.elapsedTime * 2) * 0.3;
      
      if (healthPercent < 0.3) {
        crystalRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 10) * 0.05;
        crystalRef.current.rotation.z = Math.cos(state.clock.elapsedTime * 10) * 0.05;
      }
    }
    
    if (glowRef.current) {
      glowRef.current.intensity = 2 + Math.sin(state.clock.elapsedTime * 3) * 0.5;
    }
  });
  
  return (
    <group position={position}>
      <mesh position={[0, 0.5, 0]}>
        <cylinderGeometry args={[3, 4, 1, 6]} />
        <meshStandardMaterial color="#444444" metalness={0.5} roughness={0.5} />
      </mesh>
      
      <mesh position={[0, 0.75, 0]}>
        <cylinderGeometry args={[2.5, 3, 0.5, 6]} />
        <meshStandardMaterial color="#555555" />
      </mesh>
      
      <mesh ref={crystalRef} position={[0, 3, 0]} castShadow>
        <octahedronGeometry args={[2, 0]} />
        <meshStandardMaterial 
          color={color}
          emissive={color}
          emissiveIntensity={0.6}
          transparent
          opacity={0.85}
          metalness={0.2}
          roughness={0.1}
        />
      </mesh>
      
      <mesh position={[0, 3, 0]}>
        <octahedronGeometry args={[2.2, 0]} />
        <meshBasicMaterial 
          color={color}
          transparent
          opacity={0.15}
          wireframe
        />
      </mesh>
      
      <pointLight 
        ref={glowRef}
        position={[0, 3, 0]} 
        color={color} 
        intensity={2} 
        distance={25} 
      />
      
      <group position={[0, 6.5, 0]}>
        <Text
          fontSize={0.6}
          color="white"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.04}
          outlineColor="black"
        >
          Crystal of Life
        </Text>
        
        <group position={[0, -0.8, 0]}>
          <mesh>
            <planeGeometry args={[4, 0.4]} />
            <meshBasicMaterial color="#222222" />
          </mesh>
          <mesh position={[(healthPercent - 1) * 2, 0, 0.01]} scale={[healthPercent, 1, 1]}>
            <planeGeometry args={[4, 0.4]} />
            <meshBasicMaterial color={color} />
          </mesh>
        </group>
        
        <Text
          position={[0, -0.8, 0.1]}
          fontSize={0.35}
          color="white"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.02}
          outlineColor="black"
        >
          {`${hp} / ${maxHp}`}
        </Text>
      </group>
      
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <mesh 
          key={i}
          position={[
            Math.cos((i / 6) * Math.PI * 2) * 1.5,
            3,
            Math.sin((i / 6) * Math.PI * 2) * 1.5
          ]}
        >
          <octahedronGeometry args={[0.3, 0]} />
          <meshStandardMaterial 
            color={color}
            emissive={color}
            emissiveIntensity={0.5}
            transparent
            opacity={0.6}
          />
        </mesh>
      ))}
    </group>
  );
}
