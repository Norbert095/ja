import { useRef, useState, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { CUBE_COLORS } from "@/lib/gameData";
import { CubeType } from "@/lib/stores/useGameStore";

interface CubeProps {
  id: string;
  type: CubeType;
  position: [number, number, number];
  onClick?: () => void;
  isHeld?: boolean;
  isHighlighted?: boolean;
}

export function Cube({ id, type, position, onClick, isHeld = false, isHighlighted = false }: CubeProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const [animatedY, setAnimatedY] = useState(position[1]);
  const initialY = useRef(position[1]);
  
  const color = CUBE_COLORS[type];
  
  useEffect(() => {
    if (isHeld) {
      document.body.style.cursor = "grabbing";
    } else if (hovered) {
      document.body.style.cursor = "grab";
    } else {
      document.body.style.cursor = "default";
    }
    
    return () => {
      document.body.style.cursor = "default";
    };
  }, [hovered, isHeld]);
  
  useFrame((state) => {
    if (!meshRef.current) return;
    
    meshRef.current.rotation.y += 0.01;
    
    const bobHeight = 0.15;
    const bobSpeed = 2;
    setAnimatedY(initialY.current + Math.sin(state.clock.elapsedTime * bobSpeed + id.charCodeAt(0)) * bobHeight);
    
    if (hovered || isHighlighted) {
      meshRef.current.scale.lerp(new THREE.Vector3(1.2, 1.2, 1.2), 0.1);
    } else {
      meshRef.current.scale.lerp(new THREE.Vector3(1, 1, 1), 0.1);
    }
  });
  
  if (isHeld) return null;
  
  return (
    <mesh
      ref={meshRef}
      position={[position[0], animatedY, position[2]]}
      onClick={(e) => {
        e.stopPropagation();
        if (onClick) onClick();
      }}
      onPointerOver={(e) => {
        e.stopPropagation();
        setHovered(true);
      }}
      onPointerOut={() => setHovered(false)}
      castShadow
    >
      <boxGeometry args={[0.8, 0.8, 0.8]} />
      <meshStandardMaterial 
        color={color}
        emissive={color}
        emissiveIntensity={hovered || isHighlighted ? 0.5 : 0.2}
        metalness={0.3}
        roughness={0.4}
      />
      
      {(hovered || isHighlighted) && (
        <pointLight color={color} intensity={1} distance={5} />
      )}
    </mesh>
  );
}

interface CubeStackProps {
  cubes: Array<{ id: string; type: CubeType }>;
  position: [number, number, number];
  onCraftComplete?: (result: string) => void;
}

export function CubeStack({ cubes, position, onCraftComplete }: CubeStackProps) {
  const groupRef = useRef<THREE.Group>(null);
  const [isMerging, setIsMerging] = useState(false);
  const [mergeProgress, setMergeProgress] = useState(0);
  
  useFrame((state, delta) => {
    if (!groupRef.current) return;
    
    if (isMerging) {
      setMergeProgress(prev => {
        const newProgress = prev + delta * 2;
        if (newProgress >= 1 && onCraftComplete) {
          const mainType = cubes[0]?.type;
          if (mainType) {
            onCraftComplete(mainType);
          }
        }
        return newProgress;
      });
      
      groupRef.current.rotation.y += delta * 5;
      const scale = 1 + Math.sin(mergeProgress * Math.PI) * 0.3;
      groupRef.current.scale.setScalar(scale);
    }
  });
  
  useEffect(() => {
    if (cubes.length >= 2) {
      const allSameType = cubes.every(c => c.type === cubes[0].type);
      if (allSameType) {
        const timer = setTimeout(() => {
          setIsMerging(true);
        }, 500);
        return () => clearTimeout(timer);
      }
    }
  }, [cubes]);
  
  return (
    <group ref={groupRef} position={position}>
      {cubes.map((cube, index) => {
        const yOffset = index * 0.9;
        const color = CUBE_COLORS[cube.type];
        
        return (
          <mesh 
            key={cube.id} 
            position={[0, yOffset, 0]}
            castShadow
          >
            <boxGeometry args={[0.8, 0.8, 0.8]} />
            <meshStandardMaterial 
              color={color}
              emissive={color}
              emissiveIntensity={isMerging ? 0.8 : 0.2}
              metalness={0.3}
              roughness={0.4}
              transparent={isMerging}
              opacity={isMerging ? 1 - mergeProgress : 1}
            />
          </mesh>
        );
      })}
      
      {isMerging && (
        <pointLight 
          color={CUBE_COLORS[cubes[0]?.type || "common"]} 
          intensity={5 * mergeProgress} 
          distance={10} 
        />
      )}
    </group>
  );
}
