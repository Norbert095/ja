import { useRef, useState, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { Text } from "@react-three/drei";
import { ENEMY_TYPES, BOSS_DATA, SANDBOX_BOSSES } from "@/lib/gameData";
import { Enemy as EnemyType } from "@/lib/stores/useGameStore";

interface EnemyProps {
  enemy: EnemyType;
  playerPosition: [number, number, number];
  onTakeDamage: (enemyId: string, damage: number) => void;
  onPlayerDamage: (damage: number) => void;
}

export function Enemy({ enemy, playerPosition, onTakeDamage, onPlayerDamage }: EnemyProps) {
  const meshRef = useRef<THREE.Group>(null);
  const [isHit, setIsHit] = useState(false);
  const [lastAttackTime, setLastAttackTime] = useState(0);
  
  const enemyData = enemy.isBoss 
    ? [...BOSS_DATA, ...SANDBOX_BOSSES].find(b => b.index === enemy.bossIndex)
    : ENEMY_TYPES.find(e => e.type === enemy.type);
  
  const color = enemyData?.color || "#FF0000";
  const size = enemy.isBoss ? 3 : 1;
  
  useFrame((state) => {
    if (!meshRef.current) return;
    
    const dx = playerPosition[0] - enemy.position[0];
    const dz = playerPosition[2] - enemy.position[2];
    const distance = Math.sqrt(dx * dx + dz * dz);
    
    const aggroRange = enemy.isBoss ? 30 : 15;
    const attackRange = enemy.isBoss ? 4 : 2;
    
    if (distance < aggroRange && distance > attackRange) {
      const moveSpeed = enemy.isBoss ? 2 : 3;
      const moveX = (dx / distance) * moveSpeed * 0.016;
      const moveZ = (dz / distance) * moveSpeed * 0.016;
      
      meshRef.current.position.x += moveX;
      meshRef.current.position.z += moveZ;
      
      enemy.position[0] += moveX;
      enemy.position[2] += moveZ;
    }
    
    if (distance < attackRange) {
      const currentTime = state.clock.elapsedTime;
      const attackCooldown = enemy.isBoss ? 2 : 1.5;
      
      if (currentTime - lastAttackTime > attackCooldown) {
        onPlayerDamage(enemy.damage);
        setLastAttackTime(currentTime);
        
        meshRef.current.scale.set(size * 1.3, size * 1.3, size * 1.3);
        setTimeout(() => {
          if (meshRef.current) {
            meshRef.current.scale.set(size, size, size);
          }
        }, 200);
      }
    }
    
    meshRef.current.lookAt(playerPosition[0], meshRef.current.position.y, playerPosition[2]);
    
    if (enemy.isBoss) {
      meshRef.current.position.y = size / 2 + Math.sin(state.clock.elapsedTime * 2) * 0.2;
    }
  });
  
  const handleClick = () => {
    setIsHit(true);
    setTimeout(() => setIsHit(false), 100);
    onTakeDamage(enemy.id, 10);
  };
  
  const healthPercent = enemy.hp / enemy.maxHp;
  const healthBarColor = healthPercent > 0.5 ? "#00FF00" : healthPercent > 0.25 ? "#FFFF00" : "#FF0000";
  
  return (
    <group 
      ref={meshRef} 
      position={[enemy.position[0], size / 2, enemy.position[2]]}
    >
      {enemy.isBoss ? (
        <group>
          <mesh castShadow onClick={handleClick}>
            <boxGeometry args={[size, size * 1.5, size]} />
            <meshStandardMaterial 
              color={isHit ? "#FFFFFF" : color}
              emissive={color}
              emissiveIntensity={0.3}
            />
          </mesh>
          
          <mesh position={[0, size * 0.9, 0]} castShadow>
            <boxGeometry args={[size * 0.6, size * 0.4, size * 0.6]} />
            <meshStandardMaterial color={color} />
          </mesh>
          
          <mesh position={[size * 0.4, size * 0.2, 0]} rotation={[0, 0, -0.3]} castShadow>
            <boxGeometry args={[size * 0.8, size * 0.3, size * 0.3]} />
            <meshStandardMaterial color={color} />
          </mesh>
          
          <mesh position={[-size * 0.4, size * 0.2, 0]} rotation={[0, 0, 0.3]} castShadow>
            <boxGeometry args={[size * 0.8, size * 0.3, size * 0.3]} />
            <meshStandardMaterial color={color} />
          </mesh>
          
          <pointLight color={color} intensity={2} distance={15} />
        </group>
      ) : (
        <mesh castShadow onClick={handleClick}>
          <boxGeometry args={[size, size * 1.2, size]} />
          <meshStandardMaterial 
            color={isHit ? "#FFFFFF" : color}
            emissive={color}
            emissiveIntensity={0.2}
          />
        </mesh>
      )}
      
      <group position={[0, size * (enemy.isBoss ? 1.5 : 1) + 0.5, 0]}>
        <mesh position={[0, 0, 0]}>
          <planeGeometry args={[2, 0.2]} />
          <meshBasicMaterial color="#333333" />
        </mesh>
        <mesh position={[(healthPercent - 1), 0, 0.01]} scale={[healthPercent, 1, 1]}>
          <planeGeometry args={[2, 0.2]} />
          <meshBasicMaterial color={healthBarColor} />
        </mesh>
      </group>
      
      <Text
        position={[0, size * (enemy.isBoss ? 1.8 : 1.2) + 0.5, 0]}
        fontSize={enemy.isBoss ? 0.6 : 0.3}
        color="white"
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.03}
        outlineColor="black"
      >
        {enemy.name}
      </Text>
      
      {enemy.isBoss && (
        <Text
          position={[0, size * 1.4, 0]}
          fontSize={0.4}
          color="#FFD700"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.02}
          outlineColor="black"
        >
          {`${enemy.hp}/${enemy.maxHp}`}
        </Text>
      )}
    </group>
  );
}
