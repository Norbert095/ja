import { useRef, useEffect, useState, useCallback, useMemo } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { KeyboardControls, PointerLockControls, Sky, Stars, Text } from "@react-three/drei";
import * as THREE from "three";
import { useGameStore, CubeType, Enemy as EnemyType, CubeItem, WallItem } from "@/lib/stores/useGameStore";
import { useAudio } from "@/lib/stores/useAudio";
import { ISLAND_DATA, getRandomCubeType, getGridPosition, CUBE_COLORS, ENEMY_TYPES, BOSS_DATA, generateWeapon } from "@/lib/gameData";
import { startAutoSave, stopAutoSave } from "@/lib/stores/useGameStore";

enum Controls {
  forward = "forward",
  backward = "backward",
  left = "left",
  right = "right",
  jump = "jump",
}

export const playerKeyMap = [
  { name: Controls.forward, keys: ["KeyW", "ArrowUp"] },
  { name: Controls.backward, keys: ["KeyS", "ArrowDown"] },
  { name: Controls.left, keys: ["KeyA", "ArrowLeft"] },
  { name: Controls.right, keys: ["KeyD", "ArrowRight"] },
  { name: Controls.jump, keys: ["Space"] },
];

function Lights() {
  return (
    <>
      <ambientLight intensity={0.4} />
      <directionalLight
        position={[50, 100, 50]}
        intensity={1}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-far={200}
        shadow-camera-left={-100}
        shadow-camera-right={100}
        shadow-camera-top={100}
        shadow-camera-bottom={-100}
      />
      <pointLight position={[0, 50, 0]} intensity={0.5} color="#FFE4B5" />
    </>
  );
}

function Ground() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -50, 0]} receiveShadow>
      <planeGeometry args={[1000, 1000]} />
      <meshStandardMaterial color="#1a1a2e" transparent opacity={0.8} />
    </mesh>
  );
}

const keysPressed = { forward: false, backward: false, left: false, right: false, jump: false };
let lastPickupTime = 0;
let lastAttackTime = 0;

function PlayerController() {
  const { camera } = useThree();
  const controlsRef = useRef<any>(null);
  const velocityRef = useRef(new THREE.Vector3());
  const isGroundedRef = useRef(true);
  const canJumpRef = useRef(true);
  const worldCubesRef = useRef<CubeItem[]>([]);
  const worldEnemiesRef = useRef<EnemyType[]>([]);
  
  const { updatePlayerPosition, phase, takeDamage, currentSlot, damageEnemy, worldEnemies, worldCubes, pickupCube, equipWeapon, placeWall, unequipWall, damageWall } = useGameStore();
  const { playHit } = useAudio();
  
  worldCubesRef.current = worldCubes;
  worldEnemiesRef.current = worldEnemies;
  
  const MOVE_SPEED = 8;
  const JUMP_FORCE = 8;
  const GRAVITY = 20;
  const GROUND_LEVEL = 1.6;
  
  const handleKeyPress = useCallback((e: KeyboardEvent) => {
    if (e.code === "KeyE") {
      const now = Date.now();
      if (now - lastPickupTime < 200) return;
      lastPickupTime = now;
      
      if (currentSlot?.equippedWall) {
        const forwardDist = 3;
        const forward = new THREE.Vector3(0, 0, -1).applyAxisAngle(new THREE.Vector3(0, 1, 0), camera.rotation.order === 'YXZ' ? -camera.rotation.y : 0);
        const wallPos: [number, number, number] = [
          camera.position.x + forward.x * forwardDist,
          0.5,
          camera.position.z + forward.z * forwardDist
        ];
        placeWall({ ...currentSlot.equippedWall, position: wallPos });
        unequipWall();
        return;
      }
      
      const playerPos = camera.position;
      let closestCube: CubeItem | null = null;
      let closestDist = 5;
      
      worldCubesRef.current.forEach(cube => {
        const dx = cube.position[0] - playerPos.x;
        const dz = cube.position[2] - playerPos.z;
        const distance = Math.sqrt(dx * dx + dz * dz);
        
        if (distance < closestDist) {
          closestDist = distance;
          closestCube = cube;
        }
      });
      
      if (closestCube) {
        pickupCube(closestCube.id);
      }
    }
  }, [camera, pickupCube, currentSlot, placeWall, unequipWall]);
  
  const handleClick = useCallback((e: MouseEvent) => {
    if (phase !== "playing" && phase !== "sandbox") return;
    
    const now = Date.now();
    if (now - lastAttackTime < 100) return;
    lastAttackTime = now;
    
    const target = e.target as HTMLElement;
    if (target && (target.tagName !== 'CANVAS')) return;
    
    if (currentSlot?.equippedWeapon) {
      const attackRange = 2.5;
      const playerPos = camera.position;
      
      worldEnemiesRef.current.forEach(enemy => {
        const dx = enemy.position[0] - playerPos.x;
        const dz = enemy.position[2] - playerPos.z;
        const distance = Math.sqrt(dx * dx + dz * dz);
        
        if (distance < attackRange) {
          damageEnemy(enemy.id, currentSlot.equippedWeapon!.damage);
          playHit();
        }
      });
    } else {
      const attackRange = 1.5;
      worldEnemiesRef.current.forEach(enemy => {
        const dx = enemy.position[0] - camera.position.x;
        const dz = enemy.position[2] - camera.position.z;
        const distance = Math.sqrt(dx * dx + dz * dz);
        
        if (distance < attackRange) {
          damageEnemy(enemy.id, 5);
          playHit();
        }
      });
    }
  }, [phase, currentSlot, camera, damageEnemy, playHit]);
  
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.code;
      if (["KeyW", "ArrowUp"].includes(key)) keysPressed.forward = true;
      if (["KeyS", "ArrowDown"].includes(key)) keysPressed.backward = true;
      if (["KeyA", "ArrowLeft"].includes(key)) keysPressed.left = true;
      if (["KeyD", "ArrowRight"].includes(key)) keysPressed.right = true;
      if (key === "Space") keysPressed.jump = true;
      
      // Number keys to equip weapons
      if (["Digit1", "Digit2", "Digit3", "Digit4"].includes(key)) {
        const slotIndex = parseInt(key.replace("Digit", "")) - 1;
        const weapon = (currentSlot?.weapons || [])[slotIndex];
        if (weapon) {
          equipWeapon(weapon);
        }
      }
    };
    
    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.code;
      if (["KeyW", "ArrowUp"].includes(key)) keysPressed.forward = false;
      if (["KeyS", "ArrowDown"].includes(key)) keysPressed.backward = false;
      if (["KeyA", "ArrowLeft"].includes(key)) keysPressed.left = false;
      if (["KeyD", "ArrowRight"].includes(key)) keysPressed.right = false;
      if (key === "Space") keysPressed.jump = false;
    };
    
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    window.addEventListener("click", handleClick);
    window.addEventListener("keydown", handleKeyPress);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
      window.removeEventListener("click", handleClick);
      window.removeEventListener("keydown", handleKeyPress);
    };
  }, [handleKeyPress, handleClick, currentSlot, equipWeapon]);
  
  const worldWallsRef = useRef<WallItem[]>([]);
  worldWallsRef.current = currentSlot?.placedWalls || [];
  
  useFrame((_, delta) => {
    if (phase !== "playing" && phase !== "sandbox") return;
    if (!controlsRef.current?.isLocked) return;
    
    const velocity = velocityRef.current;
    
    velocity.x -= velocity.x * 10.0 * delta;
    velocity.z -= velocity.z * 10.0 * delta;
    
    if (!isGroundedRef.current) {
      velocity.y -= GRAVITY * delta;
    }
    
    const direction = new THREE.Vector3();
    direction.z = Number(keysPressed.forward) - Number(keysPressed.backward);
    direction.x = Number(keysPressed.right) - Number(keysPressed.left);
    direction.normalize();
    
    if (keysPressed.forward || keysPressed.backward) {
      velocity.z -= direction.z * MOVE_SPEED * delta * 10;
    }
    if (keysPressed.left || keysPressed.right) {
      velocity.x -= direction.x * MOVE_SPEED * delta * 10;
    }
    
    if (keysPressed.jump && isGroundedRef.current && canJumpRef.current) {
      velocity.y = JUMP_FORCE;
      isGroundedRef.current = false;
      canJumpRef.current = false;
      setTimeout(() => { canJumpRef.current = true; }, 300);
    }
    
    const moveRight = new THREE.Vector3();
    const moveForward = new THREE.Vector3();
    
    camera.getWorldDirection(moveForward);
    moveForward.y = 0;
    moveForward.normalize();
    
    moveRight.crossVectors(camera.up, moveForward).normalize();
    
    camera.position.addScaledVector(moveRight, velocity.x * delta);
    camera.position.addScaledVector(moveForward, -velocity.z * delta);
    camera.position.y += velocity.y * delta;
    
    for (const wall of worldWallsRef.current) {
      const dx = camera.position.x - wall.position[0];
      const dz = camera.position.z - wall.position[2];
      const distance = Math.sqrt(dx * dx + dz * dz);
      const collision_radius = 0.8;
      
      if (distance < collision_radius && distance > 0) {
        const angle = Math.atan2(dz, dx);
        camera.position.x = wall.position[0] + Math.cos(angle) * collision_radius;
        camera.position.z = wall.position[2] + Math.sin(angle) * collision_radius;
      }
    }
    
    if (camera.position.y < GROUND_LEVEL) {
      camera.position.y = GROUND_LEVEL;
      velocity.y = 0;
      isGroundedRef.current = true;
    }
    
    camera.position.x = Math.max(-300, Math.min(300, camera.position.x));
    camera.position.z = Math.max(-300, Math.min(300, camera.position.z));
    
    updatePlayerPosition([camera.position.x, camera.position.y, camera.position.z]);
  });
  
  if (phase !== "playing" && phase !== "sandbox") return null;
  
  return <PointerLockControls ref={controlsRef} makeDefault onLock={() => {}} onUnlock={() => {}} />;
}

interface CubeEntityProps {
  cube: CubeItem;
  onClick: () => void;
}

function CubeEntity({ cube, onClick }: CubeEntityProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  
  const color = CUBE_COLORS[cube.type];
  
  useFrame((state) => {
    if (!meshRef.current) return;
    meshRef.current.rotation.y += 0.01;
    meshRef.current.position.y = cube.position[1] + Math.sin(state.clock.elapsedTime * 2 + cube.id.charCodeAt(0)) * 0.15;
  });
  
  return (
    <mesh
      ref={meshRef}
      position={[cube.position[0], cube.position[1], cube.position[2]]}
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
      castShadow
      scale={hovered ? 1.2 : 1}
    >
      <boxGeometry args={[0.8, 0.8, 0.8]} />
      <meshStandardMaterial 
        color={color}
        emissive={color}
        emissiveIntensity={hovered ? 0.5 : 0.2}
        metalness={0.3}
        roughness={0.4}
      />
    </mesh>
  );
}

interface WallEntityProps {
  wall: WallItem;
  playerPosition: [number, number, number];
  onDamage: (wallId: string, damage: number) => void;
}

function WallEntity({ wall, playerPosition, onDamage }: WallEntityProps) {
  const meshRef = useRef<THREE.Group>(null);
  const { damageWall } = useGameStore();
  const healthPercent = wall.hp / wall.maxHp;
  
  useFrame(() => {
    if (!meshRef.current) return;
    const dx = playerPosition[0] - wall.position[0];
    const dz = playerPosition[2] - wall.position[2];
    const distance = Math.sqrt(dx * dx + dz * dz);
    if (distance < 2.5) {
      onDamage(wall.id, 0);
    }
  });
  
  return (
    <group ref={meshRef} position={wall.position}>
      <mesh castShadow receiveShadow onClick={() => onDamage(wall.id, 10)}>
        <boxGeometry args={[1, 2, 0.2]} />
        <meshStandardMaterial 
          color={["#8B4513", "#696969", "#A8A8A8", "#00FFFF", "#1A0A2E", "#FF69B4"][wall.tier - 1]}
          emissive={["#8B4513", "#696969", "#A8A8A8", "#00FFFF", "#1A0A2E", "#FF69B4"][wall.tier - 1]}
          emissiveIntensity={0.2}
        />
      </mesh>
      
      <group position={[0, 1.3, 0.1]}>
        <mesh>
          <planeGeometry args={[1.2, 0.15]} />
          <meshBasicMaterial color="#333333" />
        </mesh>
        <mesh position={[(healthPercent - 1) * 0.6, 0, 0.01]} scale={[healthPercent, 1, 1]}>
          <planeGeometry args={[1.2, 0.15]} />
          <meshBasicMaterial color={healthPercent > 0.5 ? "#00FF00" : healthPercent > 0.25 ? "#FFFF00" : "#FF0000"} />
        </mesh>
      </group>
      
      <Text
        position={[0, 2.2, 0.1]}
        fontSize={0.2}
        color="white"
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.02}
        outlineColor="black"
      >
        {wall.name}
      </Text>
    </group>
  );
}

interface EnemyEntityProps {
  enemy: EnemyType;
  playerPosition: [number, number, number];
}

function EnemyEntity({ enemy, playerPosition }: EnemyEntityProps) {
  const meshRef = useRef<THREE.Group>(null);
  const { takeDamage, damageEnemy } = useGameStore();
  const lastAttackRef = useRef(0);
  
  const enemyData = ENEMY_TYPES.find(e => e.type === enemy.type);
  const color = enemy.isBoss 
    ? (BOSS_DATA.find(b => b.index === enemy.bossIndex)?.color || "#FF0000")
    : (enemyData?.color || "#FF0000");
  
  const size = enemy.isBoss ? 3 : 1;
  
  useFrame((state) => {
    if (!meshRef.current) return;
    
    const dx = playerPosition[0] - enemy.position[0];
    const dz = playerPosition[2] - enemy.position[2];
    const distance = Math.sqrt(dx * dx + dz * dz);
    
    const aggroRange = enemy.isBoss ? 30 : 15;
    const attackRange = enemy.isBoss ? 4 : 2;
    
    if (distance < aggroRange && distance > attackRange) {
      const moveSpeed = enemy.isBoss ? 2 : 3;
      const moveX = (dx / distance) * moveSpeed * 0.016;
      const moveZ = (dz / distance) * moveSpeed * 0.016;
      
      meshRef.current.position.x += moveX;
      meshRef.current.position.z += moveZ;
      enemy.position[0] += moveX;
      enemy.position[2] += moveZ;
    }
    
    if (distance < attackRange) {
      const currentTime = state.clock.elapsedTime;
      const attackCooldown = enemy.isBoss ? 2 : 1.5;
      
      if (currentTime - lastAttackRef.current > attackCooldown) {
        takeDamage(enemy.damage);
        lastAttackRef.current = currentTime;
      }
    }
    
    meshRef.current.lookAt(playerPosition[0], meshRef.current.position.y, playerPosition[2]);
    
    if (enemy.isBoss) {
      meshRef.current.position.y = size / 2 + Math.sin(state.clock.elapsedTime * 2) * 0.2;
    }
  });
  
  const healthPercent = enemy.hp / enemy.maxHp;
  
  return (
    <group ref={meshRef} position={[enemy.position[0], size / 2, enemy.position[2]]}>
      <mesh castShadow onClick={() => damageEnemy(enemy.id, 10)}>
        <boxGeometry args={[size, size * 1.2, size]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.2} />
      </mesh>
      
      <group position={[0, size * 0.8 + 0.5, 0]}>
        <mesh>
          <planeGeometry args={[2, 0.2]} />
          <meshBasicMaterial color="#333333" />
        </mesh>
        <mesh position={[(healthPercent - 1), 0, 0.01]} scale={[healthPercent, 1, 1]}>
          <planeGeometry args={[2, 0.2]} />
          <meshBasicMaterial color={healthPercent > 0.5 ? "#00FF00" : healthPercent > 0.25 ? "#FFFF00" : "#FF0000"} />
        </mesh>
      </group>
      
      <Text
        position={[0, size * 1.2, 0]}
        fontSize={0.3}
        color="white"
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.02}
        outlineColor="black"
      >
        {enemy.name}
      </Text>
    </group>
  );
}

interface IslandEntityProps {
  island: typeof ISLAND_DATA[0];
  crystalHp?: number;
  position?: [number, number, number];
}

function IslandEntity({ island, crystalHp, position }: IslandEntityProps) {
  const islandPosition = position || island.position;
  const crystalRef = useRef<THREE.Mesh>(null);
  
  const trees = useMemo(() => {
    const treeData: Array<{ x: number; z: number; height: number }> = [];
    const numTrees = Math.floor(island.size * 0.3);
    
    for (let i = 0; i < numTrees; i++) {
      const angle = (i / numTrees) * Math.PI * 2 + Math.random() * 0.5;
      const radius = (island.size * 0.3) + Math.random() * (island.size * 0.35);
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      
      if (island.hasCrystal && Math.sqrt(x * x + z * z) < 8) continue;
      
      treeData.push({ x, z, height: 2 + Math.random() * 2 });
    }
    return treeData;
  }, [island]);
  
  useFrame((state) => {
    if (crystalRef.current && island.hasCrystal) {
      crystalRef.current.rotation.y += 0.015;
      crystalRef.current.position.y = 3 + Math.sin(state.clock.elapsedTime * 2) * 0.3;
    }
  });
  
  const crystalHealthPercent = (crystalHp || 5000) / 5000;
  const crystalColor = crystalHealthPercent > 0.5 ? "#00FF88" : crystalHealthPercent > 0.25 ? "#FFFF00" : "#FF4444";
  
  return (
    <group position={islandPosition}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[island.size, 32]} />
        <meshStandardMaterial color={island.color} />
      </mesh>
      
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, 0]}>
        <circleGeometry args={[island.size + 2, 32]} />
        <meshStandardMaterial color="#654321" />
      </mesh>
      
      {trees.map((tree, i) => (
        <group key={i} position={[tree.x, 0, tree.z]}>
          <mesh position={[0, tree.height / 2, 0]} castShadow>
            <cylinderGeometry args={[0.15, 0.25, tree.height, 8]} />
            <meshStandardMaterial color="#8B4513" />
          </mesh>
          <mesh position={[0, tree.height + 0.8, 0]} castShadow>
            <coneGeometry args={[1.5, 2.5, 8]} />
            <meshStandardMaterial color="#228B22" />
          </mesh>
        </group>
      ))}
      
      {island.hasCrystal && (
        <group position={[0, 0, 0]}>
          <mesh position={[0, 0.5, 0]}>
            <cylinderGeometry args={[3, 4, 1, 6]} />
            <meshStandardMaterial color="#555555" />
          </mesh>
          
          <mesh ref={crystalRef} position={[0, 3, 0]} castShadow>
            <octahedronGeometry args={[2, 0]} />
            <meshStandardMaterial 
              color={crystalColor}
              emissive={crystalColor}
              emissiveIntensity={0.5}
              transparent
              opacity={0.9}
            />
          </mesh>
          
          <pointLight position={[0, 3, 0]} color={crystalColor} intensity={2} distance={20} />
          
          <Text
            position={[0, 6, 0]}
            fontSize={0.6}
            color="white"
            anchorX="center"
            anchorY="middle"
            outlineWidth={0.04}
            outlineColor="black"
          >
            {`Crystal: ${crystalHp || 5000}/5000`}
          </Text>
        </group>
      )}
      
      <Text
        position={[0, 0.5, -island.size - 2]}
        fontSize={1}
        color="white"
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.06}
        outlineColor="black"
      >
        {island.name}
      </Text>
    </group>
  );
}

function WeaponDisplay() {
  const { currentSlot } = useGameStore();
  const { camera } = useThree();
  const groupRef = useRef<THREE.Group>(null);
  const [isSwinging, setIsSwinging] = useState(false);
  
  useEffect(() => {
    const handleClick = () => {
      if (currentSlot?.equippedWeapon) {
        setIsSwinging(true);
        setTimeout(() => setIsSwinging(false), 200);
      }
    };
    window.addEventListener("click", handleClick);
    return () => window.removeEventListener("click", handleClick);
  }, [currentSlot]);
  
  useFrame(() => {
    if (!groupRef.current || !currentSlot?.equippedWeapon) return;
    
    groupRef.current.position.copy(camera.position);
    groupRef.current.quaternion.copy(camera.quaternion);
    
    groupRef.current.translateX(0.3);
    groupRef.current.translateY(-0.25);
    groupRef.current.translateZ(-0.5);
    
    if (isSwinging) {
      groupRef.current.rotateX(-0.5);
    }
  });
  
  if (!currentSlot?.equippedWeapon) return null;
  
  const weapon = currentSlot.equippedWeapon;
  const length = weapon.category === "greatsword" ? 1.2 : weapon.category === "sword" ? 0.7 : 0.4;
  
  const tierColors: Record<number, string> = {
    1: "#8B4513", 2: "#808080", 3: "#A8A8A8", 4: "#00BFFF", 5: "#1A0A2E", 6: "#FF1493", 7: "#FFD700"
  };
  const color = tierColors[weapon.tier] || "#808080";
  
  return (
    <group ref={groupRef}>
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[0.06, 0.1, 0.03]} />
        <meshStandardMaterial color="#5C4033" />
      </mesh>
      <mesh position={[0, 0, length / 2 + 0.02]}>
        <boxGeometry args={[0.08, 0.02, length]} />
        <meshStandardMaterial color={color} metalness={0.7} roughness={0.3} />
      </mesh>
    </group>
  );
}

function GameWorld() {
  const { 
    currentSlot, 
    worldCubes, 
    worldEnemies,
    spawnCube,
    addCubeToInventory,
    pickupCube,
    playerPosition,
    spawnEnemy,
    damageWall,
    renderDistance
  } = useGameStore();
  
  const lastSpawnTime = useRef<Record<number, number>>({});
  const enemiesSpawnedRef = useRef(false);
  
  useEffect(() => {
    ISLAND_DATA.forEach(island => {
      if (!lastSpawnTime.current[island.id]) {
        lastSpawnTime.current[island.id] = Date.now();
      }
    });
    
    const interval = setInterval(() => {
      const now = Date.now();
      
      ISLAND_DATA.forEach(island => {
        if (now - lastSpawnTime.current[island.id] > island.cubeSpawnRate) {
          lastSpawnTime.current[island.id] = now;
          
          const cubeType = getRandomCubeType();
          const angle = Math.random() * Math.PI * 2;
          const radius = Math.random() * (island.size * 0.4);
          const x = island.position[0] + Math.cos(angle) * radius;
          const z = island.position[2] + Math.sin(angle) * radius;
          
          if (island.hasCrystal && Math.sqrt(Math.pow(x - island.position[0], 2) + Math.pow(z - island.position[2], 2)) < 5) {
            return;
          }
          
          spawnCube(cubeType, [x, 0.5, z]);
        }
      });
    }, 1000);
    
    return () => clearInterval(interval);
  }, [spawnCube]);
  
  useEffect(() => {
    if (!enemiesSpawnedRef.current && currentSlot) {
      enemiesSpawnedRef.current = true;
      
      ISLAND_DATA.forEach(island => {
        if (island.bosses && island.bosses.length > 0) {
          const bossIndex = island.bosses[0];
          const bossData = BOSS_DATA[bossIndex];
          
          if (bossData && !currentSlot.defeatedBosses.includes(bossIndex)) {
            spawnEnemy({
              name: bossData.name,
              hp: bossData.hp,
              maxHp: bossData.hp,
              damage: bossData.damage,
              position: [island.position[0], 0, island.position[2]],
              type: "golem" as const,
              isAggro: true,
              isBoss: true,
              bossIndex: bossIndex,
              drops: [
                { type: "coins" as const, amount: 100 + bossIndex * 50 },
                generateWeapon("greatsword", Math.min(6, Math.floor(bossIndex / 2) + 1), true, bossData.name)
              ],
            });
          }
        }
        
        if (island.enemies && island.enemies.length > 0) {
          island.enemies.forEach(enemyType => {
            const enemyData = ENEMY_TYPES.find(e => e.type === enemyType);
            if (enemyData) {
              for (let i = 0; i < 1; i++) {
                const angle = Math.random() * Math.PI * 2;
                const radius = island.size * 0.3 + Math.random() * (island.size * 0.3);
                const x = island.position[0] + Math.cos(angle) * radius;
                const z = island.position[2] + Math.sin(angle) * radius;
                
                spawnEnemy({
                  name: enemyData.name,
                  hp: enemyData.hp,
                  maxHp: enemyData.hp,
                  damage: enemyData.damage,
                  position: [x, 0, z],
                  type: enemyData.type,
                  isAggro: false,
                  isBoss: false,
                  drops: [{ type: "coins", amount: enemyData.coinDrop[0] + Math.floor(Math.random() * (enemyData.coinDrop[1] - enemyData.coinDrop[0])) }],
                });
              }
            }
          });
        }
      });
    }
  }, [currentSlot, spawnEnemy]);
  
  const handleCubeClick = useCallback((cube: CubeItem) => {
    addCubeToInventory(cube.type, 1);
    pickupCube(cube.id);
  }, [addCubeToInventory, pickupCube]);
  
  // Culling helper - only render entities within view distance
  const isInViewDistance = useCallback((pos: [number, number, number], distance = 300) => {
    const dx = pos[0] - playerPosition[0];
    const dz = pos[2] - playerPosition[2];
    return Math.sqrt(dx * dx + dz * dz) < distance;
  }, [playerPosition]);
  
  // Apply world type positioning
  const getIslandPosition = useCallback((island: typeof ISLAND_DATA[0]) => {
    if (currentSlot?.worldType === "grid") {
      return getGridPosition(island.id);
    }
    return island.position;
  }, [currentSlot?.worldType]);
  
  const visibleCubes = useMemo(() => worldCubes.filter(c => isInViewDistance(c.position, renderDistance * 0.67)), [worldCubes, isInViewDistance, renderDistance]);
  const visibleEnemies = useMemo(() => worldEnemies.filter(e => isInViewDistance(e.position, renderDistance)), [worldEnemies, isInViewDistance, renderDistance]);
  const visibleWalls = useMemo(() => currentSlot?.placedWalls.filter(w => isInViewDistance(w.position, renderDistance * 0.83)) || [], [currentSlot?.placedWalls, isInViewDistance, renderDistance]);
  const visibleIslands = useMemo(() => ISLAND_DATA.filter(i => isInViewDistance(getIslandPosition(i), renderDistance * 1.33)), [isInViewDistance, renderDistance, currentSlot?.worldType, getIslandPosition]);
  
  return (
    <>
      <Lights />
      <Sky sunPosition={[100, 50, 100]} />
      <Stars radius={300} depth={50} count={1000} factor={4} />
      <Ground />
      <fog attach="fog" args={["#1a1a2e", 100, 250]} />
      
      {visibleIslands.map(island => (
        <IslandEntity 
          key={island.id} 
          island={island}
          crystalHp={island.hasCrystal ? currentSlot?.crystalHp : undefined}
          position={getIslandPosition(island)}
        />
      ))}
      
      {visibleCubes.map(cube => (
        <CubeEntity
          key={cube.id}
          cube={cube}
          onClick={() => handleCubeClick(cube)}
        />
      ))}
      
      {visibleEnemies.map(enemy => (
        <EnemyEntity
          key={enemy.id}
          enemy={enemy}
          playerPosition={playerPosition}
        />
      ))}
      
      {visibleWalls.map(wall => (
        <WallEntity
          key={wall.id}
          wall={wall}
          playerPosition={playerPosition}
          onDamage={damageWall}
        />
      ))}
      
      <PlayerController />
      <WeaponDisplay />
    </>
  );
}

interface GameSceneProps {
  menuOpen?: boolean;
}

export function GameScene({ menuOpen = false }: GameSceneProps) {
  const { phase, currentSlot } = useGameStore();
  const canvasRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (phase === "playing" || phase === "sandbox") {
      startAutoSave();
    } else {
      stopAutoSave();
    }
    return () => stopAutoSave();
  }, [phase]);
  
  useEffect(() => {
    if (menuOpen) {
      try {
        if (document.pointerLockElement) {
          document.exitPointerLock();
        }
      } catch (e) {
        // Silently ignore pointer lock errors
      }
    }
  }, [menuOpen]);
  
  if (phase !== "playing" && phase !== "sandbox") return null;
  if (!currentSlot) return null;
  
  return (
    <div className="fixed inset-0" ref={canvasRef} onContextMenu={(e) => e.preventDefault()}>
      <KeyboardControls map={playerKeyMap}>
        <Canvas
          shadows
          camera={{
            position: [0, 1.6, 5],
            fov: 75,
            near: 0.1,
            far: 1000
          }}
          gl={{
            antialias: true,
            powerPreference: "default"
          }}
          onClick={(e) => {
            if (menuOpen) {
              if (document.pointerLockElement) {
                document.exitPointerLock();
              }
              return;
            }
            const canvas = e.currentTarget as HTMLCanvasElement;
            if (canvas && !document.pointerLockElement) {
              canvas.requestPointerLock?.();
            }
          }}
        >
          <color attach="background" args={["#0a0a1a"]} />
          <GameWorld />
        </Canvas>
      </KeyboardControls>
    </div>
  );
}
