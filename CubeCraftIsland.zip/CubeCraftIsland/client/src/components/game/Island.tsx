import { useRef, useMemo } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";

interface IslandProps {
  position: [number, number, number];
  size: number;
  color: string;
  name: string;
  hasCrystal?: boolean;
  crystalHp?: number;
  crystalMaxHp?: number;
}

export function Island({ 
  position, 
  size, 
  color, 
  name, 
  hasCrystal = false,
  crystalHp = 5000,
  crystalMaxHp = 5000 
}: IslandProps) {
  const crystalRef = useRef<THREE.Mesh>(null);
  
  const trees = useMemo(() => {
    const treeData: Array<{ x: number; z: number; height: number; trunkColor: string; leafColor: string }> = [];
    const numTrees = Math.floor(size * 0.3);
    
    for (let i = 0; i < numTrees; i++) {
      const angle = (i / numTrees) * Math.PI * 2 + Math.random() * 0.5;
      const radius = (size * 0.3) + Math.random() * (size * 0.35);
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      
      if (hasCrystal && Math.sqrt(x * x + z * z) < 8) continue;
      
      treeData.push({
        x,
        z,
        height: 2 + Math.random() * 2,
        trunkColor: "#8B4513",
        leafColor: "#228B22",
      });
    }
    
    return treeData;
  }, [size, hasCrystal]);
  
  const rocks = useMemo(() => {
    const rockData: Array<{ x: number; z: number; scale: number }> = [];
    const numRocks = Math.floor(size * 0.2);
    
    for (let i = 0; i < numRocks; i++) {
      const angle = Math.random() * Math.PI * 2;
      const radius = Math.random() * (size * 0.45);
      
      rockData.push({
        x: Math.cos(angle) * radius,
        z: Math.sin(angle) * radius,
        scale: 0.3 + Math.random() * 0.5,
      });
    }
    
    return rockData;
  }, [size]);
  
  useFrame((state) => {
    if (crystalRef.current && hasCrystal) {
      crystalRef.current.rotation.y += 0.01;
      crystalRef.current.position.y = 3 + Math.sin(state.clock.elapsedTime * 2) * 0.2;
    }
  });
  
  const crystalHealthPercent = crystalHp / crystalMaxHp;
  const crystalColor = crystalHealthPercent > 0.5 
    ? "#00FF88" 
    : crystalHealthPercent > 0.25 
      ? "#FFFF00" 
      : "#FF4444";
  
  return (
    <group position={position}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[size, 32]} />
        <meshStandardMaterial color={color} />
      </mesh>
      
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, 0]}>
        <circleGeometry args={[size + 2, 32]} />
        <meshStandardMaterial color="#654321" />
      </mesh>
      
      {trees.map((tree, i) => (
        <group key={`tree-${i}`} position={[tree.x, 0, tree.z]}>
          <mesh position={[0, tree.height / 2, 0]} castShadow>
            <cylinderGeometry args={[0.15, 0.25, tree.height, 8]} />
            <meshStandardMaterial color={tree.trunkColor} />
          </mesh>
          <mesh position={[0, tree.height + 0.8, 0]} castShadow>
            <coneGeometry args={[1.5, 2.5, 8]} />
            <meshStandardMaterial color={tree.leafColor} />
          </mesh>
        </group>
      ))}
      
      {rocks.map((rock, i) => (
        <mesh 
          key={`rock-${i}`} 
          position={[rock.x, rock.scale * 0.5, rock.z]}
          castShadow
        >
          <dodecahedronGeometry args={[rock.scale, 0]} />
          <meshStandardMaterial color="#888888" roughness={0.9} />
        </mesh>
      ))}
      
      {hasCrystal && (
        <group position={[0, 0, 0]}>
          <mesh position={[0, 0.5, 0]}>
            <cylinderGeometry args={[3, 4, 1, 6]} />
            <meshStandardMaterial color="#555555" />
          </mesh>
          
          <mesh ref={crystalRef} position={[0, 3, 0]} castShadow>
            <octahedronGeometry args={[2, 0]} />
            <meshStandardMaterial 
              color={crystalColor}
              emissive={crystalColor}
              emissiveIntensity={0.5}
              transparent
              opacity={0.9}
            />
          </mesh>
          
          <pointLight 
            position={[0, 3, 0]} 
            color={crystalColor} 
            intensity={2} 
            distance={20} 
          />
          
          <Text
            position={[0, 6, 0]}
            fontSize={0.8}
            color="white"
            anchorX="center"
            anchorY="middle"
            outlineWidth={0.05}
            outlineColor="black"
          >
            {`Crystal HP: ${crystalHp}/${crystalMaxHp}`}
          </Text>
        </group>
      )}
      
      <Text
        position={[0, 0.5, -size - 2]}
        fontSize={1.2}
        color="white"
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.08}
        outlineColor="black"
      >
        {name}
      </Text>
    </group>
  );
}
