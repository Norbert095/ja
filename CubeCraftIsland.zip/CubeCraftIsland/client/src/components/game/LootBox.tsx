import { useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { Text } from "@react-three/drei";

interface LootBoxProps {
  id: string;
  position: [number, number, number];
  isOpen: boolean;
  onOpen: () => void;
}

export function LootBox({ id, position, isOpen, onOpen }: LootBoxProps) {
  const boxRef = useRef<THREE.Group>(null);
  const lidRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const [openProgress, setOpenProgress] = useState(0);
  const [particles, setParticles] = useState<Array<{ x: number; y: number; z: number; vx: number; vy: number; vz: number }>>([]);
  
  useFrame((state, delta) => {
    if (!boxRef.current) return;
    
    if (!isOpen && hovered) {
      boxRef.current.rotation.y += 0.02;
    }
    
    if (isOpen && openProgress < 1) {
      setOpenProgress(prev => Math.min(1, prev + delta * 2));
      
      if (openProgress < 0.1 && particles.length === 0) {
        const newParticles = Array.from({ length: 20 }, () => ({
          x: 0,
          y: 0.5,
          z: 0,
          vx: (Math.random() - 0.5) * 3,
          vy: Math.random() * 5 + 2,
          vz: (Math.random() - 0.5) * 3,
        }));
        setParticles(newParticles);
      }
    }
    
    if (lidRef.current && isOpen) {
      lidRef.current.rotation.x = -openProgress * Math.PI * 0.7;
    }
    
    if (particles.length > 0) {
      setParticles(prevParticles => 
        prevParticles.map(p => ({
          ...p,
          x: p.x + p.vx * delta,
          y: p.y + p.vy * delta - 9.8 * delta * delta,
          z: p.z + p.vz * delta,
          vy: p.vy - 9.8 * delta,
        })).filter(p => p.y > -1)
      );
    }
  });
  
  const boxColor = isOpen ? "#8B4513" : "#DAA520";
  const glowColor = "#FFD700";
  
  return (
    <group ref={boxRef} position={position}>
      <mesh 
        position={[0, 0.4, 0]}
        onClick={(e) => {
          e.stopPropagation();
          if (!isOpen) onOpen();
        }}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        castShadow
      >
        <boxGeometry args={[1.2, 0.8, 0.8]} />
        <meshStandardMaterial 
          color={boxColor}
          metalness={0.3}
          roughness={0.6}
        />
      </mesh>
      
      <mesh position={[0, 0.35, -0.35]}>
        <boxGeometry args={[0.3, 0.2, 0.1]} />
        <meshStandardMaterial color="#C0C0C0" metalness={0.8} roughness={0.2} />
      </mesh>
      
      <mesh 
        ref={lidRef}
        position={[0, 0.8, 0.35]}
        castShadow
      >
        <boxGeometry args={[1.2, 0.15, 0.8]} />
        <meshStandardMaterial 
          color={boxColor}
          metalness={0.3}
          roughness={0.6}
        />
      </mesh>
      
      {!isOpen && (
        <pointLight 
          position={[0, 1, 0]} 
          color={glowColor} 
          intensity={hovered ? 2 : 1} 
          distance={5} 
        />
      )}
      
      {isOpen && openProgress > 0.5 && (
        <pointLight 
          position={[0, 1, 0]} 
          color="#FFFFFF" 
          intensity={3 * (1 - openProgress + 0.5)} 
          distance={8} 
        />
      )}
      
      {particles.map((p, i) => (
        <mesh key={i} position={[p.x, p.y, p.z]}>
          <sphereGeometry args={[0.05, 8, 8]} />
          <meshBasicMaterial color={glowColor} />
        </mesh>
      ))}
      
      {!isOpen && hovered && (
        <Text
          position={[0, 1.5, 0]}
          fontSize={0.3}
          color="#FFD700"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.02}
          outlineColor="black"
        >
          Press E to Open
        </Text>
      )}
      
      {isOpen && (
        <Text
          position={[0, 1.2, 0]}
          fontSize={0.25}
          color="#888888"
          anchorX="center"
          anchorY="middle"
        >
          Empty
        </Text>
      )}
    </group>
  );
}
