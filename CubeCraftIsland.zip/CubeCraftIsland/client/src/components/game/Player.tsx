import { useRef, useEffect, useCallback } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { useKeyboardControls, PointerLockControls } from "@react-three/drei";
import * as THREE from "three";
import { useGameStore } from "@/lib/stores/useGameStore";
import { getSpeedMultiplier } from "@/lib/mods/speedDemonMod";
import { isGodModeActive } from "@/lib/mods/godModeMod";

enum Controls {
  forward = "forward",
  backward = "backward",
  left = "left",
  right = "right",
  jump = "jump",
  attack = "attack",
  interact = "interact",
}

interface PlayerProps {
  onAttack?: () => void;
  onInteract?: (target: THREE.Object3D | null) => void;
}

export function Player({ onAttack, onInteract }: PlayerProps) {
  const { camera } = useThree();
  const controlsRef = useRef<any>(null);
  const velocityRef = useRef(new THREE.Vector3());
  const directionRef = useRef(new THREE.Vector3());
  const isGroundedRef = useRef(true);
  const canJumpRef = useRef(true);
  const mobileInputRef = useRef({ forward: 0, right: 0 });
  
  const { updatePlayerPosition, playerPosition, phase, currentSlot } = useGameStore();
  
  const [, getKeys] = useKeyboardControls<Controls>();
  
  const speedMult = getSpeedMultiplier(currentSlot?.enabledMods || []) * (isGodModeActive(currentSlot?.enabledMods || []) ? 3 : 1);
  const MOVE_SPEED = 8 * speedMult;
  const JUMP_FORCE = 8;
  const GRAVITY = 20;
  const GROUND_LEVEL = 1.6;
  
  useEffect(() => {
    camera.position.set(playerPosition[0], playerPosition[1], playerPosition[2]);
  }, []);
  
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (phase !== "playing" && phase !== "sandbox") return;
    
    if (e.code === "KeyE" && onInteract) {
      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
      onInteract(null);
    }
    
    if (e.code === "Mouse0" || e.code === "KeyJ") {
      if (onAttack) onAttack();
    }
  }, [camera, onAttack, onInteract, phase]);
  
  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);
  
  const handleClick = useCallback(() => {
    if (phase !== "playing" && phase !== "sandbox") return;
    if (onAttack) onAttack();
  }, [onAttack, phase]);
  
  useEffect(() => {
    window.addEventListener("click", handleClick);
    return () => window.removeEventListener("click", handleClick);
  }, [handleClick]);
  
  useFrame((_, delta) => {
    if (phase !== "playing" && phase !== "sandbox") return;
    if (!controlsRef.current?.isLocked) return;
    
    const keys = getKeys();
    const velocity = velocityRef.current;
    const direction = directionRef.current;
    
    // Combine keyboard and mobile input
    const isMobile = window.innerWidth < 768;
    let forwardInput = Number(keys.forward) - Number(keys.backward);
    let rightInput = Number(keys.right) - Number(keys.left);
    
    if (isMobile) {
      forwardInput += mobileInputRef.current.forward;
      rightInput += mobileInputRef.current.right;
    }
    
    velocity.x -= velocity.x * 10.0 * delta;
    velocity.z -= velocity.z * 10.0 * delta;
    
    if (!isGroundedRef.current) {
      velocity.y -= GRAVITY * delta;
    }
    
    direction.z = forwardInput;
    direction.x = rightInput;
    if (direction.length() > 0) {
      direction.normalize();
    }
    
    if (forwardInput !== 0) {
      velocity.z -= direction.z * MOVE_SPEED * delta * 10;
    }
    if (rightInput !== 0) {
      velocity.x -= direction.x * MOVE_SPEED * delta * 10;
    }
    
    if (keys.jump && isGroundedRef.current && canJumpRef.current) {
      velocity.y = JUMP_FORCE;
      isGroundedRef.current = false;
      canJumpRef.current = false;
      setTimeout(() => {
        canJumpRef.current = true;
      }, 300);
    }
    
    const moveRight = new THREE.Vector3();
    const moveForward = new THREE.Vector3();
    
    camera.getWorldDirection(moveForward);
    moveForward.y = 0;
    moveForward.normalize();
    
    moveRight.crossVectors(camera.up, moveForward).normalize();
    
    camera.position.addScaledVector(moveRight, velocity.x * delta);
    camera.position.addScaledVector(moveForward, -velocity.z * delta);
    camera.position.y += velocity.y * delta;
    
    if (camera.position.y < GROUND_LEVEL) {
      camera.position.y = GROUND_LEVEL;
      velocity.y = 0;
      isGroundedRef.current = true;
    }
    
    const minBound = -200;
    const maxBound = 200;
    camera.position.x = Math.max(minBound, Math.min(maxBound, camera.position.x));
    camera.position.z = Math.max(minBound, Math.min(maxBound, camera.position.z));
    
    updatePlayerPosition([camera.position.x, camera.position.y, camera.position.z]);
  });
  
  if (phase !== "playing" && phase !== "sandbox") return null;
  
  return (
    <PointerLockControls
      ref={controlsRef}
      makeDefault
    />
  );
}

export const playerKeyMap = [
  { name: Controls.forward, keys: ["KeyW", "ArrowUp"] },
  { name: Controls.backward, keys: ["KeyS", "ArrowDown"] },
  { name: Controls.left, keys: ["KeyA", "ArrowLeft"] },
  { name: Controls.right, keys: ["KeyD", "ArrowRight"] },
  { name: Controls.jump, keys: ["Space"] },
  { name: Controls.attack, keys: ["KeyJ"] },
  { name: Controls.interact, keys: ["KeyE"] },
];
