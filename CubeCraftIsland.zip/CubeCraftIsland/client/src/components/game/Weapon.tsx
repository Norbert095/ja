import { useRef, useState, useEffect } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { WeaponItem, WeaponCategory } from "@/lib/stores/useGameStore";

interface WeaponProps {
  weapon: WeaponItem;
  isAttacking?: boolean;
}

const WEAPON_SIZES: Record<WeaponCategory, { length: number; width: number; height: number }> = {
  dagger: { length: 0.4, width: 0.08, height: 0.02 },
  sword: { length: 0.8, width: 0.1, height: 0.02 },
  greatsword: { length: 1.4, width: 0.15, height: 0.03 },
};

const TIER_COLORS: Record<number, string> = {
  1: "#8B4513",
  2: "#808080",
  3: "#A8A8A8",
  4: "#00BFFF",
  5: "#1A0A2E",
  6: "#FF1493",
  7: "#FFD700",
};

export function FirstPersonWeapon({ weapon, isAttacking }: WeaponProps) {
  const groupRef = useRef<THREE.Group>(null);
  const { camera } = useThree();
  const [attackProgress, setAttackProgress] = useState(0);
  
  const size = WEAPON_SIZES[weapon.category];
  const color = TIER_COLORS[weapon.tier] || "#808080";
  
  useEffect(() => {
    if (isAttacking) {
      setAttackProgress(0);
    }
  }, [isAttacking]);
  
  useFrame((state, delta) => {
    if (!groupRef.current) return;
    
    const basePosition = new THREE.Vector3(0.4, -0.3, -0.6);
    const baseRotation = new THREE.Euler(-0.2, 0.3, 0.1);
    
    if (isAttacking && attackProgress < 1) {
      setAttackProgress(prev => Math.min(1, prev + delta * weapon.attackSpeed * 3));
      
      const swingPhase = Math.sin(attackProgress * Math.PI);
      basePosition.z -= swingPhase * 0.3;
      basePosition.x += swingPhase * 0.1;
      baseRotation.x -= swingPhase * 0.8;
      baseRotation.z -= swingPhase * 0.3;
    } else {
      const bobAmount = Math.sin(state.clock.elapsedTime * 2) * 0.02;
      basePosition.y += bobAmount;
    }
    
    groupRef.current.position.copy(basePosition);
    groupRef.current.rotation.copy(baseRotation);
    
    groupRef.current.position.applyMatrix4(camera.matrixWorld);
    groupRef.current.quaternion.copy(camera.quaternion);
    groupRef.current.rotateX(baseRotation.x);
    groupRef.current.rotateY(baseRotation.y);
    groupRef.current.rotateZ(baseRotation.z);
  });
  
  return (
    <group ref={groupRef}>
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[0.08, 0.12, 0.04]} />
        <meshStandardMaterial color="#5C4033" roughness={0.8} />
      </mesh>
      
      <mesh position={[0, 0, 0.02]}>
        <boxGeometry args={[0.12, 0.02, 0.01]} />
        <meshStandardMaterial color="#C0C0C0" metalness={0.8} roughness={0.3} />
      </mesh>
      
      <mesh position={[0, 0, size.length / 2 + 0.02]}>
        <boxGeometry args={[size.width, size.height, size.length]} />
        <meshStandardMaterial 
          color={color}
          metalness={0.7}
          roughness={0.3}
          emissive={color}
          emissiveIntensity={weapon.tier > 4 ? 0.3 : 0}
        />
      </mesh>
      
      {weapon.tier > 4 && (
        <pointLight 
          position={[0, 0, size.length / 2]} 
          color={color} 
          intensity={0.5} 
          distance={2} 
        />
      )}
    </group>
  );
}

interface DroppedWeaponProps {
  weapon: WeaponItem;
  position: [number, number, number];
  onClick?: () => void;
}

export function DroppedWeapon({ weapon, position, onClick }: DroppedWeaponProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  
  const size = WEAPON_SIZES[weapon.category];
  const color = TIER_COLORS[weapon.tier] || "#808080";
  
  useFrame((state) => {
    if (!meshRef.current) return;
    
    meshRef.current.rotation.y += 0.02;
    meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 2) * 0.1;
  });
  
  return (
    <mesh
      ref={meshRef}
      position={position}
      onClick={(e) => {
        e.stopPropagation();
        if (onClick) onClick();
      }}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
      castShadow
    >
      <boxGeometry args={[size.width * 2, size.height * 2, size.length]} />
      <meshStandardMaterial 
        color={color}
        metalness={0.7}
        roughness={0.3}
        emissive={color}
        emissiveIntensity={hovered ? 0.5 : 0.2}
      />
    </mesh>
  );
}
