import { useState } from "react";
import { useGameStore, CubeType, WeaponCategory, ArmorSlot, WallItem } from "@/lib/stores/useGameStore";
import { 
  CRAFTING_RECIPES, 
  CUBE_COLORS, 
  CUBE_NAMES,
  generateWeapon,
  generateArmor,
  WALL_TYPES 
} from "@/lib/gameData";
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./tabs";
import { X, Sword, Shield, Hammer, Heart, Package, ChevronRight } from "lucide-react";

interface CraftingUIProps {
  onClose: () => void;
}

type CraftingCategory = "weapons" | "armor" | "walls" | "special";

export function CraftingUI({ onClose }: CraftingUIProps) {
  const { currentSlot, removeCubeFromInventory, equipWeapon, equipArmor, addLifeCube, upgradeInventory } = useGameStore();
  const [selectedCategory, setSelectedCategory] = useState<CraftingCategory>("weapons");
  const [craftingResult, setCraftingResult] = useState<string | null>(null);
  
  if (!currentSlot) return null;
  
  const canCraft = (cubeType: CubeType, amount: number): boolean => {
    return currentSlot.cubes[cubeType] >= amount;
  };
  
  const getInventoryUsed = (): number => {
    return (currentSlot.weapons?.length || 0);
  };
  
  const craftWeapon = (category: WeaponCategory, tier: number, cubeType: CubeType, cubesRequired: number) => {
    if (!canCraft(cubeType, cubesRequired)) return;
    if (getInventoryUsed() + 1 > currentSlot.inventorySlots) {
      setCraftingResult("Inventory full!");
      setTimeout(() => setCraftingResult(null), 2000);
      return;
    }
    
    if (removeCubeFromInventory(cubeType, cubesRequired)) {
      const weapon = generateWeapon(category, tier);
      const newWeapons = [...(currentSlot.weapons || []), weapon];
      // Manually update - we'll need to add addWeaponToInventory method
      useGameStore.setState(state => ({
        currentSlot: state.currentSlot ? { ...state.currentSlot, weapons: newWeapons } : null
      }));
      setCraftingResult(`Crafted ${weapon.name}!`);
      setTimeout(() => setCraftingResult(null), 2000);
    }
  };
  
  const craftArmor = (slot: ArmorSlot, tier: number, cubeType: CubeType, cubesRequired: number) => {
    if (!canCraft(cubeType, cubesRequired)) return;
    
    if (removeCubeFromInventory(cubeType, cubesRequired)) {
      const armor = generateArmor(slot, tier);
      equipArmor(armor);
      setCraftingResult(`Crafted ${armor.name}!`);
      setTimeout(() => setCraftingResult(null), 2000);
    }
  };
  
  const craftWall = (tier: number, cubeType: CubeType, cubesRequired: number) => {
    if (!canCraft(cubeType, cubesRequired)) return;
    
    if (removeCubeFromInventory(cubeType, cubesRequired)) {
      const wallData = WALL_TYPES.find(w => w.tier === tier);
      if (wallData) {
        const wall: WallItem = {
          id: `wall_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          tier,
          name: wallData.name,
          hp: wallData.hp,
          maxHp: wallData.hp,
          position: [0, 0, 0],
          rotation: 0,
        };
        const newWalls = [...(currentSlot.walls || []), wall];
        useGameStore.setState(state => ({
          currentSlot: state.currentSlot ? { 
            ...state.currentSlot, 
            walls: newWalls,
            equippedWall: wall
          } : null,
        }));
        setCraftingResult(`Crafted ${wallData.name}! Press E to place it.`);
        setTimeout(() => setCraftingResult(null), 2000);
      }
    }
  };
  
  const craftLifeCube = () => {
    const recipe = CRAFTING_RECIPES.lifeCube;
    if (!canCraft(recipe.cubeType, recipe.cubesRequired)) return;
    
    if (removeCubeFromInventory(recipe.cubeType, recipe.cubesRequired)) {
      addLifeCube();
      setCraftingResult("Crafted Life Cube!");
      setTimeout(() => setCraftingResult(null), 2000);
    }
  };
  
  const craftInventoryUpgrade = () => {
    if (upgradeInventory()) {
      setCraftingResult("Inventory upgraded!");
      setTimeout(() => setCraftingResult(null), 2000);
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <Card className="max-w-4xl w-full max-h-[90vh] overflow-hidden bg-gray-900 border-purple-500">
        <CardHeader className="flex flex-row items-center justify-between border-b border-gray-700">
          <CardTitle className="text-2xl text-white flex items-center gap-2">
            <Hammer className="h-6 w-6 text-orange-400" />
            Crafting
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </CardHeader>
        
        <div className="p-4 border-b border-gray-700 flex gap-2 flex-wrap">
          <span className="text-gray-400 mr-2">Materials:</span>
          {(Object.entries(currentSlot.cubes) as [CubeType, number][]).map(([type, count]) => (
            <div 
              key={type}
              className="flex items-center gap-1 bg-gray-800 rounded px-2 py-1"
            >
              <div 
                className="w-4 h-4 rounded"
                style={{ backgroundColor: CUBE_COLORS[type] }}
              />
              <span className="text-white text-sm">{count}</span>
            </div>
          ))}
        </div>
        
        {craftingResult && (
          <div className="p-3 bg-green-600 text-white text-center font-bold">
            {craftingResult}
          </div>
        )}
        
        <Tabs value={selectedCategory} onValueChange={(v) => setSelectedCategory(v as CraftingCategory)}>
          <TabsList className="w-full justify-start bg-gray-800 p-1 rounded-none">
            <TabsTrigger value="weapons" className="flex items-center gap-1">
              <Sword className="h-4 w-4" />
              Weapons
            </TabsTrigger>
            <TabsTrigger value="armor" className="flex items-center gap-1">
              <Shield className="h-4 w-4" />
              Armor
            </TabsTrigger>
            <TabsTrigger value="walls" className="flex items-center gap-1">
              <Hammer className="h-4 w-4" />
              Walls
            </TabsTrigger>
            <TabsTrigger value="special" className="flex items-center gap-1">
              <Heart className="h-4 w-4" />
              Special
            </TabsTrigger>
          </TabsList>
          
          <CardContent className="overflow-y-auto max-h-[50vh] p-4">
            <TabsContent value="weapons" className="mt-0 space-y-2">
              {CRAFTING_RECIPES.weapons.map((recipe, i) => (
                <div 
                  key={i}
                  className={`p-3 rounded-lg border ${
                    canCraft(recipe.cubeType, recipe.cubesRequired)
                      ? "bg-gray-800 border-gray-600 hover:border-purple-500 cursor-pointer"
                      : "bg-gray-800/50 border-gray-700 opacity-50"
                  }`}
                  onClick={() => craftWeapon(recipe.category, recipe.tier, recipe.cubeType, recipe.cubesRequired)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Sword className="h-5 w-5 text-orange-400" />
                      <span className="text-white font-medium">{recipe.result}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-5 h-5 rounded"
                        style={{ backgroundColor: CUBE_COLORS[recipe.cubeType] }}
                      />
                      <span className="text-gray-300">x{recipe.cubesRequired}</span>
                      <ChevronRight className="h-4 w-4 text-gray-500" />
                    </div>
                  </div>
                </div>
              ))}
              <div className="border-t border-gray-700 pt-3 mt-3">
                <h4 className="text-sm font-bold text-purple-400 mb-2">⭐ Advanced Weapons</h4>
                {CRAFTING_RECIPES.advancedWeapons.map((recipe, i) => (
                  <div 
                    key={`adv_${i}`}
                    className={`p-3 rounded-lg border mb-2 ${
                      canCraft(recipe.cubeType, recipe.cubesRequired)
                        ? "bg-purple-900/30 border-purple-500 hover:border-purple-400 cursor-pointer"
                        : "bg-gray-800/50 border-gray-700 opacity-50"
                    }`}
                    onClick={() => craftWeapon(recipe.category, recipe.tier, recipe.cubeType, recipe.cubesRequired)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Sword className="h-5 w-5 text-purple-400" />
                        <span className="text-white font-medium">{recipe.result}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-5 h-5 rounded"
                          style={{ backgroundColor: CUBE_COLORS[recipe.cubeType] }}
                        />
                        <span className="text-gray-300">x{recipe.cubesRequired}</span>
                        <ChevronRight className="h-4 w-4 text-gray-500" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="border-t border-gray-700 pt-3 mt-3">
                <h4 className="text-sm font-bold text-pink-400 mb-2">🌟 Legendary Weapons</h4>
                {CRAFTING_RECIPES.legendaryWeapons.map((recipe, i) => (
                  <div 
                    key={`leg_${i}`}
                    className={`p-3 rounded-lg border mb-2 ${
                      canCraft(recipe.cubeType, recipe.cubesRequired)
                        ? "bg-pink-900/30 border-pink-500 hover:border-pink-400 cursor-pointer"
                        : "bg-gray-800/50 border-gray-700 opacity-50"
                    }`}
                    onClick={() => craftWeapon(recipe.category, recipe.tier, recipe.cubeType, recipe.cubesRequired)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Sword className="h-5 w-5 text-pink-400" />
                        <span className="text-white font-medium">{recipe.result}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-5 h-5 rounded"
                          style={{ backgroundColor: CUBE_COLORS[recipe.cubeType] }}
                        />
                        <span className="text-gray-300">x{recipe.cubesRequired}</span>
                        <ChevronRight className="h-4 w-4 text-gray-500" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="armor" className="mt-0 space-y-2">
              {CRAFTING_RECIPES.armor.map((recipe, i) => (
                <div 
                  key={i}
                  className={`p-3 rounded-lg border ${
                    canCraft(recipe.cubeType, recipe.cubesRequired)
                      ? "bg-gray-800 border-gray-600 hover:border-purple-500 cursor-pointer"
                      : "bg-gray-800/50 border-gray-700 opacity-50"
                  }`}
                  onClick={() => craftArmor(recipe.slot, recipe.tier, recipe.cubeType, recipe.cubesRequired)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Shield className="h-5 w-5 text-blue-400" />
                      <span className="text-white font-medium">{recipe.result}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-5 h-5 rounded"
                        style={{ backgroundColor: CUBE_COLORS[recipe.cubeType] }}
                      />
                      <span className="text-gray-300">x{recipe.cubesRequired}</span>
                      <ChevronRight className="h-4 w-4 text-gray-500" />
                    </div>
                  </div>
                </div>
              ))}
              <div className="border-t border-gray-700 pt-3 mt-3">
                <h4 className="text-sm font-bold text-purple-400 mb-2">⭐ Advanced Armor</h4>
                {CRAFTING_RECIPES.advancedArmor.map((recipe, i) => (
                  <div 
                    key={`adv_${i}`}
                    className={`p-3 rounded-lg border mb-2 ${
                      canCraft(recipe.cubeType, recipe.cubesRequired)
                        ? "bg-purple-900/30 border-purple-500 hover:border-purple-400 cursor-pointer"
                        : "bg-gray-800/50 border-gray-700 opacity-50"
                    }`}
                    onClick={() => craftArmor(recipe.slot, recipe.tier, recipe.cubeType, recipe.cubesRequired)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Shield className="h-5 w-5 text-purple-400" />
                        <span className="text-white font-medium">{recipe.result}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-5 h-5 rounded"
                          style={{ backgroundColor: CUBE_COLORS[recipe.cubeType] }}
                        />
                        <span className="text-gray-300">x{recipe.cubesRequired}</span>
                        <ChevronRight className="h-4 w-4 text-gray-500" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="border-t border-gray-700 pt-3 mt-3">
                <h4 className="text-sm font-bold text-pink-400 mb-2">🌟 Legendary Armor</h4>
                {CRAFTING_RECIPES.legendaryArmor.map((recipe, i) => (
                  <div 
                    key={`leg_${i}`}
                    className={`p-3 rounded-lg border mb-2 ${
                      canCraft(recipe.cubeType, recipe.cubesRequired)
                        ? "bg-pink-900/30 border-pink-500 hover:border-pink-400 cursor-pointer"
                        : "bg-gray-800/50 border-gray-700 opacity-50"
                    }`}
                    onClick={() => craftArmor(recipe.slot, recipe.tier, recipe.cubeType, recipe.cubesRequired)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Shield className="h-5 w-5 text-pink-400" />
                        <span className="text-white font-medium">{recipe.result}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-5 h-5 rounded"
                          style={{ backgroundColor: CUBE_COLORS[recipe.cubeType] }}
                        />
                        <span className="text-gray-300">x{recipe.cubesRequired}</span>
                        <ChevronRight className="h-4 w-4 text-gray-500" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="walls" className="mt-0 space-y-2">
              {CRAFTING_RECIPES.walls.map((recipe, i) => (
                <div 
                  key={i}
                  className={`p-3 rounded-lg border ${
                    canCraft(recipe.cubeType, recipe.cubesRequired)
                      ? "bg-gray-800 border-gray-600 hover:border-purple-500 cursor-pointer"
                      : "bg-gray-800/50 border-gray-700 opacity-50"
                  }`}
                  onClick={() => craftWall(recipe.tier, recipe.cubeType, recipe.cubesRequired)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Hammer className="h-5 w-5 text-yellow-400" />
                      <div>
                        <span className="text-white font-medium">{recipe.result}</span>
                        <span className="text-gray-400 text-sm ml-2">({recipe.hp} HP)</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-5 h-5 rounded"
                        style={{ backgroundColor: CUBE_COLORS[recipe.cubeType] }}
                      />
                      <span className="text-gray-300">x{recipe.cubesRequired}</span>
                      <ChevronRight className="h-4 w-4 text-gray-500" />
                    </div>
                  </div>
                </div>
              ))}
            </TabsContent>
            
            <TabsContent value="special" className="mt-0 space-y-4">
              <div 
                className={`p-4 rounded-lg border ${
                  canCraft(CRAFTING_RECIPES.lifeCube.cubeType, CRAFTING_RECIPES.lifeCube.cubesRequired)
                    ? "bg-pink-900/30 border-pink-500 hover:bg-pink-900/50 cursor-pointer"
                    : "bg-gray-800/50 border-gray-700 opacity-50"
                }`}
                onClick={craftLifeCube}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Heart className="h-6 w-6 text-pink-400" />
                    <div>
                      <span className="text-white font-bold">Life Cube</span>
                      <p className="text-pink-300 text-sm">Prevents death once (like Totem of Undying)</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-5 h-5 rounded"
                      style={{ backgroundColor: CUBE_COLORS[CRAFTING_RECIPES.lifeCube.cubeType] }}
                    />
                    <span className="text-gray-300">x{CRAFTING_RECIPES.lifeCube.cubesRequired}</span>
                  </div>
                </div>
              </div>
              
              {currentSlot.inventorySlots < 4 && (
                <div className="border-t border-gray-700 pt-4">
                  <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                    <Package className="h-5 w-5 text-green-400" />
                    Inventory Upgrades
                  </h3>
                  {CRAFTING_RECIPES.inventoryUpgrades
                    .filter(u => u.fromSlots === currentSlot.inventorySlots)
                    .map((upgrade, i) => (
                      <div 
                        key={i}
                        className={`p-4 rounded-lg border ${
                          canCraft(upgrade.cubeType, upgrade.cubesRequired)
                            ? "bg-green-900/30 border-green-500 hover:bg-green-900/50 cursor-pointer"
                            : "bg-gray-800/50 border-gray-700 opacity-50"
                        }`}
                        onClick={craftInventoryUpgrade}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-white font-bold">{upgrade.result}</span>
                            <p className="text-green-300 text-sm">
                              Upgrade inventory to {upgrade.toSlots} slots
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <div 
                              className="w-5 h-5 rounded"
                              style={{ backgroundColor: CUBE_COLORS[upgrade.cubeType] }}
                            />
                            <span className="text-gray-300">x{upgrade.cubesRequired}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </TabsContent>
          </CardContent>
        </Tabs>
        
        <div className="p-4 border-t border-gray-700 text-center text-gray-400 text-sm">
          Tip: You can also drop cubes in the world to combine them!
        </div>
      </Card>
    </div>
  );
}
