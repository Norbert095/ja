import { useEffect, useState, useRef } from "react";
import { useGameStore } from "@/lib/stores/useGameStore";
import { CUBE_COLORS, CUBE_NAMES, CUBE_ICONS } from "@/lib/gameData";
import { Heart, Shield, Coins, Package, Swords, ChevronUp, Settings, Pause, Zap } from "lucide-react";
import { Button } from "./button";
import { Progress } from "./progress";

interface GameHUDProps {
  onPause?: () => void;
  onOpenInventory?: () => void;
  onOpenCrafting?: () => void;
}

export function GameHUD({ onPause, onOpenInventory, onOpenCrafting }: GameHUDProps) {
  const { 
    playerHp, 
    maxPlayerHp, 
    currentSlot,
    phase,
    heldItem,
    equipWeapon,
    equipWall
  } = useGameStore();
  
  const [showControls, setShowControls] = useState(true);
  const [fps, setFps] = useState(0);
  const fpsRef = useRef(0);
  const frameCountRef = useRef(0);
  const lastTimeRef = useRef(Date.now());
  
  useEffect(() => {
    const timer = setTimeout(() => setShowControls(false), 10000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const fpsInterval = setInterval(() => {
      setFps(fpsRef.current);
      fpsRef.current = 0;
    }, 1000);

    const animationFrameId = setInterval(() => {
      const now = Date.now();
      const deltaTime = now - lastTimeRef.current;
      
      if (deltaTime > 0) {
        const currentFps = Math.round(1000 / (deltaTime / frameCountRef.current || 1));
        fpsRef.current = Math.min(currentFps, 120);
      }
      
      frameCountRef.current = 0;
      lastTimeRef.current = now;
    }, 100);

    const measureFrame = () => {
      frameCountRef.current++;
      requestAnimationFrame(measureFrame);
    };
    measureFrame();

    return () => {
      clearInterval(fpsInterval);
      clearInterval(animationFrameId);
    };
  }, []);
  
  if (phase !== "playing" && phase !== "sandbox") return null;
  
  const healthPercent = (playerHp / maxPlayerHp) * 100;
  const healthColor = healthPercent > 50 ? "bg-green-500" : healthPercent > 25 ? "bg-yellow-500" : "bg-red-500";
  
  const totalDefense = currentSlot 
    ? Object.values(currentSlot.equippedArmor)
        .filter(Boolean)
        .reduce((sum, armor) => sum + (armor?.defense || 0), 0)
    : 0;
  
  return (
    <div className="fixed inset-0 pointer-events-none z-40">
      <div className="absolute top-4 left-4 pointer-events-auto space-y-2">
        <div className="bg-black/70 rounded-lg p-3 flex items-center gap-2">
          <Zap className="h-5 w-5 text-green-400" />
          <span className="text-green-400 font-bold">{fps} FPS</span>
        </div>
        
        <div className="bg-black/70 rounded-lg p-3 min-w-[200px]">
          <div className="flex items-center gap-2 mb-1">
            <Heart className="h-5 w-5 text-red-500" />
            <span className="text-white font-bold">{playerHp} / {maxPlayerHp}</span>
          </div>
          <div className="h-3 bg-gray-700 rounded-full overflow-hidden">
            <div 
              className={`h-full ${healthColor} transition-all duration-300`}
              style={{ width: `${healthPercent}%` }}
            />
          </div>
        </div>
        
        {totalDefense > 0 && (
          <div className="bg-black/70 rounded-lg p-3 flex items-center gap-2">
            <Shield className="h-5 w-5 text-cyan-400" />
            <span className="text-cyan-400 font-bold">{totalDefense} Defense</span>
          </div>
        )}
        
        <div className="bg-black/70 rounded-lg p-3 flex items-center gap-2">
          <Coins className="h-5 w-5 text-yellow-400" />
          <span className="text-yellow-400 font-bold">{currentSlot?.coins || 0}</span>
        </div>
        
        {currentSlot && currentSlot.lifeCubes > 0 && (
          <div className="bg-black/70 rounded-lg p-3 flex items-center gap-2">
            <Heart className="h-5 w-5 text-pink-400" />
            <span className="text-pink-400 font-bold">{currentSlot.lifeCubes} Life Cubes</span>
          </div>
        )}
      </div>
      
      <div className="absolute top-4 right-4 pointer-events-auto flex gap-2">
        <Button 
          size="sm" 
          variant="ghost" 
          className="bg-black/70 text-white hover:bg-black/90"
          onClick={onOpenInventory}
        >
          <Package className="h-5 w-5" />
        </Button>
        <Button 
          size="sm" 
          variant="ghost" 
          className="bg-black/70 text-white hover:bg-black/90"
          onClick={onOpenCrafting}
        >
          <Swords className="h-5 w-5" />
        </Button>
        <Button 
          size="sm" 
          variant="ghost" 
          className="bg-black/70 text-white hover:bg-black/90"
          onClick={onPause}
        >
          <Pause className="h-5 w-5" />
        </Button>
      </div>
      
      {currentSlot && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-black/70 rounded-lg p-2 px-4">
          <div className="flex items-center gap-4 text-sm">
            {(Object.entries(currentSlot.cubes) as [keyof typeof CUBE_COLORS, number][])
              .filter(([_, count]) => count > 0)
              .map(([type, count]) => (
                <div key={type} className="flex items-center gap-1">
                  <span className="text-lg">{CUBE_ICONS[type]}</span>
                  <span className="text-white">{count}</span>
                </div>
              ))}
          </div>
        </div>
      )}
      
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        {heldItem && (
          <div className="bg-black/70 rounded-lg p-2 px-4 text-white">
            Holding: {
              "type" in heldItem && ["common", "uncommon", "rare", "epic", "legendary", "mythic"].includes(heldItem.type as string)
                ? CUBE_NAMES[heldItem.type as keyof typeof CUBE_NAMES]
                : "name" in heldItem 
                  ? heldItem.name 
                  : "Item"
            }
          </div>
        )}
        
        <div className="bg-black/70 rounded-lg p-3 flex items-center gap-4">
          <div className="flex flex-col items-center">
            <span className="text-gray-400 text-xs">Weapon</span>
            <div className="w-12 h-12 bg-gray-800 rounded border border-gray-600 flex items-center justify-center">
              {currentSlot?.equippedWeapon ? (
                <Swords className="h-6 w-6 text-orange-400" />
              ) : (
                <span className="text-gray-600 text-2xl">-</span>
              )}
            </div>
          </div>
          
          <div className="flex gap-1">
            {Array.from({ length: currentSlot?.inventorySlots || 1 }).map((_, i) => {
              const weapon = (currentSlot?.weapons || [])[i];
              const wall = (currentSlot?.walls || [])[i];
              const item = weapon || wall;
              const isEquipped = currentSlot?.equippedWeapon?.id === weapon?.id || currentSlot?.equippedWall?.id === wall?.id;
              return (
                <div 
                  key={i}
                  onClick={() => {
                    if (weapon) equipWeapon(weapon);
                    else if (wall) equipWall(wall);
                  }}
                  className={`w-10 h-10 rounded border flex items-center justify-center text-xs font-bold cursor-pointer transition-all ${
                    isEquipped
                      ? wall
                        ? "bg-blue-900/60 border-blue-500 hover:bg-blue-800 text-blue-400"
                        : "bg-orange-900/60 border-orange-500 hover:bg-orange-800 text-orange-400"
                      : item
                      ? (wall ? "bg-slate-900/60 border-slate-500 hover:bg-slate-800 text-slate-400" : "bg-orange-900/60 border-orange-500 hover:bg-orange-800 text-orange-400")
                      : "bg-gray-800 border-gray-600 text-gray-600"
                  }`}
                  title={item?.name || "Empty"}
                >
                  {i + 1}
                </div>
              );
            })}
          </div>
          
          <div className="flex flex-col items-center">
            <span className="text-gray-400 text-xs">Offhand</span>
            <div className="w-12 h-12 bg-gray-800 rounded border border-gray-600 flex items-center justify-center">
              {currentSlot?.offhandItem ? (
                <Shield className="h-6 w-6 text-blue-400" />
              ) : (
                <span className="text-gray-600 text-2xl">-</span>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-6 h-6 relative">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-0.5 h-4 bg-white/70" />
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-4 h-0.5 bg-white/70" />
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-1 h-1 bg-red-500 rounded-full" />
          </div>
        </div>
      </div>
      
      {showControls && (
        <div className="absolute bottom-4 right-4 bg-black/70 rounded-lg p-4 text-sm text-gray-300 pointer-events-auto">
          <div className="flex items-center gap-2 mb-2">
            <Settings className="h-4 w-4" />
            <span className="text-white font-bold">Controls</span>
            <Button 
              size="sm" 
              variant="ghost" 
              className="ml-auto h-6 px-2"
              onClick={() => setShowControls(false)}
            >
              Hide
            </Button>
          </div>
          <div className="space-y-1">
            <p><span className="text-white">WASD</span> - Move</p>
            <p><span className="text-white">Mouse</span> - Look</p>
            <p><span className="text-white">Space</span> - Jump</p>
            <p><span className="text-white">Click</span> - Attack</p>
            <p><span className="text-white">E</span> - Interact</p>
            <p><span className="text-white">Tab</span> - Inventory</p>
          </div>
        </div>
      )}
    </div>
  );
}
