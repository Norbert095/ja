import { useGameStore } from "@/lib/stores/useGameStore";
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Skull, RotateCcw, Home, Coins, Heart } from "lucide-react";

export function GameOver() {
  const { currentSlot, setPhase, respawn, reviveCrystal } = useGameStore();
  
  const isCrystalDestroyed = currentSlot?.crystalHp === 0;
  const canReviveCrystal = currentSlot && currentSlot.coins >= currentSlot.crystalReviveCost;
  
  const handleRevive = () => {
    if (isCrystalDestroyed) {
      if (reviveCrystal()) {
        respawn();
      }
    } else {
      respawn();
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              width: `${2 + Math.random() * 4}px`,
              height: `${2 + Math.random() * 4}px`,
              backgroundColor: "#ff0000",
              borderRadius: "50%",
              opacity: 0.3,
            }}
          />
        ))}
      </div>
      
      <Card className="w-96 bg-gradient-to-b from-red-900/90 to-gray-900/95 border-red-500">
        <CardHeader className="text-center">
          <div className="mx-auto w-20 h-20 bg-red-900 rounded-full flex items-center justify-center mb-4 animate-pulse">
            <Skull className="h-12 w-12 text-red-500" />
          </div>
          <CardTitle className="text-4xl text-red-500">
            {isCrystalDestroyed ? "CRYSTAL DESTROYED" : "YOU DIED"}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {isCrystalDestroyed ? (
            <div className="text-center text-gray-300 space-y-2">
              <p>The Crystal of Life has been destroyed!</p>
              <p className="text-yellow-400">
                Revive it for <span className="font-bold">{currentSlot?.crystalReviveCost}</span> coins
              </p>
              {currentSlot && (
                <p className="text-sm text-gray-400">
                  Your coins: {currentSlot.coins}
                </p>
              )}
            </div>
          ) : (
            <div className="text-center text-gray-300">
              <p>You have fallen in battle.</p>
              <p className="text-sm text-gray-400 mt-2">
                Tip: Craft Life Cubes to prevent death!
              </p>
            </div>
          )}
          
          {isCrystalDestroyed ? (
            <>
              <Button 
                className="w-full py-6 text-lg bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
                disabled={!canReviveCrystal}
                onClick={handleRevive}
              >
                <Heart className="mr-2 h-5 w-5" />
                Revive Crystal ({currentSlot?.crystalReviveCost} coins)
              </Button>
              {!canReviveCrystal && (
                <p className="text-center text-red-400 text-sm">
                  Not enough coins to revive!
                </p>
              )}
            </>
          ) : (
            <Button 
              className="w-full py-6 text-lg bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
              onClick={handleRevive}
            >
              <RotateCcw className="mr-2 h-5 w-5" />
              Respawn
            </Button>
          )}
          
          <Button 
            variant="outline"
            className="w-full py-5 border-gray-600 text-gray-400 hover:bg-gray-800"
            onClick={() => setPhase("menu")}
          >
            <Home className="mr-2 h-5 w-5" />
            Return to Menu
          </Button>
          
          {currentSlot && (
            <div className="pt-4 border-t border-gray-700 text-center space-y-1">
              <p className="text-gray-400 text-sm">
                World: <span className="text-white">{currentSlot.name}</span>
              </p>
              <p className="text-gray-400 text-sm">
                Bosses Defeated: <span className="text-white">{currentSlot.defeatedBosses.length}/8</span>
              </p>
              <p className="text-gray-400 text-sm flex items-center justify-center gap-1">
                <Coins className="h-4 w-4 text-yellow-400" />
                <span className="text-yellow-400">{currentSlot.coins}</span>
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
