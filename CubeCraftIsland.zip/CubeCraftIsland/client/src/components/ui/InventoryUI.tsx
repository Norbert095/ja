import { useGameStore, WeaponItem, ArmorItem, ArmorSlot } from "@/lib/stores/useGameStore";
import { CUBE_COLORS, CUBE_NAMES } from "@/lib/gameData";
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { X, Sword, Shield, Heart, Package, Trash2 } from "lucide-react";

interface InventoryUIProps {
  onClose: () => void;
}

export function InventoryUI({ onClose }: InventoryUIProps) {
  const { 
    currentSlot, 
    equipWeapon, 
    equipArmor, 
    unequipWeapon, 
    unequipArmor 
  } = useGameStore();
  
  if (!currentSlot) return null;
  
  const armorSlots: ArmorSlot[] = ["helmet", "chestplate", "leggings"];
  
  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <Card className="max-w-3xl w-full max-h-[90vh] overflow-hidden bg-gray-900 border-purple-500">
        <CardHeader className="flex flex-row items-center justify-between border-b border-gray-700">
          <CardTitle className="text-2xl text-white flex items-center gap-2">
            <Package className="h-6 w-6 text-green-400" />
            Inventory
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </CardHeader>
        
        <CardContent className="p-4 overflow-y-auto max-h-[70vh]">
          <div className="mb-6">
            <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
              <Package className="h-5 w-5 text-green-400" />
              Inventory Slots
            </h3>
            <div className="grid grid-cols-5 gap-2 mb-4">
              {Array.from({ length: currentSlot.inventorySlots }).map((_, slotIndex) => {
                const weapon = (currentSlot.weapons || [])[slotIndex];
                return (
                  <div 
                    key={slotIndex}
                    className={`aspect-square rounded-lg border-2 flex flex-col items-center justify-center p-2 text-center text-xs ${
                      weapon 
                        ? "bg-orange-900/40 border-orange-500 hover:bg-orange-900/60 cursor-pointer"
                        : "bg-gray-800 border-gray-700"
                    }`}
                    onClick={() => weapon && equipWeapon(weapon)}
                  >
                    {weapon ? (
                      <>
                        <Sword className="h-4 w-4 text-orange-400 mb-1" />
                        <div className="text-white font-bold text-xs">{weapon.damage}dmg</div>
                      </>
                    ) : (
                      <div className="text-gray-500">Empty</div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-gradient-to-r from-gray-400 via-blue-400 to-purple-400" />
                Materials
              </h3>
              <div className="grid grid-cols-3 gap-2">
                {(Object.entries(currentSlot.cubes) as [keyof typeof CUBE_COLORS, number][]).map(([type, count]) => (
                  <div 
                    key={type}
                    className="bg-gray-800 rounded-lg p-3 text-center border border-gray-700"
                  >
                    <div 
                      className="w-10 h-10 rounded mx-auto mb-2"
                      style={{ 
                        backgroundColor: CUBE_COLORS[type],
                        boxShadow: `0 0 10px ${CUBE_COLORS[type]}50`
                      }}
                    />
                    <div className="text-white font-bold">{count}</div>
                    <div className="text-gray-400 text-xs capitalize">{type}</div>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <Sword className="h-5 w-5 text-orange-400" />
                Equipped Weapon
              </h3>
              <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                {currentSlot.equippedWeapon ? (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Sword className="h-8 w-8 text-orange-400" />
                      <div>
                        <div className="text-white font-bold">{currentSlot.equippedWeapon.name}</div>
                        <div className="text-gray-400 text-sm">
                          {currentSlot.equippedWeapon.damage} damage | 
                          {currentSlot.equippedWeapon.attackSpeed.toFixed(1)}x speed
                        </div>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-red-400 hover:text-red-300 hover:bg-red-900/30"
                      onClick={unequipWeapon}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="text-gray-500 text-center py-4">
                    No weapon equipped
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
              <Shield className="h-5 w-5 text-blue-400" />
              Equipped Armor
            </h3>
            <div className="grid grid-cols-3 gap-3">
              {armorSlots.map((slot) => {
                const armor = currentSlot.equippedArmor[slot];
                return (
                  <div 
                    key={slot}
                    className="bg-gray-800 rounded-lg p-4 border border-gray-700"
                  >
                    <div className="text-gray-400 text-xs uppercase mb-2">{slot}</div>
                    {armor ? (
                      <div>
                        <div className="text-white font-bold text-sm">{armor.name}</div>
                        <div className="text-blue-400 text-xs">+{armor.defense} defense</div>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="mt-2 w-full text-red-400 hover:text-red-300 hover:bg-red-900/30"
                          onClick={() => unequipArmor(slot)}
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          Remove
                        </Button>
                      </div>
                    ) : (
                      <div className="text-gray-500 text-center py-2 text-sm">
                        Empty
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            
            <div className="mt-4 bg-blue-900/30 rounded-lg p-3 border border-blue-500">
              <div className="flex items-center justify-between">
                <span className="text-blue-300">Total Defense:</span>
                <span className="text-white font-bold">
                  {Object.values(currentSlot.equippedArmor)
                    .filter(Boolean)
                    .reduce((sum, armor) => sum + (armor?.defense || 0), 0)}
                </span>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
              <Heart className="h-5 w-5 text-pink-400" />
              Special Items
            </h3>
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Heart className="h-8 w-8 text-pink-400" />
                  <div>
                    <div className="text-white font-bold">Life Cubes</div>
                    <div className="text-pink-300 text-sm">Prevents death once when used</div>
                  </div>
                </div>
                <div className="text-3xl font-bold text-pink-400">
                  {currentSlot.lifeCubes}
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
              <Package className="h-5 w-5 text-green-400" />
              Inventory Slots ({currentSlot.inventorySlots}/4)
            </h3>
            <div className="flex gap-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <div 
                  key={i}
                  className={`w-16 h-16 rounded-lg border-2 ${
                    i < currentSlot.inventorySlots 
                      ? "bg-gray-800 border-gray-600" 
                      : "bg-gray-900 border-gray-800 opacity-50"
                  }`}
                />
              ))}
            </div>
            {currentSlot.inventorySlots < 4 && (
              <p className="text-gray-400 text-sm mt-2">
                Craft Pack/Container/Backpack to unlock more slots!
              </p>
            )}
          </div>
          
          <div className="mt-6 pt-4 border-t border-gray-700">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="text-gray-400">
                Bosses Defeated: <span className="text-white">{currentSlot.defeatedBosses.length}/8</span>
              </div>
              <div className="text-gray-400">
                Coins: <span className="text-yellow-400">{currentSlot.coins}</span>
              </div>
              <div className="text-gray-400">
                Crystal HP: <span className="text-cyan-400">{currentSlot.crystalHp}/5000</span>
              </div>
              <div className="text-gray-400">
                Sandbox: <span className={currentSlot.hasSandbox ? "text-green-400" : "text-red-400"}>
                  {currentSlot.hasSandbox ? "Unlocked" : "Locked"}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
