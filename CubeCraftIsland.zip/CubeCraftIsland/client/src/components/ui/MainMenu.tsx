import { useState, useEffect } from "react";
import { useGameStore } from "@/lib/stores/useGameStore";
import { useAudio } from "@/lib/stores/useAudio";
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Volume2, VolumeX, Gamepad2, BookOpen, Settings } from "lucide-react";
import { SettingsUI } from "./SettingsUI";

export function MainMenu() {
  const { setPhase, isMuted, toggleMute, slots } = useGameStore();
  const { backgroundMusic, setBackgroundMusic } = useAudio();
  const [showControls, setShowControls] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  
  useEffect(() => {
    if (!backgroundMusic) {
      const music = new Audio("/sounds/background.mp3");
      music.loop = true;
      music.volume = 0.3;
      setBackgroundMusic(music);
    }
    
    if (backgroundMusic && !isMuted) {
      backgroundMusic.play().catch(console.log);
    }
    
    return () => {
      if (backgroundMusic) {
        backgroundMusic.pause();
      }
    };
  }, [backgroundMusic, isMuted]);
  
  const handleToggleMute = () => {
    toggleMute();
    if (backgroundMusic) {
      if (isMuted) {
        backgroundMusic.play().catch(console.log);
      } else {
        backgroundMusic.pause();
      }
    }
  };
  
  return (
    <div className="fixed inset-0 bg-gradient-to-b from-purple-900 via-indigo-900 to-black flex flex-col items-center justify-center overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 50 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-sm opacity-20"
            style={{
              width: `${10 + Math.random() * 20}px`,
              height: `${10 + Math.random() * 20}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              backgroundColor: ["#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7", "#DDA0DD"][Math.floor(Math.random() * 6)],
              animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 2}s`,
            }}
          />
        ))}
      </div>
      
      <div className="relative z-10 text-center mb-12">
        <h1 className="text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-purple-500 mb-4 animate-pulse">
          CUBE COMBINATION
        </h1>
        <p className="text-xl text-gray-300">Craft, Fight, Survive</p>
      </div>
      
      <div className="relative z-10 flex flex-col gap-4 min-w-[300px]">
        <Button
          size="lg"
          className="w-full text-xl py-6 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 transition-all transform hover:scale-105"
          onClick={() => setPhase("slot_select")}
        >
          <Gamepad2 className="mr-2 h-6 w-6" />
          {slots.length > 0 ? "Continue Game" : "New Game"}
        </Button>
        
        <Button
          size="lg"
          variant="outline"
          className="w-full text-lg py-5 border-2 border-purple-500 text-purple-300 hover:bg-purple-500/20"
          onClick={() => setShowControls(true)}
        >
          <BookOpen className="mr-2 h-5 w-5" />
          How to Play
        </Button>
        
        <Button
          size="lg"
          variant="ghost"
          className="w-full text-lg py-5 text-gray-400 hover:text-white hover:bg-white/10"
          onClick={handleToggleMute}
        >
          {isMuted ? <VolumeX className="mr-2 h-5 w-5" /> : <Volume2 className="mr-2 h-5 w-5" />}
          {isMuted ? "Unmute Sound" : "Mute Sound"}
        </Button>

        <Button
          size="lg"
          variant="ghost"
          className="w-full text-lg py-5 text-gray-400 hover:text-white hover:bg-white/10"
          onClick={() => setShowSettings(true)}
        >
          <Settings className="mr-2 h-5 w-5" />
          Settings
        </Button>
      </div>
      
      <div className="absolute bottom-8 text-gray-500 text-sm">
        v1.0Beta Release - Made with React Three Fiber
      </div>
      
      {showSettings && <SettingsUI onClose={() => setShowSettings(false)} />}
      
      {showControls && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <Card className="max-w-2xl w-full max-h-[80vh] overflow-y-auto bg-gray-900 border-purple-500">
            <CardHeader>
              <CardTitle className="text-2xl text-purple-400">How to Play</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300 space-y-4">
              <div>
                <h3 className="text-lg font-bold text-yellow-400 mb-2">Controls</h3>
                <ul className="list-disc list-inside space-y-1">
                  <li><span className="text-white">WASD</span> - Move around</li>
                  <li><span className="text-white">Mouse</span> - Look around</li>
                  <li><span className="text-white">Space</span> - Jump</li>
                  <li><span className="text-white">Left Click</span> - Attack / Interact</li>
                  <li><span className="text-white">E</span> - Pick up / Drop items</li>
                  <li><span className="text-white">Tab</span> - Open inventory</li>
                  <li><span className="text-white">ESC</span> - Pause menu</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-bold text-green-400 mb-2">Crafting</h3>
                <p>Drop cubes on top of each other to combine them! Stack the same type of cubes to craft weapons, armor, and more.</p>
              </div>
              
              <div>
                <h3 className="text-lg font-bold text-blue-400 mb-2">Cube Types</h3>
                <ul className="list-disc list-inside space-y-1">
                  <li><span className="text-gray-400">Common</span> - Basic materials</li>
                  <li><span className="text-green-400">Uncommon</span> - Better quality</li>
                  <li><span className="text-blue-400">Rare</span> - Rare materials</li>
                  <li><span className="text-purple-400">Epic</span> - Epic items</li>
                  <li><span className="text-orange-400">Legendary</span> - Powerful gear</li>
                  <li><span className="text-pink-400">Mythic</span> - The best of the best</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-bold text-red-400 mb-2">Objective</h3>
                <p>Protect the Crystal of Life at the center of the starter island! If it's destroyed, game over. Explore other islands, defeat bosses, and collect loot!</p>
              </div>
              
              <div>
                <h3 className="text-lg font-bold text-cyan-400 mb-2">Tips</h3>
                <ul className="list-disc list-inside space-y-1">
                  <li>Build platforms to reach other islands</li>
                  <li>Craft Life Cubes to prevent death</li>
                  <li>Defeat bosses for special materials</li>
                  <li>Earn coins to unlock sandbox mode (50 coins)</li>
                </ul>
              </div>
              
              <Button 
                className="w-full mt-4"
                onClick={() => setShowControls(false)}
              >
                Got it!
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
      
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(180deg); }
        }
      `}</style>
    </div>
  );
}
