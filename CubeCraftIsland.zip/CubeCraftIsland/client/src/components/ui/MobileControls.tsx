import { useRef, useEffect, useState } from "react";
import { ChevronUp, PackageOpen } from "lucide-react";
import { useGameStore } from "@/lib/stores/useGameStore";

interface MobileControlsProps {
  onMove?: (x: number, z: number) => void;
  onJump?: () => void;
  onAttack?: () => void;
  onInteract?: () => void;
  onInventory?: () => void;
}

export function MobileControls({ onMove, onJump, onAttack, onInteract, onInventory }: MobileControlsProps) {
  const { mobileControlsEnabled } = useGameStore();
  const joystickRef = useRef<HTMLDivElement>(null);
  const touchRef = useRef<{ id: number; x: number; y: number } | null>(null);
  const [joystickPos, setJoystickPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleTouchStart = (e: TouchEvent) => {
      const touch = e.touches[0];
      if (!joystickRef.current) return;

      const rect = joystickRef.current.getBoundingClientRect();
      const x = touch.clientX - rect.left;
      const y = touch.clientY - rect.top;

      touchRef.current = { id: touch.identifier, x, y };
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!touchRef.current || !joystickRef.current) return;

      const touch = Array.from(e.touches).find(
        (t) => t.identifier === touchRef.current?.id
      );
      if (!touch) return;

      const rect = joystickRef.current.getBoundingClientRect();
      const x = touch.clientX - rect.left - 40;
      const y = touch.clientY - rect.top - 40;

      const distance = Math.sqrt(x * x + y * y);
      const maxDistance = 40;

      let finalX = x;
      let finalY = y;

      if (distance > maxDistance) {
        finalX = (x / distance) * maxDistance;
        finalY = (y / distance) * maxDistance;
      }

      setJoystickPos({ x: finalX, y: finalY });

      if (onMove) {
        onMove(finalX / maxDistance, -finalY / maxDistance);
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      const touch = Array.from(e.changedTouches).find(
        (t) => t.identifier === touchRef.current?.id
      );
      if (touch) {
        touchRef.current = null;
        setJoystickPos({ x: 0, y: 0 });
        if (onMove) onMove(0, 0);
      }
    };

    window.addEventListener("touchstart", handleTouchStart);
    window.addEventListener("touchmove", handleTouchMove);
    window.addEventListener("touchend", handleTouchEnd);

    return () => {
      window.removeEventListener("touchstart", handleTouchStart);
      window.removeEventListener("touchmove", handleTouchMove);
      window.removeEventListener("touchend", handleTouchEnd);
    };
  }, [onMove]);

  if (!mobileControlsEnabled) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-30 md:hidden">
      {/* Left Joystick */}
      <div
        ref={joystickRef}
        className="absolute bottom-20 left-4 w-24 h-24 bg-black/40 border-2 border-cyan-500 rounded-full pointer-events-auto"
      >
        <div
          className="absolute w-12 h-12 bg-cyan-500 rounded-full transition-transform"
          style={{
            left: `calc(50% - 24px + ${joystickPos.x}px)`,
            top: `calc(50% - 24px + ${joystickPos.y}px)`,
          }}
        />
      </div>

      {/* Right Side Buttons */}
      <div className="absolute bottom-4 right-4 flex flex-col gap-2 pointer-events-auto">
        {/* Attack Button */}
        <button
          onClick={onAttack}
          className="w-14 h-14 bg-red-600 hover:bg-red-700 rounded-full flex items-center justify-center text-white font-bold text-lg active:scale-90 transition-transform"
        >
          A
        </button>

        {/* Jump Button */}
        <button
          onClick={onJump}
          className="w-14 h-14 bg-green-600 hover:bg-green-700 rounded-full flex items-center justify-center text-white font-bold active:scale-90 transition-transform"
        >
          <ChevronUp className="h-6 w-6" />
        </button>

        {/* Interact Button */}
        <button
          onClick={onInteract}
          className="w-14 h-14 bg-blue-600 hover:bg-blue-700 rounded-full flex items-center justify-center text-white font-bold text-lg active:scale-90 transition-transform"
        >
          E
        </button>

        {/* Inventory Button */}
        <button
          onClick={onInventory}
          className="w-14 h-14 bg-purple-600 hover:bg-purple-700 rounded-full flex items-center justify-center text-white active:scale-90 transition-transform"
        >
          <PackageOpen className="h-6 w-6" />
        </button>
      </div>

      {/* Info Text */}
      <div className="absolute top-4 left-4 pointer-events-none">
        <p className="text-xs text-gray-300 bg-black/50 px-2 py-1 rounded">
          Mobile Mode
        </p>
      </div>
    </div>
  );
}
