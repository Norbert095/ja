import { useState } from "react";
import { useGameStore } from "@/lib/stores/useGameStore";
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Play, Save, Home, Volume2, VolumeX, Settings, Sparkles } from "lucide-react";
import { SettingsUI } from "./SettingsUI";

interface PauseMenuProps {
  onResume: () => void;
}

export function PauseMenu({ onResume }: PauseMenuProps) {
  const [showSettings, setShowSettings] = useState(false);
  const { 
    setPhase, 
    saveGame, 
    currentSlot, 
    isMuted, 
    toggleMute,
    unlockSandbox
  } = useGameStore();
  
  const handleSaveAndQuit = () => {
    saveGame();
    setPhase("menu");
  };
  
  const handleUnlockSandbox = () => {
    if (currentSlot && !currentSlot.hasSandbox && currentSlot.coins >= 50) {
      unlockSandbox();
    }
  };
  
  const handleEnterSandbox = () => {
    if (currentSlot?.hasSandbox) {
      setPhase("sandbox");
      onResume();
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 backdrop-blur-sm">
      <Card className="w-96 bg-gray-900/95 border-purple-500">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl text-white">Game Paused</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button 
            className="w-full py-6 text-lg bg-green-600 hover:bg-green-700"
            onClick={onResume}
          >
            <Play className="mr-2 h-5 w-5" />
            Resume Game
          </Button>
          
          <Button 
            variant="outline"
            className="w-full py-5 border-blue-500 text-blue-400 hover:bg-blue-500/20"
            onClick={saveGame}
          >
            <Save className="mr-2 h-5 w-5" />
            Save Game
          </Button>
          
          <div className="border-t border-gray-700 pt-3">
            {currentSlot?.hasSandbox ? (
              <Button 
                className="w-full py-5 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
                onClick={handleEnterSandbox}
              >
                <Sparkles className="mr-2 h-5 w-5" />
                Enter Sandbox Mode
              </Button>
            ) : (
              <Button 
                className="w-full py-5"
                variant={currentSlot && currentSlot.coins >= 50 ? "default" : "ghost"}
                disabled={!currentSlot || currentSlot.coins < 50}
                onClick={handleUnlockSandbox}
              >
                <Sparkles className="mr-2 h-5 w-5" />
                Unlock Sandbox (50 coins)
                {currentSlot && currentSlot.coins < 50 && (
                  <span className="ml-2 text-red-400">
                    ({currentSlot.coins}/50)
                  </span>
                )}
              </Button>
            )}
          </div>
          
          <div className="border-t border-gray-700 pt-3 flex gap-2">
            <Button 
              variant="ghost"
              className="flex-1 text-gray-400 hover:text-white hover:bg-gray-800"
              onClick={toggleMute}
            >
              {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
            </Button>
            
            <Button 
              variant="ghost"
              className="flex-1 text-gray-400 hover:text-white hover:bg-gray-800"
              onClick={() => setShowSettings(true)}
            >
              <Settings className="h-5 w-5" />
            </Button>
          </div>
          
          <Button 
            variant="destructive"
            className="w-full py-5"
            onClick={handleSaveAndQuit}
          >
            <Home className="mr-2 h-5 w-5" />
            Save & Quit
          </Button>
          
          {currentSlot && (
            <div className="text-center text-sm text-gray-500 pt-2">
              Playing: {currentSlot.name}
            </div>
          )}
        </CardContent>
      </Card>
      
      {showSettings && <SettingsUI onClose={() => setShowSettings(false)} />}
    </div>
  );
}
