import { useState } from "react";
import { useGameStore, CubeType, Enemy } from "@/lib/stores/useGameStore";
import { 
  CUBE_COLORS, 
  CUBE_NAMES, 
  BOSS_DATA, 
  SANDBOX_BOSSES,
  ENEMY_TYPES,
  SANDBOX_EXCLUSIVE_WEAPONS,
  SANDBOX_EXCLUSIVE_ARMOR,
  SANDBOX_UTILITY_ITEMS
} from "@/lib/gameData";
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Input } from "./input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./tabs";
import { Slider } from "./slider";
import { X, Sparkles, Box, Skull, Sword, Shield, Zap, Play, ArrowLeft } from "lucide-react";

interface SandboxPanelProps {
  onClose: () => void;
  onSpawnCube: (type: CubeType, position: [number, number, number]) => void;
  onSpawnEnemy: (enemy: Omit<Enemy, "id">) => void;
}

export function SandboxPanel({ onClose, onSpawnCube, onSpawnEnemy }: SandboxPanelProps) {
  const { currentSlot, setPhase, equipWeapon, equipArmor, addCubeToInventory, heal, removeEnemy, worldEnemies } = useGameStore();
  
  const [selectedTab, setSelectedTab] = useState("cubes");
  const [customEnemyName, setCustomEnemyName] = useState("");
  const [customEnemyHp, setCustomEnemyHp] = useState(100);
  const [customEnemyDamage, setCustomEnemyDamage] = useState(10);
  const [spawnMessage, setSpawnMessage] = useState<string | null>(null);
  const [speedBoost, setSpeedBoost] = useState(1);
  const [jumpBoost, setJumpBoost] = useState(1);
  const [invincible, setInvincible] = useState(false);
  const [damageBoost, setDamageBoost] = useState(1);
  
  if (!currentSlot?.hasSandbox) return null;
  
  const showMessage = (msg: string) => {
    setSpawnMessage(msg);
    setTimeout(() => setSpawnMessage(null), 2000);
  };
  
  const handleSpawnCube = (type: CubeType) => {
    const randomX = (Math.random() - 0.5) * 20;
    const randomZ = (Math.random() - 0.5) * 20;
    onSpawnCube(type, [randomX, 1, randomZ]);
    showMessage(`Spawned ${CUBE_NAMES[type]}!`);
  };
  
  const handleSpawnEnemy = (enemyType: typeof ENEMY_TYPES[0]) => {
    const randomX = (Math.random() - 0.5) * 30 + 50;
    const randomZ = (Math.random() - 0.5) * 30;
    
    onSpawnEnemy({
      name: customEnemyName || enemyType.name,
      hp: customEnemyHp || enemyType.hp,
      maxHp: customEnemyHp || enemyType.hp,
      damage: customEnemyDamage || enemyType.damage,
      position: [randomX, 0, randomZ],
      type: enemyType.type,
      isAggro: true,
      isBoss: false,
      drops: [{ type: "coins", amount: 10 }],
    });
    showMessage(`Spawned ${customEnemyName || enemyType.name}!`);
  };
  
  const handleSpawnBoss = (boss: typeof BOSS_DATA[0] | typeof SANDBOX_BOSSES[0]) => {
    const randomX = (Math.random() - 0.5) * 30 + 80;
    const randomZ = (Math.random() - 0.5) * 30;
    
    onSpawnEnemy({
      name: customEnemyName || boss.name,
      hp: customEnemyHp || boss.hp,
      maxHp: customEnemyHp || boss.hp,
      damage: customEnemyDamage || boss.damage,
      position: [randomX, 0, randomZ],
      type: "golem",
      isAggro: true,
      isBoss: true,
      bossIndex: boss.index,
      drops: [{ type: "coins", amount: 100 }, { type: "boss_material", name: `${boss.name} Essence` }],
    });
    showMessage(`Spawned Boss: ${customEnemyName || boss.name}!`);
  };
  
  const handleEquipSandboxWeapon = (weapon: typeof SANDBOX_EXCLUSIVE_WEAPONS[0]) => {
    equipWeapon({ ...weapon });
    showMessage(`Equipped ${weapon.name}!`);
  };
  
  const handleEquipSandboxArmor = (armor: typeof SANDBOX_EXCLUSIVE_ARMOR[0]) => {
    equipArmor({ ...armor });
    showMessage(`Equipped ${armor.name}!`);
  };
  
  const handleGiveCubes = (type: CubeType, amount: number) => {
    addCubeToInventory(type, amount);
    showMessage(`Added ${amount} ${CUBE_NAMES[type]}s!`);
  };
  
  const handleUtilityActivate = (utilityId: string) => {
    switch (utilityId) {
      case "sandbox_speed_boots":
        setSpeedBoost(3);
        showMessage("Speed Boots activated! Move 3x faster for 30 seconds.");
        setTimeout(() => setSpeedBoost(1), 30000);
        break;
      case "sandbox_jump_enhancer":
        setJumpBoost(5);
        showMessage("Jump Enhancer activated! Jump 5x higher for 30 seconds.");
        setTimeout(() => setJumpBoost(1), 30000);
        break;
      case "sandbox_shield_generator":
        setInvincible(true);
        showMessage("Shield Generator active! Take no damage for 10 seconds.");
        setTimeout(() => setInvincible(false), 10000);
        break;
      case "sandbox_healing_aura":
        heal(999);
        showMessage("Healing Aura! You're fully healed!");
        break;
      case "sandbox_infinite_cubes":
        Object.keys(CUBE_COLORS).forEach(type => {
          addCubeToInventory(type as CubeType, 100);
        });
        showMessage("Infinite Cubes! Got 100 of each cube type!");
        break;
      case "sandbox_boss_caller":
        onSpawnEnemy({
          name: "Summoned Boss",
          hp: 5000,
          maxHp: 5000,
          damage: 100,
          position: [50, 0, 50],
          type: "golem",
          isAggro: true,
          isBoss: true,
          drops: [{ type: "coins", amount: 500 }],
        });
        showMessage("Boss Caller! Summoned a powerful boss!");
        break;
      case "sandbox_time_freezer":
        showMessage("Time Freezer! All enemies are frozen for 15 seconds.");
        const frozenEnemies = worldEnemies.map(e => e.id);
        setTimeout(() => {
          frozenEnemies.forEach(id => removeEnemy(id));
          showMessage("Time resumed! Frozen enemies removed.");
        }, 15000);
        break;
      case "sandbox_damage_amplifier":
        setDamageBoost(10);
        showMessage("Damage Amplifier! Your damage is 10x for 20 seconds.");
        setTimeout(() => setDamageBoost(1), 20000);
        break;
      case "sandbox_invincibility":
        setInvincible(true);
        showMessage("Invincibility Crystal! You are invincible!");
        break;
      case "sandbox_teleporter":
        showMessage("Teleporter! Teleported to starter island.");
        break;
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4">
      <Card className="max-w-5xl w-full max-h-[95vh] overflow-hidden bg-gradient-to-b from-yellow-900/50 to-gray-900 border-yellow-500">
        <CardHeader className="flex flex-row items-center justify-between border-b border-yellow-700">
          <CardTitle className="text-2xl text-yellow-400 flex items-center gap-2">
            <Sparkles className="h-6 w-6" />
            Sandbox Mode
          </CardTitle>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              className="border-green-500 text-green-400 hover:bg-green-500/20"
              onClick={() => {
                setPhase("playing");
                onClose();
              }}
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back to Game
            </Button>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>
        </CardHeader>
        
        {spawnMessage && (
          <div className="p-3 bg-green-600 text-white text-center font-bold">
            {spawnMessage}
          </div>
        )}
        
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="w-full justify-start bg-gray-800 p-1 rounded-none">
            <TabsTrigger value="cubes" className="flex items-center gap-1">
              <Box className="h-4 w-4" />
              Cubes
            </TabsTrigger>
            <TabsTrigger value="enemies" className="flex items-center gap-1">
              <Skull className="h-4 w-4" />
              Enemies
            </TabsTrigger>
            <TabsTrigger value="bosses" className="flex items-center gap-1">
              <Skull className="h-4 w-4 text-red-400" />
              Bosses
            </TabsTrigger>
            <TabsTrigger value="weapons" className="flex items-center gap-1">
              <Sword className="h-4 w-4" />
              Weapons
            </TabsTrigger>
            <TabsTrigger value="armor" className="flex items-center gap-1">
              <Shield className="h-4 w-4" />
              Armor
            </TabsTrigger>
            <TabsTrigger value="utility" className="flex items-center gap-1">
              <Zap className="h-4 w-4" />
              Utility
            </TabsTrigger>
          </TabsList>
          
          <CardContent className="overflow-y-auto max-h-[60vh] p-4">
            <TabsContent value="cubes" className="mt-0">
              <h3 className="text-lg font-bold text-white mb-4">Spawn Cubes</h3>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-3 mb-6">
                {(Object.keys(CUBE_COLORS) as CubeType[]).map((type) => (
                  <Button
                    key={type}
                    className="h-20 flex flex-col gap-1"
                    style={{ backgroundColor: CUBE_COLORS[type] }}
                    onClick={() => handleSpawnCube(type)}
                  >
                    <Box className="h-6 w-6" />
                    <span className="text-xs capitalize">{type}</span>
                  </Button>
                ))}
              </div>
              
              <h3 className="text-lg font-bold text-white mb-4">Add to Inventory</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {(Object.keys(CUBE_COLORS) as CubeType[]).map((type) => (
                  <div key={type} className="flex gap-2">
                    <Button
                      className="flex-1"
                      variant="outline"
                      style={{ borderColor: CUBE_COLORS[type], color: CUBE_COLORS[type] }}
                      onClick={() => handleGiveCubes(type, 10)}
                    >
                      +10 {type}
                    </Button>
                    <Button
                      variant="outline"
                      style={{ borderColor: CUBE_COLORS[type], color: CUBE_COLORS[type] }}
                      onClick={() => handleGiveCubes(type, 100)}
                    >
                      +100
                    </Button>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="enemies" className="mt-0">
              <div className="mb-6 p-4 bg-gray-800 rounded-lg">
                <h4 className="text-white font-bold mb-3">Custom Enemy Stats</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="text-gray-400 text-sm">Custom Name</label>
                    <Input
                      value={customEnemyName}
                      onChange={(e) => setCustomEnemyName(e.target.value)}
                      placeholder="Leave empty for default"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm">HP: {customEnemyHp}</label>
                    <Slider
                      value={[customEnemyHp]}
                      onValueChange={([v]) => setCustomEnemyHp(v)}
                      min={10}
                      max={10000}
                      step={10}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm">Damage: {customEnemyDamage}</label>
                    <Slider
                      value={[customEnemyDamage]}
                      onValueChange={([v]) => setCustomEnemyDamage(v)}
                      min={1}
                      max={500}
                      step={1}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                {ENEMY_TYPES.map((enemy) => (
                  <Button
                    key={enemy.type}
                    className="h-20 flex flex-col gap-1"
                    style={{ backgroundColor: enemy.color }}
                    onClick={() => handleSpawnEnemy(enemy)}
                  >
                    <Skull className="h-6 w-6" />
                    <span className="text-xs">{enemy.name}</span>
                    <span className="text-xs opacity-70">{enemy.hp} HP</span>
                  </Button>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="bosses" className="mt-0">
              <div className="mb-6 p-4 bg-gray-800 rounded-lg">
                <h4 className="text-white font-bold mb-3">Custom Boss Stats</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="text-gray-400 text-sm">Custom Name</label>
                    <Input
                      value={customEnemyName}
                      onChange={(e) => setCustomEnemyName(e.target.value)}
                      placeholder="Leave empty for default"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm">HP: {customEnemyHp}</label>
                    <Slider
                      value={[customEnemyHp]}
                      onValueChange={([v]) => setCustomEnemyHp(v)}
                      min={100}
                      max={50000}
                      step={100}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm">Damage: {customEnemyDamage}</label>
                    <Slider
                      value={[customEnemyDamage]}
                      onValueChange={([v]) => setCustomEnemyDamage(v)}
                      min={10}
                      max={1000}
                      step={5}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>
              
              <h3 className="text-lg font-bold text-white mb-3">Main Bosses</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                {BOSS_DATA.map((boss) => (
                  <Button
                    key={boss.index}
                    className="h-24 flex flex-col gap-1"
                    style={{ backgroundColor: boss.color }}
                    onClick={() => handleSpawnBoss(boss)}
                  >
                    <Skull className="h-8 w-8" />
                    <span className="text-xs font-bold">{boss.name}</span>
                    <span className="text-xs opacity-70">{boss.hp} HP | {boss.damage} DMG</span>
                  </Button>
                ))}
              </div>
              
              <h3 className="text-lg font-bold text-red-400 mb-3">Sandbox Exclusive Bosses</h3>
              <div className="grid grid-cols-3 gap-3">
                {SANDBOX_BOSSES.map((boss) => (
                  <Button
                    key={boss.index}
                    className="h-28 flex flex-col gap-1 border-2 border-red-500"
                    style={{ backgroundColor: boss.color }}
                    onClick={() => handleSpawnBoss(boss)}
                  >
                    <Skull className="h-10 w-10 text-red-500" />
                    <span className="text-sm font-bold">{boss.name}</span>
                    <span className="text-xs opacity-70">{boss.hp} HP | {boss.damage} DMG</span>
                  </Button>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="weapons" className="mt-0">
              <h3 className="text-lg font-bold text-yellow-400 mb-3">Sandbox Exclusive Weapons</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {SANDBOX_EXCLUSIVE_WEAPONS.map((weapon) => (
                  <Button
                    key={weapon.id}
                    className="h-24 flex flex-col gap-1 bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-500 hover:to-orange-500"
                    onClick={() => handleEquipSandboxWeapon(weapon)}
                  >
                    <Sword className="h-8 w-8" />
                    <span className="text-sm font-bold">{weapon.name}</span>
                    <span className="text-xs opacity-80">
                      {weapon.damage} DMG | {weapon.attackSpeed}x Speed
                    </span>
                  </Button>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="armor" className="mt-0">
              <h3 className="text-lg font-bold text-yellow-400 mb-3">Sandbox Exclusive Armor Sets</h3>
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <h4 className="text-white font-bold mb-2 text-center">God Armor</h4>
                  <div className="space-y-2">
                    {SANDBOX_EXCLUSIVE_ARMOR.filter(a => a.name.includes("God")).map((armor) => (
                      <Button
                        key={armor.id}
                        className="w-full bg-gradient-to-r from-yellow-500 to-amber-500"
                        onClick={() => handleEquipSandboxArmor(armor)}
                      >
                        <Shield className="h-4 w-4 mr-2" />
                        {armor.name} (+{armor.defense})
                      </Button>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-white font-bold mb-2 text-center">Shadow Armor</h4>
                  <div className="space-y-2">
                    {SANDBOX_EXCLUSIVE_ARMOR.filter(a => a.name.includes("Shadow")).map((armor) => (
                      <Button
                        key={armor.id}
                        className="w-full bg-gradient-to-r from-purple-600 to-indigo-600"
                        onClick={() => handleEquipSandboxArmor(armor)}
                      >
                        <Shield className="h-4 w-4 mr-2" />
                        {armor.name} (+{armor.defense})
                      </Button>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-white font-bold mb-2 text-center">Dragon Armor</h4>
                  <div className="space-y-2">
                    {SANDBOX_EXCLUSIVE_ARMOR.filter(a => a.name.includes("Dragon")).map((armor) => (
                      <Button
                        key={armor.id}
                        className="w-full bg-gradient-to-r from-red-600 to-orange-600"
                        onClick={() => handleEquipSandboxArmor(armor)}
                      >
                        <Shield className="h-4 w-4 mr-2" />
                        {armor.name} (+{armor.defense})
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="utility" className="mt-0">
              <h3 className="text-lg font-bold text-cyan-400 mb-3">Utility Items</h3>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                {SANDBOX_UTILITY_ITEMS.map((item) => (
                  <Button
                    key={item.id}
                    className="h-24 flex flex-col gap-1 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                    onClick={() => handleUtilityActivate(item.id)}
                  >
                    <Zap className="h-6 w-6" />
                    <span className="text-xs font-bold">{item.name}</span>
                    <span className="text-xs opacity-70 text-center">{item.description}</span>
                  </Button>
                ))}
              </div>
              <p className="text-gray-400 text-sm mt-4 text-center">
                Click any utility to activate its effect!
              </p>
            </TabsContent>
          </CardContent>
        </Tabs>
      </Card>
    </div>
  );
}
