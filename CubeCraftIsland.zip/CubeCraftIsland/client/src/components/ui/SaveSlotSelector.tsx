import { useState } from "react";
import { useGameStore, SaveSlot } from "@/lib/stores/useGameStore";
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Input } from "./input";
import { ArrowLeft, Plus, Play, Trash2, Coins, Clock, Shield, Sword } from "lucide-react";

export function SaveSlotSelector() {
  const { 
    slots, 
    availableSlots, 
    maxSlots, 
    slotCost,
    setPhase, 
    loadSlot, 
    createSlot,
    deleteSlot,
    purchaseSlot 
  } = useGameStore();
  
  const [showNewSlot, setShowNewSlot] = useState(false);
  const [newSlotName, setNewSlotName] = useState("");
  const [worldType, setWorldType] = useState<"standard" | "grid">("standard");
  const [selectedSlot, setSelectedSlot] = useState<SaveSlot | null>(null);
  
  const handleCreateSlot = () => {
    if (newSlotName.trim() || slots.length === 0) {
      createSlot(newSlotName.trim() || `World ${slots.length + 1}`);
      setShowNewSlot(false);
      setNewSlotName("");
    }
  };
  
  const handleLoadSlot = (slot: SaveSlot) => {
    loadSlot(slot.id);
  };
  
  const formatPlayTime = (ms: number) => {
    const hours = Math.floor(ms / 3600000);
    const minutes = Math.floor((ms % 3600000) / 60000);
    return `${hours}h ${minutes}m`;
  };
  
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString();
  };
  
  return (
    <div className="fixed inset-0 bg-gradient-to-b from-indigo-900 via-purple-900 to-black flex flex-col items-center justify-center p-4">
      <Button
        variant="ghost"
        className="absolute top-4 left-4 text-gray-300 hover:text-white"
        onClick={() => setPhase("menu")}
      >
        <ArrowLeft className="mr-2 h-5 w-5" />
        Back to Menu
      </Button>
      
      <h1 className="text-4xl font-bold text-white mb-2">Select World</h1>
      <p className="text-gray-400 mb-8">
        {slots.length} / {availableSlots} slots used 
        {availableSlots < maxSlots && ` (Buy more for ${slotCost} coins)`}
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl w-full max-h-[60vh] overflow-y-auto p-2">
        {slots.map((slot) => (
          <Card 
            key={slot.id}
            className={`cursor-pointer transition-all transform hover:scale-105 ${
              selectedSlot?.id === slot.id 
                ? "border-2 border-purple-500 bg-purple-900/50" 
                : "bg-gray-800/80 border-gray-700 hover:border-gray-500"
            }`}
            onClick={() => setSelectedSlot(slot)}
          >
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-white flex items-center justify-between">
                <span>{slot.name}</span>
                {slot.hasSandbox && (
                  <span className="text-xs bg-yellow-500 text-black px-2 py-1 rounded">
                    SANDBOX
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-gray-300 space-y-2">
              <div className="flex items-center gap-2">
                <Coins className="h-4 w-4 text-yellow-400" />
                <span>{slot.coins} coins</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-cyan-400" />
                <span>Crystal: {slot.crystalHp}/5000 HP</span>
              </div>
              <div className="flex items-center gap-2">
                <Sword className="h-4 w-4 text-red-400" />
                <span>{slot.defeatedBosses.length}/8 Bosses</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-gray-400" />
                <span>{formatPlayTime(slot.playTime)}</span>
              </div>
              <div className="text-xs text-gray-500">
                Last played: {formatDate(slot.lastSave)}
              </div>
              
              {selectedSlot?.id === slot.id && (
                <div className="flex gap-2 mt-4">
                  <Button 
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleLoadSlot(slot);
                    }}
                  >
                    <Play className="mr-1 h-4 w-4" />
                    Play
                  </Button>
                  <Button 
                    className="flex-1 bg-red-600 hover:bg-red-700"
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm(`Delete "${slot.name}"? This cannot be undone.`)) {
                        deleteSlot(slot.id);
                        setPhase("slot_select");
                      }
                    }}
                  >
                    <Trash2 className="mr-1 h-4 w-4" />
                    Delete
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
        
        {slots.length < availableSlots && (
          <Card 
            className="cursor-pointer bg-gray-800/50 border-dashed border-2 border-gray-600 hover:border-purple-500 transition-all flex items-center justify-center min-h-[200px]"
            onClick={() => setShowNewSlot(true)}
          >
            <div className="text-center text-gray-400">
              <Plus className="h-12 w-12 mx-auto mb-2" />
              <p>Create New World</p>
            </div>
          </Card>
        )}
        
        {slots.length >= availableSlots && availableSlots < maxSlots && (
          <Card 
            className="cursor-pointer bg-yellow-900/30 border-dashed border-2 border-yellow-600 hover:border-yellow-500 transition-all flex items-center justify-center min-h-[200px]"
            onClick={() => {
              if (selectedSlot && selectedSlot.coins >= slotCost) {
                loadSlot(selectedSlot.id);
                purchaseSlot();
              }
            }}
          >
            <div className="text-center text-yellow-400">
              <Coins className="h-12 w-12 mx-auto mb-2" />
              <p>Buy Slot ({slotCost} coins)</p>
              <p className="text-xs text-yellow-600 mt-1">
                Select a world with enough coins first
              </p>
            </div>
          </Card>
        )}
      </div>
      
      {showNewSlot && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <Card className="w-96 bg-gray-900 border-purple-500">
            <CardHeader>
              <CardTitle className="text-white">Create New World</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm text-gray-400">World Name</label>
                <Input
                  value={newSlotName}
                  onChange={(e) => setNewSlotName(e.target.value)}
                  placeholder={`World ${slots.length + 1}`}
                  className="bg-gray-800 border-gray-600 text-white"
                  maxLength={20}
                  autoFocus
                />
              </div>

              <div>
                <label className="text-sm text-gray-400">World Type</label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <Button
                    variant={worldType === "standard" ? "default" : "outline"}
                    className={worldType === "standard" ? "bg-blue-600" : ""}
                    onClick={() => setWorldType("standard")}
                  >
                    Standard
                  </Button>
                  <Button
                    variant={worldType === "grid" ? "default" : "outline"}
                    className={worldType === "grid" ? "bg-blue-600" : ""}
                    onClick={() => setWorldType("grid")}
                  >
                    Grid
                  </Button>
                </div>
              </div>

              <div className="bg-yellow-900/30 border border-yellow-600 rounded p-3">
                <p className="text-sm text-yellow-400">
                  <strong>Sandbox Cost:</strong> 700 coins to unlock
                </p>
              </div>

              <Button 
                disabled
                className="w-full bg-gray-700 text-gray-400 cursor-not-allowed"
              >
                🔜 Multiplayer Coming Soon
              </Button>

              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => {
                    setShowNewSlot(false);
                    setNewSlotName("");
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={handleCreateSlot}
                >
                  Create & Play
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
