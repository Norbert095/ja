import { useState } from "react";
import { useGameStore } from "@/lib/stores/useGameStore";
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Slider } from "./slider";
import { Input } from "./input";
import { X, Trash2, Gift, Zap } from "lucide-react";
import { getAvailableMods } from "@/lib/mods";

interface SettingsUIProps {
  onClose: () => void;
}

export function SettingsUI({ onClose }: SettingsUIProps) {
  const { renderDistance, setRenderDistance, setPhase, deleteAllData, redeemCode, redeemedCodes, currentSlot, toggleMod, mobileControlsEnabled, setMobileControlsEnabled } = useGameStore();
  const [tempDistance, setTempDistance] = useState(renderDistance);
  const [mobileEnabled, setMobileEnabled] = useState(mobileControlsEnabled);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [codeInput, setCodeInput] = useState("");
  const [codeMessage, setCodeMessage] = useState<{ text: string; type: "success" | "error" } | null>(null);
  
  const AVAILABLE_MODS = getAvailableMods();

  const handleApply = () => {
    setRenderDistance(tempDistance);
    setMobileControlsEnabled(mobileEnabled);
    onClose();
  };

  const handleDeleteAll = () => {
    deleteAllData();
    setPhase("menu");
    onClose();
  };

  const handleRedeemCode = () => {
    if (!codeInput.trim()) {
      setCodeMessage({ text: "Please enter a code", type: "error" });
      return;
    }
    
    if (redeemCode(codeInput)) {
      setCodeMessage({ text: `Code "${codeInput}" redeemed!`, type: "success" });
      setCodeInput("");
      setTimeout(() => setCodeMessage(null), 3000);
    } else {
      setCodeMessage({ text: "Invalid or already redeemed code", type: "error" });
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
      <Card className="w-full max-w-md bg-gray-900 border-cyan-500 max-h-[90vh] flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between border-b border-cyan-500 flex-shrink-0">
          <CardTitle className="text-cyan-400">Settings</CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </CardHeader>
        
        <CardContent className="space-y-6 pt-6 overflow-y-auto flex-1">
          <div className="space-y-3">
            <label className="text-white font-semibold block">
              Render Distance: {tempDistance}m
            </label>
            <Slider
              value={[tempDistance]}
              onValueChange={(value) => setTempDistance(value[0])}
              min={150}
              max={600}
              step={50}
              className="w-full"
            />
            <p className="text-xs text-gray-400">
              Lower = Better performance. Higher = See more islands/enemies.
            </p>
          </div>

          <div className="border-t border-gray-700 pt-6">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={mobileEnabled}
                onChange={(e) => setMobileEnabled(e.target.checked)}
                className="w-4 h-4"
              />
              <span className="text-white font-semibold">Mobile Controls</span>
            </label>
            <p className="text-xs text-gray-400 mt-2">Show virtual joystick and buttons on mobile devices</p>
          </div>

          <div className="border-t border-gray-700 pt-6 space-y-3">
            {currentSlot && (
              <div>
                <label className="text-white font-semibold block mb-2">
                  <Zap className="inline mr-2 h-4 w-4" />
                  Mods
                </label>
                <div className="space-y-2">
                  {AVAILABLE_MODS.length > 0 ? (
                    AVAILABLE_MODS.map(mod => (
                      <div key={mod.id} className="flex items-center justify-between bg-gray-800 rounded p-2">
                        <div className="flex-1">
                          <p className="text-white font-medium text-sm">{mod.name}</p>
                          <p className="text-gray-400 text-xs">{mod.description}</p>
                          <p className="text-gray-500 text-xs">v{mod.version} by {mod.author}</p>
                        </div>
                        <label className="flex items-center cursor-pointer ml-2">
                          <input
                            type="checkbox"
                            checked={currentSlot.enabledMods.includes(mod.id)}
                            onChange={() => toggleMod(mod.id)}
                            className="w-4 h-4"
                          />
                        </label>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-400 text-sm">No mods available</p>
                  )}
                </div>
                <p className="text-xs text-gray-400 mt-2">Mods disable coin earnings</p>
              </div>
            )}
            <div>
              <label className="text-white font-semibold block mb-2">
                <Gift className="inline mr-2 h-4 w-4" />
                Redeem Code
              </label>
              <div className="flex gap-2">
                <Input
                  value={codeInput}
                  onChange={(e) => setCodeInput(e.target.value)}
                  placeholder="Enter code..."
                  className="bg-gray-800 border-gray-600 text-white flex-1"
                  onKeyPress={(e) => e.key === "Enter" && handleRedeemCode()}
                />
                <Button
                  className="bg-green-600 hover:bg-green-700"
                  onClick={handleRedeemCode}
                >
                  Redeem
                </Button>
              </div>
              {codeMessage && (
                <p className={`text-xs mt-2 ${codeMessage.type === "success" ? "text-green-400" : "text-red-400"}`}>
                  {codeMessage.text}
                </p>
              )}
              <div className="text-xs text-gray-400 mt-2 space-y-1">
                <p><strong>Available codes:</strong></p>
                <p>• "Free Admin" - Sandbox in all servers</p>
                <p>• "StarterPack" - Armor + Sword on new worlds</p>
              </div>
            </div>

            <div className="border-t border-gray-600 pt-3">
              <Button
                variant="outline"
                className="w-full border-red-500 text-red-400 hover:bg-red-500/20"
                onClick={() => setShowDeleteConfirm(true)}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Delete All Data
              </Button>
              <p className="text-xs text-gray-400 mt-2">
                Permanently delete all save slots and progress.
              </p>
            </div>
          </div>

          {showDeleteConfirm && (
            <div className="bg-red-900/30 border border-red-500 rounded p-4 space-y-3">
              <p className="text-red-400 font-bold">Are you sure?</p>
              <p className="text-sm text-gray-300">
                This will permanently delete all your save slots and progress. This cannot be undone.
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1 border-gray-500 text-gray-400"
                  onClick={() => setShowDeleteConfirm(false)}
                >
                  Cancel
                </Button>
                <Button
                  size="sm"
                  className="flex-1 bg-red-600 hover:bg-red-700"
                  onClick={handleDeleteAll}
                >
                  Delete All
                </Button>
              </div>
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <Button
              variant="outline"
              className="flex-1 border-cyan-500 text-cyan-400 hover:bg-cyan-500/20"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button
              className="flex-1 bg-cyan-600 hover:bg-cyan-700"
              onClick={handleApply}
            >
              Apply
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
