import { CubeType, WeaponCategory, WeaponItem, ArmorItem, ArmorSlot } from "./stores/useGameStore";

export const CUBE_COLORS: Record<CubeType, string> = {
  common: "#8B8B8B",
  uncommon: "#4CAF50",
  rare: "#2196F3",
  epic: "#9C27B0",
  legendary: "#FF9800",
  mythic: "#E91E63",
};

export const CUBE_NAMES: Record<CubeType, string> = {
  common: "Common Cube",
  uncommon: "Uncommon Cube",
  rare: "Rare Cube",
  epic: "Epic Cube",
  legendary: "Legendary Cube",
  mythic: "Mythic Cube",
};

export const CUBE_ICONS: Record<CubeType, string> = {
  common: "⚪",
  uncommon: "🟢",
  rare: "🔵",
  epic: "🟣",
  legendary: "🟠",
  mythic: "🌸",
};

export const CUBE_SPAWN_WEIGHTS: Record<CubeType, number> = {
  common: 40,
  uncommon: 25,
  rare: 18,
  epic: 10,
  legendary: 5,
  mythic: 2,
};

export const WEAPON_TIERS = [
  { name: "Wooden", tier: 1, cubeType: "common" as CubeType, cubesRequired: 3 },
  { name: "Stone", tier: 2, cubeType: "uncommon" as CubeType, cubesRequired: 3 },
  { name: "Iron", tier: 3, cubeType: "rare" as CubeType, cubesRequired: 3 },
  { name: "Diamond", tier: 4, cubeType: "epic" as CubeType, cubesRequired: 3 },
  { name: "Obsidian", tier: 5, cubeType: "legendary" as CubeType, cubesRequired: 3 },
  { name: "Mythril", tier: 6, cubeType: "mythic" as CubeType, cubesRequired: 3 },
];

export const WEAPON_CATEGORIES: Record<WeaponCategory, { baseDamage: number; attackSpeed: number; description: string }> = {
  dagger: { baseDamage: 5, attackSpeed: 2.0, description: "Fast but weak" },
  sword: { baseDamage: 10, attackSpeed: 1.2, description: "Balanced weapon" },
  greatsword: { baseDamage: 20, attackSpeed: 0.6, description: "Slow but powerful" },
};

export const generateWeapon = (category: WeaponCategory, tier: number, isBossDrop = false, bossName?: string): WeaponItem => {
  const tierData = WEAPON_TIERS[tier - 1];
  const categoryData = WEAPON_CATEGORIES[category];
  
  const tierMultiplier = tier * 0.5 + 0.5;
  const damage = Math.round(categoryData.baseDamage * tierMultiplier);
  
  let name = `${tierData.name} ${category.charAt(0).toUpperCase() + category.slice(1)}`;
  if (isBossDrop && bossName) {
    name = `${bossName}'s ${category.charAt(0).toUpperCase() + category.slice(1)}`;
  }
  
  return {
    id: `weapon_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    category,
    tier,
    name,
    damage,
    attackSpeed: categoryData.attackSpeed,
    isBossDrop,
    bossName,
  };
};

export const generateUltimateSword = (): WeaponItem => {
  return {
    id: `weapon_ultimate_${Date.now()}`,
    category: "sword",
    tier: 6,
    name: "⚡ Ultimate Sword",
    damage: 500, // ULTIMATE DAMAGE
    attackSpeed: 2.5, // SUPER FAST
    isBossDrop: false,
    bossName: undefined,
  };
};

export const generateGodSword = (): WeaponItem => {
  return {
    id: `weapon_god_${Date.now()}`,
    category: "sword",
    tier: 7,
    name: "👑 GOD SWORD",
    damage: 2000, // GODLY DAMAGE
    attackSpeed: 3.0, // GODLY SPEED
    isBossDrop: false,
    bossName: undefined,
  };
};

export const generateGodArmor = (slot: ArmorSlot): ArmorItem => {
  const defenseMap = {
    helmet: 280,
    chestplate: 400,
    leggings: 320,
  };
  
  return {
    id: `armor_god_${Date.now()}`,
    slot,
    tier: 7,
    name: `👑 GOD ${slot.charAt(0).toUpperCase() + slot.slice(1)}`,
    defense: defenseMap[slot],
    isBossDrop: false,
    bossName: undefined,
  };
};

export const ARMOR_TIERS = [
  { name: "Leather", tier: 1, cubeType: "common" as CubeType, cubesRequired: 2 },
  { name: "Chainmail", tier: 2, cubeType: "uncommon" as CubeType, cubesRequired: 2 },
  { name: "Iron", tier: 3, cubeType: "rare" as CubeType, cubesRequired: 2 },
  { name: "Diamond", tier: 4, cubeType: "epic" as CubeType, cubesRequired: 2 },
  { name: "Obsidian", tier: 5, cubeType: "legendary" as CubeType, cubesRequired: 2 },
  { name: "Mythril", tier: 6, cubeType: "mythic" as CubeType, cubesRequired: 2 },
];

export const ARMOR_SLOTS: Record<ArmorSlot, { defenseMultiplier: number }> = {
  helmet: { defenseMultiplier: 0.7 },
  chestplate: { defenseMultiplier: 1.0 },
  leggings: { defenseMultiplier: 0.85 },
};

export const generateArmor = (slot: ArmorSlot, tier: number, isBossDrop = false, bossName?: string): ArmorItem => {
  const tierData = ARMOR_TIERS[tier - 1];
  const slotData = ARMOR_SLOTS[slot];
  
  const baseDefense = tier * 3;
  const defense = Math.round(baseDefense * slotData.defenseMultiplier);
  
  let name = `${tierData.name} ${slot.charAt(0).toUpperCase() + slot.slice(1)}`;
  if (isBossDrop && bossName) {
    name = `${bossName}'s ${slot.charAt(0).toUpperCase() + slot.slice(1)}`;
  }
  
  return {
    id: `armor_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    slot,
    tier,
    name,
    defense,
    isBossDrop,
    bossName,
  };
};

export const WALL_TYPES = [
  { name: "Wooden Wall", tier: 1, hp: 50, cubeType: "common" as CubeType, cubesRequired: 2, color: "#8B4513" },
  { name: "Stone Wall", tier: 2, hp: 150, cubeType: "uncommon" as CubeType, cubesRequired: 2, color: "#696969" },
  { name: "Iron Wall", tier: 3, hp: 300, cubeType: "rare" as CubeType, cubesRequired: 2, color: "#A8A8A8" },
  { name: "Diamond Wall", tier: 4, hp: 600, cubeType: "epic" as CubeType, cubesRequired: 2, color: "#00FFFF" },
  { name: "Obsidian Wall", tier: 5, hp: 1200, cubeType: "legendary" as CubeType, cubesRequired: 2, color: "#1A0A2E" },
  { name: "Crystal Wall", tier: 6, hp: 2500, cubeType: "mythic" as CubeType, cubesRequired: 2, color: "#FF69B4" },
];

export const BOSS_DATA = [
  { index: 0, name: "Stone Golem", hp: 500, damage: 15, path: "left", order: 1, color: "#696969" },
  { index: 1, name: "Shadow Knight", hp: 800, damage: 20, path: "left", order: 2, color: "#2F2F2F" },
  { index: 2, name: "Frost Giant", hp: 1200, damage: 25, path: "left", order: 3, color: "#87CEEB" },
  { index: 3, name: "Void Lord", hp: 2000, damage: 35, path: "left", order: 4, color: "#4B0082" },
  { index: 4, name: "Flame Demon", hp: 600, damage: 18, path: "right", order: 1, color: "#FF4500" },
  { index: 5, name: "Thunder Titan", hp: 1000, damage: 22, path: "right", order: 2, color: "#FFD700" },
  { index: 6, name: "Death Reaper", hp: 1500, damage: 30, path: "right", order: 3, color: "#8B0000" },
  { index: 7, name: "Chaos Dragon", hp: 2500, damage: 40, path: "right", order: 4, color: "#DC143C" },
];

export const SANDBOX_BOSSES = [
  { index: 8, name: "The Eternal One", hp: 10000, damage: 100, color: "#FFFFFF" },
  { index: 9, name: "World Devourer", hp: 15000, damage: 150, color: "#000000" },
  { index: 10, name: "Primordial Chaos", hp: 25000, damage: 200, color: "#FF00FF" },
];

export const SANDBOX_EXCLUSIVE_WEAPONS: WeaponItem[] = [
  { id: "sandbox_divine_blade", category: "greatsword", tier: 7, name: "Divine Blade", damage: 100, attackSpeed: 1.0 },
  { id: "sandbox_chaos_scythe", category: "greatsword", tier: 7, name: "Chaos Scythe", damage: 120, attackSpeed: 0.8 },
  { id: "sandbox_thunder_lance", category: "sword", tier: 7, name: "Thunder Lance", damage: 80, attackSpeed: 1.5 },
  { id: "sandbox_shadow_dagger", category: "dagger", tier: 7, name: "Shadow Dagger", damage: 50, attackSpeed: 3.0 },
  { id: "sandbox_void_katana", category: "sword", tier: 7, name: "Void Katana", damage: 90, attackSpeed: 1.3 },
  { id: "sandbox_infinity_edge", category: "greatsword", tier: 7, name: "Infinity Edge", damage: 150, attackSpeed: 0.5 },
];

export const SANDBOX_EXCLUSIVE_ARMOR: ArmorItem[] = [
  { id: "sandbox_god_helmet", slot: "helmet", tier: 7, name: "God Helmet", defense: 50 },
  { id: "sandbox_god_chestplate", slot: "chestplate", tier: 7, name: "God Chestplate", defense: 80 },
  { id: "sandbox_god_leggings", slot: "leggings", tier: 7, name: "God Leggings", defense: 65 },
  { id: "sandbox_shadow_helmet", slot: "helmet", tier: 7, name: "Shadow Helmet", defense: 40 },
  { id: "sandbox_shadow_chestplate", slot: "chestplate", tier: 7, name: "Shadow Chestplate", defense: 70 },
  { id: "sandbox_shadow_leggings", slot: "leggings", tier: 7, name: "Shadow Leggings", defense: 55 },
  { id: "sandbox_dragon_helmet", slot: "helmet", tier: 7, name: "Dragon Helmet", defense: 45 },
  { id: "sandbox_dragon_chestplate", slot: "chestplate", tier: 7, name: "Dragon Chestplate", defense: 75 },
  { id: "sandbox_dragon_leggings", slot: "leggings", tier: 7, name: "Dragon Leggings", defense: 60 },
];

export const SANDBOX_UTILITY_ITEMS = [
  { id: "sandbox_teleporter", name: "Teleporter", description: "Teleport to any location" },
  { id: "sandbox_speed_boots", name: "Speed Boots", description: "Move 3x faster" },
  { id: "sandbox_jump_enhancer", name: "Jump Enhancer", description: "Jump 5x higher" },
  { id: "sandbox_shield_generator", name: "Shield Generator", description: "Blocks all damage for 10 seconds" },
  { id: "sandbox_healing_aura", name: "Healing Aura", description: "Regenerate HP rapidly" },
  { id: "sandbox_infinite_cubes", name: "Infinite Cubes", description: "Spawn unlimited cubes" },
  { id: "sandbox_boss_caller", name: "Boss Caller", description: "Summon any boss instantly" },
  { id: "sandbox_time_freezer", name: "Time Freezer", description: "Freeze all enemies" },
  { id: "sandbox_damage_amplifier", name: "Damage Amplifier", description: "10x damage" },
  { id: "sandbox_invincibility", name: "Invincibility Crystal", description: "Become invincible" },
];

export const ENEMY_TYPES = [
  { type: "slime" as const, name: "Slime", hp: 20, damage: 5, color: "#32CD32", coinDrop: [1, 3] },
  { type: "skeleton" as const, name: "Skeleton", hp: 40, damage: 8, color: "#F5F5DC", coinDrop: [2, 5] },
  { type: "zombie" as const, name: "Zombie", hp: 60, damage: 10, color: "#556B2F", coinDrop: [3, 6] },
  { type: "goblin" as const, name: "Goblin", hp: 50, damage: 12, color: "#228B22", coinDrop: [4, 8] },
  { type: "orc" as const, name: "Orc", hp: 100, damage: 15, color: "#3D5A3D", coinDrop: [5, 10] },
  { type: "demon" as const, name: "Demon", hp: 150, damage: 20, color: "#8B0000", coinDrop: [8, 15] },
  { type: "golem" as const, name: "Golem", hp: 200, damage: 18, color: "#808080", coinDrop: [10, 18] },
  { type: "wraith" as const, name: "Wraith", hp: 80, damage: 25, color: "#4B0082", coinDrop: [12, 20] },
  { type: "dragon_whelp" as const, name: "Dragon Whelp", hp: 120, damage: 22, color: "#FF6347", coinDrop: [15, 25] },
  { type: "shadow" as const, name: "Shadow", hp: 100, damage: 30, color: "#1C1C1C", coinDrop: [18, 30] },
];

export const ISLAND_DATA = [
  {
    id: 0,
    name: "Starter Island",
    position: [0, 0, 0] as [number, number, number],
    size: 50,
    color: "#7CFC00",
    enemies: [],
    hasCrystal: true,
    cubeSpawnRate: 5000,
  },
  {
    id: 1,
    name: "Forest Island",
    position: [200, 0, 0] as [number, number, number],
    size: 40,
    color: "#228B22",
    enemies: ["slime", "skeleton", "goblin"] as const,
    hasCrystal: false,
    cubeSpawnRate: 8000,
    bosses: [0, 4],
  },
  {
    id: 2,
    name: "Mountain Island",
    position: [0, 0, 200] as [number, number, number],
    size: 45,
    color: "#808080",
    enemies: ["zombie", "orc", "golem"] as const,
    hasCrystal: false,
    cubeSpawnRate: 10000,
    bosses: [1, 5],
  },
  {
    id: 3,
    name: "Dark Island",
    position: [-200, 0, 0] as [number, number, number],
    size: 35,
    color: "#2F2F2F",
    enemies: ["demon", "wraith", "shadow"] as const,
    hasCrystal: false,
    cubeSpawnRate: 12000,
    bosses: [2, 3, 6, 7],
  },
  { id: 4, name: "Crystal Cavern", position: [200, 0, 200] as [number, number, number], size: 40, color: "#00FFFF", enemies: ["golem", "demon"] as const, hasCrystal: false, cubeSpawnRate: 9000, bosses: [0] },
  { id: 5, name: "Lava Fields", position: [-200, 0, 200] as [number, number, number], size: 42, color: "#FF4500", enemies: ["demon", "dragon_whelp"] as const, hasCrystal: false, cubeSpawnRate: 11000, bosses: [4] },
  { id: 6, name: "Frozen Tundra", position: [200, 0, -200] as [number, number, number], size: 38, color: "#87CEEB", enemies: ["wraith", "shadow"] as const, hasCrystal: false, cubeSpawnRate: 10000, bosses: [2] },
  { id: 7, name: "Mystic Grove", position: [-200, 0, -200] as [number, number, number], size: 44, color: "#8B008B", enemies: ["skeleton", "goblin"] as const, hasCrystal: false, cubeSpawnRate: 8500, bosses: [1] },
  { id: 8, name: "Sky Islands", position: [300, 0, 100] as [number, number, number], size: 35, color: "#E0FFFF", enemies: ["skeleton"] as const, hasCrystal: false, cubeSpawnRate: 7000, bosses: [5] },
  { id: 9, name: "Void Realm", position: [-300, 0, 100] as [number, number, number], size: 40, color: "#1A0A2E", enemies: ["wraith", "demon", "shadow"] as const, hasCrystal: false, cubeSpawnRate: 12000, bosses: [3] },
  { id: 10, name: "Amber Valley", position: [100, 0, 300] as [number, number, number], size: 38, color: "#FFB347", enemies: ["zombie", "orc"] as const, hasCrystal: false, cubeSpawnRate: 9500, bosses: [6] },
  { id: 11, name: "Sapphire Bay", position: [-100, 0, 300] as [number, number, number], size: 36, color: "#0047AB", enemies: ["slime", "zombie"] as const, hasCrystal: false, cubeSpawnRate: 8000, bosses: [7] },
  { id: 12, name: "Emerald Forest", position: [100, 0, -300] as [number, number, number], size: 42, color: "#50C878", enemies: ["goblin", "orc"] as const, hasCrystal: false, cubeSpawnRate: 9000, bosses: [4] },
  { id: 13, name: "Ruby Canyon", position: [-100, 0, -300] as [number, number, number], size: 40, color: "#E0115F", enemies: ["demon", "golem"] as const, hasCrystal: false, cubeSpawnRate: 10500, bosses: [5] },
  { id: 14, name: "Golden Peak", position: [280, 0, 280] as [number, number, number], size: 35, color: "#FFD700", enemies: ["dragon_whelp", "shadow"] as const, hasCrystal: false, cubeSpawnRate: 11000, bosses: [6] },
  { id: 15, name: "Silver Lagoon", position: [-280, 0, 280] as [number, number, number], size: 38, color: "#C0C0C0", enemies: ["skeleton", "wraith"] as const, hasCrystal: false, cubeSpawnRate: 8500, bosses: [3] },
  { id: 16, name: "Obsidian Peaks", position: [280, 0, -280] as [number, number, number], size: 40, color: "#1C1C1C", enemies: ["orc", "demon"] as const, hasCrystal: false, cubeSpawnRate: 10000, bosses: [7] },
  { id: 17, name: "Pearl Coast", position: [-280, 0, -280] as [number, number, number], size: 37, color: "#FFFACD", enemies: ["slime", "skeleton"] as const, hasCrystal: false, cubeSpawnRate: 7500, bosses: [2] },
  { id: 18, name: "Titan's Throne", position: [0, 0, 350] as [number, number, number], size: 50, color: "#696969", enemies: ["golem", "dragon_whelp", "shadow"] as const, hasCrystal: false, cubeSpawnRate: 13000, bosses: [1] },
];

export const CRAFTING_RECIPES = {
  weapons: WEAPON_TIERS.flatMap(tier => 
    (["dagger", "sword", "greatsword"] as WeaponCategory[]).map(category => ({
      result: `${tier.name} ${category.charAt(0).toUpperCase() + category.slice(1)}`,
      category,
      tier: tier.tier,
      cubeType: tier.cubeType,
      cubesRequired: tier.cubesRequired,
    }))
  ),
  armor: ARMOR_TIERS.flatMap(tier => 
    (["helmet", "chestplate", "leggings"] as ArmorSlot[]).map(slot => ({
      result: `${tier.name} ${slot.charAt(0).toUpperCase() + slot.slice(1)}`,
      slot,
      tier: tier.tier,
      cubeType: tier.cubeType,
      cubesRequired: tier.cubesRequired,
    }))
  ),
  walls: WALL_TYPES.map(wall => ({
    result: wall.name,
    tier: wall.tier,
    cubeType: wall.cubeType,
    cubesRequired: wall.cubesRequired,
    hp: wall.hp,
  })),
  lifeCube: {
    result: "Life Cube",
    cubeType: "epic" as CubeType,
    cubesRequired: 5,
  },
  inventoryUpgrades: [
    { result: "Pack", fromSlots: 1, toSlots: 2, cubeType: "common" as CubeType, cubesRequired: 10 },
    { result: "Container", fromSlots: 2, toSlots: 3, cubeType: "uncommon" as CubeType, cubesRequired: 10 },
    { result: "Backpack", fromSlots: 3, toSlots: 4, cubeType: "rare" as CubeType, cubesRequired: 10 },
  ],
  platforms: [
    { result: "Wooden Platform", cubeType: "common" as CubeType, cubesRequired: 5 },
    { result: "Stone Platform", cubeType: "uncommon" as CubeType, cubesRequired: 5 },
  ],
  legendaryWeapons: [
    { result: "Eternal Dagger", category: "dagger" as WeaponCategory, tier: 6, cubeType: "mythic" as CubeType, cubesRequired: 4 },
    { result: "Eternal Sword", category: "sword" as WeaponCategory, tier: 6, cubeType: "mythic" as CubeType, cubesRequired: 4 },
    { result: "Eternal Greatsword", category: "greatsword" as WeaponCategory, tier: 6, cubeType: "mythic" as CubeType, cubesRequired: 5 },
  ],
  legendaryArmor: [
    { result: "Eternal Helmet", slot: "helmet" as ArmorSlot, tier: 6, cubeType: "mythic" as CubeType, cubesRequired: 4 },
    { result: "Eternal Chestplate", slot: "chestplate" as ArmorSlot, tier: 6, cubeType: "mythic" as CubeType, cubesRequired: 5 },
    { result: "Eternal Leggings", slot: "leggings" as ArmorSlot, tier: 6, cubeType: "mythic" as CubeType, cubesRequired: 4 },
  ],
  advancedWeapons: [
    { result: "Obsidian Dagger", category: "dagger" as WeaponCategory, tier: 5, cubeType: "legendary" as CubeType, cubesRequired: 4 },
    { result: "Obsidian Sword", category: "sword" as WeaponCategory, tier: 5, cubeType: "legendary" as CubeType, cubesRequired: 4 },
    { result: "Obsidian Greatsword", category: "greatsword" as WeaponCategory, tier: 5, cubeType: "legendary" as CubeType, cubesRequired: 5 },
  ],
  advancedArmor: [
    { result: "Obsidian Helmet", slot: "helmet" as ArmorSlot, tier: 5, cubeType: "legendary" as CubeType, cubesRequired: 4 },
    { result: "Obsidian Chestplate", slot: "chestplate" as ArmorSlot, tier: 5, cubeType: "legendary" as CubeType, cubesRequired: 5 },
    { result: "Obsidian Leggings", slot: "leggings" as ArmorSlot, tier: 5, cubeType: "legendary" as CubeType, cubesRequired: 4 },
  ],
};

export const getRandomCubeType = (): CubeType => {
  const totalWeight = Object.values(CUBE_SPAWN_WEIGHTS).reduce((sum, w) => sum + w, 0);
  let random = Math.random() * totalWeight;
  
  for (const [type, weight] of Object.entries(CUBE_SPAWN_WEIGHTS)) {
    random -= weight;
    if (random <= 0) {
      return type as CubeType;
    }
  }
  
  return "common";
};

export const getGridPosition = (islandId: number): [number, number, number] => {
  const gridSize = 300;
  const cols = 5;
  const row = Math.floor(islandId / cols);
  const col = islandId % cols;
  const x = (col - 2) * gridSize;
  const z = (row - 2) * gridSize;
  return [x, 0, z];
};

export const getRandomCoinAmount = (min: number, max: number): number => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};
