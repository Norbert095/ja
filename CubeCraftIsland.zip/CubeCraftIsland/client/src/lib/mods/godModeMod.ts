import { Mod } from "./types";

export const godModeMod: Mod = {
  id: "godModeMod",
  name: "👑 GOD MODE",
  description: "20K HP, 800 Defense, 2000 Damage sword, 3x Speed - ULTIMATE POWER",
  version: "1.0.0",
  author: "Game Dev",
  apply: (currentSlot) => {
    return currentSlot?.enabledMods?.includes("godModeMod") ?? false;
  },
};

export const isGodModeActive = (enabledMods: string[]): boolean => {
  return enabledMods.includes("godModeMod");
};
