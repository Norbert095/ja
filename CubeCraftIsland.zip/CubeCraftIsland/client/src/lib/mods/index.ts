import { ModRegistry } from "./types";
import { noCoinsMod } from "./noCoinsMod";
import { opPowerMod } from "./opPowerMod";
import { speedDemonMod } from "./speedDemonMod";
import { godModeMod } from "./godModeMod";

// Register all available mods here
export const MOD_REGISTRY: ModRegistry = {
  noCoinsMod,
  opPowerMod,
  speedDemonMod,
  godModeMod,
};

// Get all available mods as an array
export const getAvailableMods = () => Object.values(MOD_REGISTRY);

// Check if a specific mod is active in a slot
export const isModActive = (modId: string, enabledMods: string[]): boolean => {
  return enabledMods.includes(modId);
};

// Check if any mods are active
export const hasActiveMods = (enabledMods: string[]): boolean => {
  return enabledMods.length > 0;
};
