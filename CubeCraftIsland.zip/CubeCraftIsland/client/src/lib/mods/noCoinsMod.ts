import { Mod } from "./types";

export const noCoinsMod: Mod = {
  id: "noCoinsMod",
  name: "🚫 No Coins Mode",
  description: "Disable coin earnings in this world",
  version: "1.0.0",
  author: "Game Dev",
  apply: (currentSlot) => {
    // This mod is active if it's enabled in the slot
    return currentSlot?.enabledMods?.includes("noCoinsMod") ?? false;
  },
};
