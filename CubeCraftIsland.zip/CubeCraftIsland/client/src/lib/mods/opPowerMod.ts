import { Mod } from "./types";

export const opPowerMod: Mod = {
  id: "opPowerMod",
  name: "💥 OP Power",
  description: "5K HP, 100 Defense, and Ultimate Sword",
  version: "1.0.0",
  author: "Game Dev",
  apply: (currentSlot) => {
    return currentSlot?.enabledMods?.includes("opPowerMod") ?? false;
  },
};

// Helper to check if mod is active
export const isOPPowerModActive = (enabledMods: string[]): boolean => {
  return enabledMods.includes("opPowerMod");
};
