import { Mod } from "./types";

export const speedDemonMod: Mod = {
  id: "speedDemonMod",
  name: "⚡ Speed Demon",
  description: "Move 3x faster - zoom across the map!",
  version: "1.0.0",
  author: "Game Dev",
  apply: (currentSlot) => {
    return currentSlot?.enabledMods?.includes("speedDemonMod") ?? false;
  },
};

export const isSpeedDemonModActive = (enabledMods: string[]): boolean => {
  return enabledMods.includes("speedDemonMod");
};

export const getSpeedMultiplier = (enabledMods: string[]): number => {
  return isSpeedDemonModActive(enabledMods) ? 3.0 : 1.0;
};
