export interface Mod {
  id: string;
  name: string;
  description: string;
  version: string;
  author: string;
  apply: (currentSlot: any) => boolean; // Returns true if mod is active
}

export interface ModRegistry {
  [modId: string]: Mod;
}
