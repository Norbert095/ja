import { create } from "zustand";

interface AudioState {
  backgroundMusic: HTMLAudioElement | null;
  hitSound: HTMLAudioElement | null;
  successSound: HTMLAudioElement | null;
  isMuted: boolean;
  musicVolume: number;
  sfxVolume: number;
  
  setBackgroundMusic: (music: HTMLAudioElement) => void;
  setHitSound: (sound: HTMLAudioElement) => void;
  setSuccessSound: (sound: HTMLAudioElement) => void;
  
  toggleMute: () => void;
  setMusicVolume: (volume: number) => void;
  setSfxVolume: (volume: number) => void;
  
  playHit: () => void;
  playSuccess: () => void;
  playBackgroundMusic: () => void;
  pauseBackgroundMusic: () => void;
}

export const useAudio = create<AudioState>((set, get) => ({
  backgroundMusic: null,
  hitSound: null,
  successSound: null,
  isMuted: false,
  musicVolume: 0.3,
  sfxVolume: 0.5,
  
  setBackgroundMusic: (music) => {
    music.volume = get().musicVolume;
    set({ backgroundMusic: music });
  },
  
  setHitSound: (sound) => {
    sound.volume = get().sfxVolume;
    set({ hitSound: sound });
  },
  
  setSuccessSound: (sound) => {
    sound.volume = get().sfxVolume;
    set({ successSound: sound });
  },
  
  toggleMute: () => {
    const { isMuted, backgroundMusic, musicVolume } = get();
    const newMutedState = !isMuted;
    
    set({ isMuted: newMutedState });
    
    if (backgroundMusic) {
      if (newMutedState) {
        backgroundMusic.pause();
      } else {
        backgroundMusic.volume = musicVolume;
        backgroundMusic.play().catch(console.log);
      }
    }
    
    console.log(`Sound ${newMutedState ? 'muted' : 'unmuted'}`);
  },
  
  setMusicVolume: (volume) => {
    const { backgroundMusic } = get();
    set({ musicVolume: volume });
    if (backgroundMusic) {
      backgroundMusic.volume = volume;
    }
  },
  
  setSfxVolume: (volume) => {
    const { hitSound, successSound } = get();
    set({ sfxVolume: volume });
    if (hitSound) hitSound.volume = volume;
    if (successSound) successSound.volume = volume;
  },
  
  playHit: () => {
    const { hitSound, isMuted, sfxVolume } = get();
    if (hitSound && !isMuted) {
      const soundClone = hitSound.cloneNode() as HTMLAudioElement;
      soundClone.volume = sfxVolume;
      soundClone.play().catch(error => {
        console.log("Hit sound play prevented:", error);
      });
    }
  },
  
  playSuccess: () => {
    const { successSound, isMuted, sfxVolume } = get();
    if (successSound && !isMuted) {
      successSound.currentTime = 0;
      successSound.volume = sfxVolume;
      successSound.play().catch(error => {
        console.log("Success sound play prevented:", error);
      });
    }
  },
  
  playBackgroundMusic: () => {
    const { backgroundMusic, isMuted, musicVolume } = get();
    if (backgroundMusic && !isMuted) {
      backgroundMusic.volume = musicVolume;
      backgroundMusic.play().catch(console.log);
    }
  },
  
  pauseBackgroundMusic: () => {
    const { backgroundMusic } = get();
    if (backgroundMusic) {
      backgroundMusic.pause();
    }
  }
}));
