import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import { generateWeapon, generateArmor, generateUltimateSword, generateGodSword, generateGodArmor } from "@/lib/gameData";
import { isModActive } from "@/lib/mods";
import { isGodModeActive } from "@/lib/mods/godModeMod";

export type GamePhase = "menu" | "slot_select" | "playing" | "paused" | "game_over" | "sandbox";

export type CubeType = "common" | "uncommon" | "rare" | "epic" | "legendary" | "mythic";
export type WeaponCategory = "dagger" | "sword" | "greatsword";
export type ArmorSlot = "helmet" | "chestplate" | "leggings";

export interface CubeItem {
  id: string;
  type: CubeType;
  position: [number, number, number];
}

export interface WeaponItem {
  id: string;
  category: WeaponCategory;
  tier: number;
  name: string;
  damage: number;
  attackSpeed: number;
  isBossDrop?: boolean;
  bossName?: string;
}

export interface ArmorItem {
  id: string;
  slot: ArmorSlot;
  tier: number;
  name: string;
  defense: number;
  isBossDrop?: boolean;
  bossName?: string;
}

export interface WallItem {
  id: string;
  tier: number;
  name: string;
  hp: number;
  maxHp: number;
  position: [number, number, number];
  rotation: number;
}

export interface LootBox {
  id: string;
  position: [number, number, number];
  isOpen: boolean;
  contents: Array<CubeItem | WeaponItem | ArmorItem | { type: "coins"; amount: number }>;
}

export interface Enemy {
  id: string;
  name: string;
  hp: number;
  maxHp: number;
  damage: number;
  position: [number, number, number];
  type: "slime" | "skeleton" | "zombie" | "goblin" | "orc" | "demon" | "golem" | "wraith" | "dragon_whelp" | "shadow";
  isAggro: boolean;
  isBoss: boolean;
  bossIndex?: number;
  drops: Array<CubeItem | { type: "coins"; amount: number } | { type: "boss_material"; name: string }>;
}

export interface SaveSlot {
  id: number;
  name: string;
  coins: number;
  crystalHp: number;
  crystalReviveCost: number;
  inventorySlots: number;
  hasSandbox: boolean;
  worldType: "standard" | "grid";
  cubes: Record<CubeType, number>;
  weapons: WeaponItem[];
  armor: ArmorItem[];
  walls: WallItem[];
  equippedWeapon: WeaponItem | null;
  equippedWall: WallItem | null;
  equippedArmor: Record<ArmorSlot, ArmorItem | null>;
  offhandItem: WeaponItem | ArmorItem | null;
  placedWalls: WallItem[];
  defeatedBosses: number[];
  lifeCubes: number;
  playTime: number;
  lastSave: number;
  enabledMods: string[];
}

interface GameState {
  phase: GamePhase;
  currentSlot: SaveSlot | null;
  availableSlots: number;
  maxSlots: number;
  slotCost: number;
  slots: SaveSlot[];
  
  playerHp: number;
  maxPlayerHp: number;
  playerPosition: [number, number, number];
  
  worldCubes: CubeItem[];
  worldEnemies: Enemy[];
  worldLootBoxes: LootBox[];
  
  heldItem: CubeItem | WeaponItem | ArmorItem | WallItem | null;
  
  isMuted: boolean;
  showControls: boolean;
  renderDistance: number;
  mobileControlsEnabled: boolean;
  redeemedCodes: string[];
  hasFreeAdmin: boolean;
  hasStarterPack: boolean;
  
  setPhase: (phase: GamePhase) => void;
  setRenderDistance: (distance: number) => void;
  setMobileControlsEnabled: (enabled: boolean) => void;
  redeemCode: (code: string) => boolean;
  loadSlot: (slotId: number) => void;
  createSlot: (name: string) => void;
  deleteSlot: (slotId: number) => void;
  purchaseSlot: () => boolean;
  saveGame: () => void;
  
  spawnCube: (type: CubeType, position: [number, number, number]) => void;
  pickupCube: (cubeId: string) => void;
  dropHeldItem: (position: [number, number, number]) => void;
  
  takeDamage: (amount: number) => void;
  heal: (amount: number) => void;
  respawn: () => void;
  
  damageCrystal: (amount: number) => void;
  reviveCrystal: () => boolean;
  
  equipWeapon: (weapon: WeaponItem) => void;
  equipArmor: (armor: ArmorItem) => void;
  equipWall: (wall: WallItem) => void;
  unequipWeapon: () => void;
  unequipArmor: (slot: ArmorSlot) => void;
  unequipWall: () => void;
  
  addCoins: (amount: number) => void;
  spendCoins: (amount: number) => boolean;
  
  unlockSandbox: () => boolean;
  toggleMod: (modId: string) => void;
  
  toggleMute: () => void;
  toggleControls: () => void;
  
  addCubeToInventory: (type: CubeType, amount: number) => void;
  removeCubeFromInventory: (type: CubeType, amount: number) => boolean;
  
  upgradeInventory: () => boolean;
  
  spawnEnemy: (enemy: Omit<Enemy, "id">) => void;
  damageEnemy: (enemyId: string, damage: number) => void;
  removeEnemy: (enemyId: string) => void;
  
  defeatBoss: (bossIndex: number) => void;
  
  useLifeCube: () => boolean;
  addLifeCube: () => void;
  
  updatePlayerPosition: (position: [number, number, number]) => void;
  
  placeWall: (wall: WallItem) => void;
  removeWall: (wallId: string) => void;
  damageWall: (wallId: string, damage: number) => void;
  
  deleteAllData: () => void;
}

const DEFAULT_SLOT: Omit<SaveSlot, "id" | "name"> = {
  coins: 0,
  crystalHp: 5000,
  crystalReviveCost: 10,
  inventorySlots: 1,
  hasSandbox: false,
  worldType: "standard",
  cubes: {
    common: 0,
    uncommon: 0,
    rare: 0,
    epic: 0,
    legendary: 0,
    mythic: 0,
  },
  weapons: [],
  armor: [],
  walls: [],
  equippedWeapon: null,
  equippedWall: null,
  equippedArmor: {
    helmet: null,
    chestplate: null,
    leggings: null,
  },
  offhandItem: null,
  placedWalls: [],
  defeatedBosses: [],
  lifeCubes: 0,
  playTime: 0,
  lastSave: Date.now(),
  enabledMods: [],
};

const loadSlotsFromStorage = (): SaveSlot[] => {
  try {
    const saved = localStorage.getItem("cubeCombination_slots");
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error("Failed to load slots:", e);
  }
  return [];
};

const loadAvailableSlotsFromStorage = (): number => {
  try {
    const saved = localStorage.getItem("cubeCombination_availableSlots");
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error("Failed to load available slots:", e);
  }
  return 2;
};

const loadRedeemedCodesFromStorage = (): string[] => {
  try {
    const saved = localStorage.getItem("cubeCombination_redeemedCodes");
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error("Failed to load redeemed codes:", e);
  }
  return [];
};

const redeemedCodes = loadRedeemedCodesFromStorage();
const hasFreeAdmin = redeemedCodes.includes("Free Admin");
const hasStarterPack = redeemedCodes.includes("StarterPack");

export const useGameStore = create<GameState>()(
  subscribeWithSelector((set, get) => ({
    phase: "menu",
    currentSlot: null,
    availableSlots: loadAvailableSlotsFromStorage(),
    maxSlots: 7,
    slotCost: 25,
    slots: loadSlotsFromStorage(),
    
    playerHp: 100,
    maxPlayerHp: 100,
    playerPosition: [0, 1.6, 0],
    
    worldCubes: [],
    worldEnemies: [],
    worldLootBoxes: [],
    
    heldItem: null,
    
    isMuted: false,
    showControls: true,
    renderDistance: 300,
    mobileControlsEnabled: false,
    redeemedCodes,
    hasFreeAdmin,
    hasStarterPack,
    
    setPhase: (phase) => set({ phase }),
    redeemCode: (code) => {
      const { redeemedCodes, slots } = get();
      
      if (redeemedCodes.includes(code)) return false;
      
      const validCodes = ["Free Admin", "StarterPack"];
      if (!validCodes.includes(code)) return false;
      
      const newRedeemedCodes = [...redeemedCodes, code];
      
      if (code === "Free Admin") {
        // Grant sandbox to all existing slots
        const updatedSlots = slots.map(slot => ({ ...slot, hasSandbox: true }));
        set({ 
          redeemedCodes: newRedeemedCodes, 
          hasFreeAdmin: true,
          slots: updatedSlots,
          currentSlot: get().currentSlot ? { ...get().currentSlot, hasSandbox: true } : null
        });
        localStorage.setItem("cubeCombination_slots", JSON.stringify(updatedSlots));
      } else if (code === "StarterPack") {
        set({ redeemedCodes: newRedeemedCodes, hasStarterPack: true });
      }
      
      localStorage.setItem("cubeCombination_redeemedCodes", JSON.stringify(newRedeemedCodes));
      return true;
    },
    
    loadSlot: (slotId) => {
      const { slots } = get();
      let slot = slots.find(s => s.id === slotId);
      if (slot) {
        let playerHp = 100;
        let modifiedSlot = slot;
        
        // Apply GOD MODE Mod bonuses
        if (isGodModeActive(slot.enabledMods)) {
          playerHp = 20000;
          
          // Add GOD Sword if not already have one
          const hasGodSword = slot.weapons.some(w => w.name.includes("GOD"));
          if (!hasGodSword) {
            const godSword = generateGodSword();
            modifiedSlot = {
              ...slot,
              weapons: [...(slot.weapons || []), godSword],
              equippedWeapon: godSword,
            };
          }
          
          // Add GOD armor set if not already has it
          const hasGodArmor = slot.equippedArmor.helmet?.name.includes("GOD");
          
          if (!hasGodArmor) {
            const godHelmet = generateGodArmor("helmet");
            const godChestplate = generateGodArmor("chestplate");
            const godLeggings = generateGodArmor("leggings");
            
            modifiedSlot = {
              ...modifiedSlot,
              armor: [...(modifiedSlot.armor || []), godHelmet, godChestplate, godLeggings],
              equippedArmor: {
                helmet: godHelmet,
                chestplate: godChestplate,
                leggings: godLeggings,
              },
            };
          }
        } else if (isModActive("opPowerMod", slot.enabledMods)) {
          // Apply OP Power Mod bonuses
          playerHp = 5000;
          
          // Add Ultimate Sword if not already have one
          const hasUltimateSword = slot.weapons.some(w => w.name.includes("Ultimate"));
          if (!hasUltimateSword) {
            const ultimateSword = generateUltimateSword();
            modifiedSlot = {
              ...slot,
              weapons: [...(slot.weapons || []), ultimateSword],
              equippedWeapon: ultimateSword,
            };
          }
          
          // Add max defense armor set if not already maxed
          const maxDefense = slot.equippedArmor.helmet?.defense === 21 && 
                            slot.equippedArmor.chestplate?.defense === 30 && 
                            slot.equippedArmor.leggings?.defense === 25;
          
          if (!maxDefense) {
            const mythrilHelmet = generateArmor("helmet", 6);
            const mythrilChestplate = generateArmor("chestplate", 6);
            const mythrilLeggings = generateArmor("leggings", 6);
            
            modifiedSlot = {
              ...modifiedSlot,
              armor: [...(modifiedSlot.armor || []), mythrilHelmet, mythrilChestplate, mythrilLeggings],
              equippedArmor: {
                helmet: mythrilHelmet,
                chestplate: mythrilChestplate,
                leggings: mythrilLeggings,
              },
            };
          }
        }
        
        set({ currentSlot: modifiedSlot, phase: "playing", playerHp });
      }
    },
    
    createSlot: (name) => {
      const { slots, availableSlots, hasStarterPack, hasFreeAdmin } = get();
      if (slots.length >= availableSlots) return;
      
      let newSlot: SaveSlot = {
        ...DEFAULT_SLOT,
        id: Date.now(),
        name: name || `World ${slots.length + 1}`,
        hasSandbox: hasFreeAdmin, // Auto-grant sandbox if Free Admin is active
      };
      
      // Add starter gear if StarterPack code was redeemed
      if (hasStarterPack) {
        const starterWeapon = generateWeapon("sword", 1);
        const helmetArmor = generateArmor("helmet", 1);
        const chestplateArmor = generateArmor("chestplate", 1);
        const leggingsArmor = generateArmor("leggings", 1);
        
        newSlot = {
          ...newSlot,
          weapons: [starterWeapon],
          armor: [helmetArmor, chestplateArmor, leggingsArmor],
          equippedWeapon: starterWeapon,
          equippedArmor: {
            helmet: helmetArmor,
            chestplate: chestplateArmor,
            leggings: leggingsArmor,
          },
        };
      }
      
      const newSlots = [...slots, newSlot];
      set({ slots: newSlots, currentSlot: newSlot, phase: "playing" });
      localStorage.setItem("cubeCombination_slots", JSON.stringify(newSlots));
    },
    
    deleteSlot: (slotId) => {
      const { slots, currentSlot } = get();
      const newSlots = slots.filter(s => s.id !== slotId);
      const newCurrentSlot = currentSlot?.id === slotId ? null : currentSlot;
      
      set({ slots: newSlots, currentSlot: newCurrentSlot, phase: newCurrentSlot ? "playing" : "slot_select" });
      localStorage.setItem("cubeCombination_slots", JSON.stringify(newSlots));
    },
    
    purchaseSlot: () => {
      const { availableSlots, maxSlots, slotCost, currentSlot } = get();
      if (availableSlots >= maxSlots) return false;
      if (!currentSlot || currentSlot.coins < slotCost) return false;
      
      const newAvailable = availableSlots + 1;
      const newSlot = { ...currentSlot, coins: currentSlot.coins - slotCost };
      
      set({ availableSlots: newAvailable, currentSlot: newSlot });
      localStorage.setItem("cubeCombination_availableSlots", JSON.stringify(newAvailable));
      get().saveGame();
      return true;
    },
    
    saveGame: () => {
      const { currentSlot, slots } = get();
      if (!currentSlot) return;
      
      const updatedSlot = { ...currentSlot, lastSave: Date.now() };
      const newSlots = slots.map(s => s.id === updatedSlot.id ? updatedSlot : s);
      
      set({ slots: newSlots, currentSlot: updatedSlot });
      localStorage.setItem("cubeCombination_slots", JSON.stringify(newSlots));
    },
    
    spawnCube: (type, position) => {
      const cube: CubeItem = {
        id: `cube_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        type,
        position,
      };
      set(state => ({ worldCubes: [...state.worldCubes, cube] }));
    },
    
    pickupCube: (cubeId) => {
      const { worldCubes, heldItem } = get();
      if (heldItem) return;
      
      const cube = worldCubes.find(c => c.id === cubeId);
      if (cube) {
        set({
          worldCubes: worldCubes.filter(c => c.id !== cubeId),
          heldItem: cube,
        });
      }
    },
    
    dropHeldItem: (position) => {
      const { heldItem } = get();
      if (!heldItem) return;
      
      if ("type" in heldItem && ["common", "uncommon", "rare", "epic", "legendary", "mythic"].includes(heldItem.type)) {
        const cube = heldItem as CubeItem;
        set(state => ({
          worldCubes: [...state.worldCubes, { ...cube, position }],
          heldItem: null,
        }));
      } else {
        set({ heldItem: null });
      }
    },
    
    takeDamage: (amount) => {
      const { playerHp, currentSlot } = get();
      
      let actualDamage = amount;
      if (currentSlot) {
        const totalDefense = Object.values(currentSlot.equippedArmor)
          .filter(Boolean)
          .reduce((sum, armor) => sum + (armor?.defense || 0), 0);
        actualDamage = Math.max(1, amount - totalDefense);
      }
      
      const newHp = Math.max(0, playerHp - actualDamage);
      set({ playerHp: newHp });
      
      if (newHp <= 0) {
        const used = get().useLifeCube();
        if (!used) {
          set({ phase: "game_over" });
        }
      }
    },
    
    heal: (amount) => {
      const { playerHp, maxPlayerHp } = get();
      set({ playerHp: Math.min(maxPlayerHp, playerHp + amount) });
    },
    
    respawn: () => {
      set({ playerHp: 100, playerPosition: [0, 1.6, 0], phase: "playing" });
    },
    
    damageCrystal: (amount) => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      const newHp = Math.max(0, currentSlot.crystalHp - amount);
      const newSlot = { ...currentSlot, crystalHp: newHp };
      set({ currentSlot: newSlot });
      
      if (newHp <= 0) {
        set({ phase: "game_over" });
      }
      
      get().saveGame();
    },
    
    reviveCrystal: () => {
      const { currentSlot } = get();
      if (!currentSlot) return false;
      if (currentSlot.coins < currentSlot.crystalReviveCost) return false;
      
      const newSlot = {
        ...currentSlot,
        coins: currentSlot.coins - currentSlot.crystalReviveCost,
        crystalHp: 5000,
        crystalReviveCost: currentSlot.crystalReviveCost + 5,
      };
      
      set({ currentSlot: newSlot, phase: "playing" });
      get().saveGame();
      return true;
    },
    
    equipWeapon: (weapon) => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      const newWeapons = [...(currentSlot.weapons || [])];
      const weaponIndex = newWeapons.findIndex(w => w.id === weapon.id);
      if (weaponIndex > -1) {
        newWeapons.splice(weaponIndex, 1);
      }
      
      const newSlot = { ...currentSlot, equippedWeapon: weapon, weapons: newWeapons };
      set({ currentSlot: newSlot });
    },
    
    equipArmor: (armor) => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      const newEquipped = { ...currentSlot.equippedArmor, [armor.slot]: armor };
      const newSlot = { ...currentSlot, equippedArmor: newEquipped };
      set({ currentSlot: newSlot });
    },
    
    unequipWeapon: () => {
      const { currentSlot } = get();
      if (!currentSlot || !currentSlot.equippedWeapon) return;
      
      const newWeapons = [...(currentSlot.weapons || []), currentSlot.equippedWeapon];
      const newSlot = { ...currentSlot, equippedWeapon: null, weapons: newWeapons };
      set({ currentSlot: newSlot });
    },
    
    unequipArmor: (slot) => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      const newEquipped = { ...currentSlot.equippedArmor, [slot]: null };
      const newSlot = { ...currentSlot, equippedArmor: newEquipped };
      set({ currentSlot: newSlot });
    },
    
    equipWall: (wall) => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      const newWalls = currentSlot.walls.filter(w => w.id !== wall.id);
      const newSlot = { ...currentSlot, equippedWall: wall, walls: newWalls };
      set({ currentSlot: newSlot });
    },
    
    unequipWall: () => {
      const { currentSlot } = get();
      if (!currentSlot || !currentSlot.equippedWall) return;
      
      const newWalls = [...currentSlot.walls, currentSlot.equippedWall];
      const newSlot = { ...currentSlot, equippedWall: null, walls: newWalls };
      set({ currentSlot: newSlot });
    },
    
    addCoins: (amount) => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      // Don't earn coins in sandbox or if any mods are enabled (prevents cheating)
      if (currentSlot.hasSandbox || currentSlot.enabledMods.length > 0) {
        console.log("[Game] Coins blocked: sandbox or mods active");
        return;
      }
      
      const newSlot = { ...currentSlot, coins: currentSlot.coins + amount };
      set({ currentSlot: newSlot });
    },
    
    spendCoins: (amount) => {
      const { currentSlot } = get();
      if (!currentSlot || currentSlot.coins < amount) return false;
      
      const newSlot = { ...currentSlot, coins: currentSlot.coins - amount };
      set({ currentSlot: newSlot });
      return true;
    },
    
    unlockSandbox: () => {
      const { currentSlot, hasFreeAdmin } = get();
      if (!currentSlot) return false;
      if (currentSlot.hasSandbox) return true;
      
      if (hasFreeAdmin) {
        const newSlot = { ...currentSlot, hasSandbox: true };
        set({ currentSlot: newSlot });
        get().saveGame();
        return true;
      }
      
      if (currentSlot.coins < 250) return false;
      
      const newSlot = { ...currentSlot, coins: currentSlot.coins - 250, hasSandbox: true };
      set({ currentSlot: newSlot });
      get().saveGame();
      return true;
    },
    
    toggleMod: (modId) => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      const enabledMods = currentSlot.enabledMods.includes(modId)
        ? currentSlot.enabledMods.filter(m => m !== modId)
        : [...currentSlot.enabledMods, modId];
      
      const newSlot = { ...currentSlot, enabledMods };
      set({ currentSlot: newSlot });
      get().saveGame();
    },
    
    toggleMute: () => set(state => ({ isMuted: !state.isMuted })),
    toggleControls: () => set(state => ({ showControls: !state.showControls })),
    setRenderDistance: (distance) => set({ renderDistance: Math.max(150, Math.min(600, distance)) }),
    setMobileControlsEnabled: (enabled) => set({ mobileControlsEnabled: enabled }),
    
    addCubeToInventory: (type, amount) => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      const newCubes = { ...currentSlot.cubes, [type]: currentSlot.cubes[type] + amount };
      const newSlot = { ...currentSlot, cubes: newCubes };
      set({ currentSlot: newSlot });
    },
    
    removeCubeFromInventory: (type, amount) => {
      const { currentSlot } = get();
      if (!currentSlot || currentSlot.cubes[type] < amount) return false;
      
      const newCubes = { ...currentSlot.cubes, [type]: currentSlot.cubes[type] - amount };
      const newSlot = { ...currentSlot, cubes: newCubes };
      set({ currentSlot: newSlot });
      return true;
    },
    
    upgradeInventory: () => {
      const { currentSlot } = get();
      if (!currentSlot) return false;
      if (currentSlot.inventorySlots >= 4) return false;
      
      const upgradeCost: Record<number, { type: CubeType; amount: number }> = {
        1: { type: "common", amount: 10 },
        2: { type: "uncommon", amount: 10 },
        3: { type: "rare", amount: 10 },
      };
      
      const cost = upgradeCost[currentSlot.inventorySlots];
      if (!cost || currentSlot.cubes[cost.type] < cost.amount) return false;
      
      const newCubes = { ...currentSlot.cubes, [cost.type]: currentSlot.cubes[cost.type] - cost.amount };
      const newSlot = { ...currentSlot, cubes: newCubes, inventorySlots: currentSlot.inventorySlots + 1 };
      set({ currentSlot: newSlot });
      get().saveGame();
      return true;
    },
    
    spawnEnemy: (enemyData) => {
      const enemy: Enemy = {
        ...enemyData,
        id: `enemy_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      };
      set(state => ({ worldEnemies: [...state.worldEnemies, enemy] }));
    },
    
    damageEnemy: (enemyId, damage) => {
      const { worldEnemies } = get();
      const enemy = worldEnemies.find(e => e.id === enemyId);
      if (!enemy) return;
      
      const newHp = enemy.hp - damage;
      if (newHp <= 0) {
        get().removeEnemy(enemyId);
        if (enemy.isBoss && enemy.bossIndex !== undefined) {
          get().defeatBoss(enemy.bossIndex);
        }
        enemy.drops.forEach(drop => {
          if ("type" in drop && drop.type === "coins") {
            get().addCoins(drop.amount);
          }
        });
      } else {
        set({
          worldEnemies: worldEnemies.map(e => 
            e.id === enemyId ? { ...e, hp: newHp } : e
          ),
        });
      }
    },
    
    removeEnemy: (enemyId) => {
      set(state => ({
        worldEnemies: state.worldEnemies.filter(e => e.id !== enemyId),
      }));
    },
    
    defeatBoss: (bossIndex) => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      if (!currentSlot.defeatedBosses.includes(bossIndex)) {
        const newSlot = {
          ...currentSlot,
          defeatedBosses: [...currentSlot.defeatedBosses, bossIndex],
        };
        set({ currentSlot: newSlot });
        get().saveGame();
      }
    },
    
    useLifeCube: () => {
      const { currentSlot } = get();
      if (!currentSlot || currentSlot.lifeCubes <= 0) return false;
      
      const newSlot = { ...currentSlot, lifeCubes: currentSlot.lifeCubes - 1 };
      set({ currentSlot: newSlot, playerHp: 50 });
      return true;
    },
    
    addLifeCube: () => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      const newSlot = { ...currentSlot, lifeCubes: currentSlot.lifeCubes + 1 };
      set({ currentSlot: newSlot });
    },
    
    updatePlayerPosition: (position) => set({ playerPosition: position }),
    
    placeWall: (wall) => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      const newWalls = [...currentSlot.placedWalls, wall];
      const newSlot = { ...currentSlot, placedWalls: newWalls };
      set({ currentSlot: newSlot });
    },
    
    removeWall: (wallId) => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      const newWalls = currentSlot.placedWalls.filter(w => w.id !== wallId);
      const newSlot = { ...currentSlot, placedWalls: newWalls };
      set({ currentSlot: newSlot });
    },
    
    damageWall: (wallId, damage) => {
      const { currentSlot } = get();
      if (!currentSlot) return;
      
      const wall = currentSlot.placedWalls.find(w => w.id === wallId);
      if (!wall) return;
      
      const newHp = wall.hp - damage;
      if (newHp <= 0) {
        get().removeWall(wallId);
      } else {
        const newWalls = currentSlot.placedWalls.map(w =>
          w.id === wallId ? { ...w, hp: newHp } : w
        );
        const newSlot = { ...currentSlot, placedWalls: newWalls };
        set({ currentSlot: newSlot });
      }
    },

    deleteAllData: () => {
      set({ 
        slots: [], 
        currentSlot: null, 
        phase: "menu", 
        playerHp: 100,
        worldCubes: [],
        worldEnemies: [],
        worldLootBoxes: [],
        availableSlots: 2,
        redeemedCodes: [],
        hasFreeAdmin: false,
        hasStarterPack: false,
      });
      localStorage.removeItem("cubeCombination_slots");
      localStorage.removeItem("cubeCombination_availableSlots");
      localStorage.removeItem("cubeCombination_redeemedCodes");
    },
  }))
);

let autoSaveInterval: number | null = null;

export const startAutoSave = () => {
  if (autoSaveInterval) clearInterval(autoSaveInterval);
  autoSaveInterval = window.setInterval(() => {
    const { currentSlot, saveGame } = useGameStore.getState();
    if (currentSlot) {
      saveGame();
      console.log("Auto-saved at", new Date().toLocaleTimeString());
    }
  }, 90000);
};

export const stopAutoSave = () => {
  if (autoSaveInterval) {
    clearInterval(autoSaveInterval);
    autoSaveInterval = null;
  }
};
