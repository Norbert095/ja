# Cube Combination Game

## Overview
A first-person 3D cube-based survival game inspired by Roblox Cube Combination. Players craft weapons, armor, and structures by dropping cubes on top of each other to combine them. Features include island exploration, boss battles, and a sandbox mode.

## Recent Changes
- November 29, 2025: Initial game implementation with all core systems

## Features
- **First-person 3D gameplay** with WASD movement and mouse look controls
- **Physics-based crafting**: Drop cubes on each other to combine them into items
- **6 Material cube types**: Common, Uncommon, Rare, Epic, Legendary, Mythic
- **18 Tiered weapons** across 3 categories (Daggers, Swords, Great Swords)
- **6 Armor tiers** (Helmet, Chestplate, Leggings)
- **6 Wall types** with increasing HP for building
- **4 Islands** to explore, accessible by building platforms
- **8 Main bosses** (2 difficulty paths with 4 bosses each)
- **3 Sandbox-exclusive bosses**
- **Crystal of Life**: 5000 HP crystal to protect (game over if destroyed)
- **Life Cubes**: Totem of Undying mechanic to prevent death
- **Save slot system**: 2 free + 5 purchasable slots with custom names
- **Auto-save** every 90 seconds
- **Sandbox mode** (50 coins): Spawn any item/boss with custom stats

## Project Architecture

### Client Structure
```
client/
├── src/
│   ├── components/
│   │   ├── game/          # 3D game components
│   │   │   ├── Player.tsx      # First-person player controller
│   │   │   ├── Island.tsx      # Island terrain and decorations
│   │   │   ├── Cube.tsx        # Cube entities and stacking
│   │   │   ├── Crystal.tsx     # Central crystal component
│   │   │   ├── Enemy.tsx       # Enemy and boss entities
│   │   │   ├── LootBox.tsx     # Loot box component
│   │   │   ├── Weapon.tsx      # Weapon rendering
│   │   │   └── GameScene.tsx   # Main game scene orchestrator
│   │   └── ui/            # UI components
│   │       ├── MainMenu.tsx
│   │       ├── SaveSlotSelector.tsx
│   │       ├── GameHUD.tsx
│   │       ├── PauseMenu.tsx
│   │       ├── CraftingUI.tsx
│   │       ├── InventoryUI.tsx
│   │       ├── SandboxPanel.tsx
│   │       └── GameOver.tsx
│   ├── lib/
│   │   ├── stores/
│   │   │   ├── useGameStore.tsx   # Main game state (Zustand)
│   │   │   └── useAudio.tsx       # Audio management
│   │   └── gameData.ts            # Game configuration/data
│   └── App.tsx
└── public/
    └── sounds/
        ├── background.mp3
        ├── hit.mp3
        └── success.mp3
```

### Key Technologies
- **React Three Fiber**: 3D rendering with React
- **@react-three/drei**: Helper components for R3F
- **Zustand**: State management
- **Tailwind CSS**: Styling
- **Radix UI**: UI components
- **LocalStorage**: Save data persistence

## Controls
- **WASD**: Movement
- **Mouse**: Look around
- **Space**: Jump
- **Left Click**: Attack
- **E**: Interact / Pick up
- **Tab**: Open inventory
- **C**: Open crafting
- **ESC**: Pause menu

## Crafting System
Drop cubes of the same type on top of each other to combine:
- 3 cubes → Weapon (based on cube tier)
- 2 cubes → Armor piece
- 2 cubes → Wall piece
- 5 Epic cubes → Life Cube

## User Preferences
- First-person controls with pointer lock
- Dark theme UI
- Auto-save enabled by default

## Development Notes
- Cubes spawn on the main (starter) island for safe crafting
- Enemies and bosses spawn on outer islands
- Crystal must be protected - game ends if destroyed
- Coins earned from defeating enemies to unlock sandbox and extra slots
